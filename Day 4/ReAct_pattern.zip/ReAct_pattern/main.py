import streamlit as st
import google.generativeai as genai
from tavily import TavilyClient
import json
import time
from datetime import datetime
import os
from typing import List, Dict, Any
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure Streamlit page
st.set_page_config(
    page_title="ReAct Web Research Agent",
    page_icon="🔍",
    layout="wide"
)

class ReActWebAgent:
    def __init__(self, gemini_api_key: str, tavily_api_key: str):
        """Initialize the ReAct Web Research Agent"""
        # Configure Gemini AI
        genai.configure(api_key=gemini_api_key)
        self.model = genai.GenerativeModel('gemini-1.5-flash')
        
        # Configure Tavily Search
        self.tavily_client = TavilyClient(api_key=tavily_api_key)
        
        # Storage for research data
        self.research_data = {}
        self.research_questions = []
        
    def generate_research_questions(self, topic: str) -> List[str]:
        """Planning Phase: Generate research questions using Gemini"""
        prompt = f"""
        You are a research assistant. Given the topic "{topic}", generate 5-6 comprehensive research questions that cover different aspects of this topic.
        
        The questions should be:
        1. Specific and focused
        2. Cover different angles/aspects
        3. Be answerable through web research
        4. Be relevant and current
        
        Return the questions as a numbered list, one question per line.
        
        Topic: {topic}
        """
        
        try:
            response = self.model.generate_content(prompt)
            questions_text = response.text
            
            # Parse questions from the response
            questions = []
            lines = questions_text.strip().split('\n')
            for line in lines:
                line = line.strip()
                if line and (line[0].isdigit() or line.startswith('-') or line.startswith('•')):
                    # Remove numbering and clean up
                    question = line.split('.', 1)[-1].strip()
                    if question.startswith(' '):
                        question = question[1:]
                    if question and len(question) > 10:  # Filter out very short questions
                        questions.append(question)
            
            self.research_questions = questions
            return questions
            
        except Exception as e:
            st.error(f"Error generating questions: {str(e)}")
            return []
    
    def search_web(self, query: str, max_results: int = 7) -> List[Dict]:
        """Acting Phase: Enhanced web search for better quality results"""
        try:
            search_result = self.tavily_client.search(
                query=query,
                search_depth="advanced",
                max_results=max_results,
                include_answer=True
            )
            
            results = []
            for result in search_result.get('results', []):
                results.append({
                    'title': result.get('title', ''),
                    'url': result.get('url', ''),
                    'content': result.get('content', ''),
                    'score': result.get('score', 0)
                })
            
            return results
            
        except Exception as e:
            st.error(f"Error searching web: {str(e)}")
            return []
    
    def extract_key_information(self, question: str, search_results: List[Dict]) -> str:
        """Enhanced information extraction for better quality responses"""
        # Prepare search results for analysis - use top 4 results for better quality
        results_text = ""
        for i, result in enumerate(search_results[:4]):
            # Take more content for better analysis
            content_snippet = result['content'][:700] if len(result['content']) > 700 else result['content']
            
            results_text += f"Source {i+1}: {result['title']}\n"
            results_text += f"Content: {content_snippet}...\n\n"
        
        prompt = f"""
        Based on the following search results, provide a comprehensive answer to the research question.
        
        Research Question: {question}
        
        Search Results:
        {results_text}
        
        Instructions:
        1. Synthesize information from multiple sources
        2. Provide a clear, factual answer with specific details
        3. Include statistics, data points, and key facts when available
        4. Structure your response in 2-3 well-developed paragraphs
        5. If information is conflicting or limited, mention it
        6. Focus on the most relevant and current information
        
        Answer:
        """
        
        try:
            response = self.model.generate_content(prompt)
            return response.text
        except Exception as e:
            return f"Error processing information: {str(e)}"
    
    def conduct_research(self, topic: str, progress_callback=None) -> Dict[str, Any]:
        """Complete research process using ReAct pattern"""
        research_data = {
            'topic': topic,
            'timestamp': datetime.now().isoformat(),
            'questions_and_answers': [],
            'summary': ''
        }
        
        # Phase 1: Planning - Generate research questions
        if progress_callback:
            progress_callback("Generating research questions...")
        
        questions = self.generate_research_questions(topic)
        if not questions:
            return research_data
        
        # Phase 2: Acting - Search and gather information
        total_questions = len(questions)
        
        for i, question in enumerate(questions):
            if progress_callback:
                progress_callback(f"Researching question {i+1}/{total_questions}: {question[:50]}...")
            
            # Search for information
            search_results = self.search_web(question)
            
            # Extract key information using LLM
            if search_results:
                answer = self.extract_key_information(question, search_results)
                sources = [{'title': r['title'], 'url': r['url']} for r in search_results[:3]]
            else:
                answer = "No relevant information found."
                sources = []
            
            research_data['questions_and_answers'].append({
                'question': question,
                'answer': answer,
                'sources': sources
            })
            
            time.sleep(1)  # Rate limiting
        
        # Phase 3: Generate summary
        if progress_callback:
            progress_callback("Generating final summary...")
        
        research_data['summary'] = self.generate_summary(topic, research_data['questions_and_answers'])
        
        self.research_data = research_data
        return research_data
    
    def generate_summary(self, topic: str, qa_pairs: List[Dict]) -> str:
        """Generate an enhanced summary of the research"""
        qa_text = ""
        for qa in qa_pairs:
            qa_text += f"Q: {qa['question']}\nA: {qa['answer']}\n\n"
        
        prompt = f"""
        Based on the research conducted on the topic "{topic}", provide a comprehensive summary that:
        
        1. Introduces the topic and its significance
        2. Highlights the key findings and important facts
        3. Identifies important trends, patterns, or insights
        4. Provides a well-reasoned conclusion
        
        Research Data:
        {qa_text}
        
        Generate a well-structured, analytical summary (3-4 paragraphs) that synthesizes all the information and provides meaningful insights:
        """
        
        try:
            response = self.model.generate_content(prompt)
            return response.text
        except Exception as e:
            return f"Error generating summary: {str(e)}"
    
    def generate_report(self) -> str:
        """Generate a formatted research report"""
        if not self.research_data:
            return "No research data available."
        
        report = f"""# Research Report: {self.research_data['topic']}

## Executive Summary
{self.research_data['summary']}

## Detailed Findings

"""
        
        for i, qa in enumerate(self.research_data['questions_and_answers'], 1):
            report += f"### {i}. {qa['question']}\n\n"
            report += f"{qa['answer']}\n\n"
            
            if qa['sources']:
                report += "**Sources:**\n"
                for source in qa['sources']:
                    report += f"- [{source['title']}]({source['url']})\n"
                report += "\n"
        
        report += f"""## Research Methodology
This report was generated using the ReAct (Reasoning + Acting) pattern:
1. **Planning Phase**: Research questions were generated using AI reasoning
2. **Acting Phase**: Enhanced web search was conducted for each question
3. **Analysis Phase**: Information was synthesized and analyzed for quality insights
4. **Reporting Phase**: Findings were compiled into this structured report

Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
        
        return report

def main():
    st.title("🔍 ReAct Web Research Agent")
    st.write("An intelligent research agent that uses the ReAct pattern to investigate topics systematically.")
    
    # API Keys - Try environment variables first, then sidebar
    st.sidebar.header("Configuration")
    
    gemini_key = os.getenv("GEMINI_API_KEY")
    tavily_key = os.getenv("TAVILY_API_KEY")
    
    # If not in environment, get from sidebar
    if not gemini_key:
        gemini_key = st.sidebar.text_input("Gemini API Key", type="password")
    else:
        st.sidebar.success("✅ Gemini API Key loaded from environment")
    
    if not tavily_key:
        tavily_key = st.sidebar.text_input("Tavily API Key", type="password")
    else:
        st.sidebar.success("✅ Tavily API Key loaded from environment")
    
    if not gemini_key or not tavily_key:
        st.warning("Please provide API keys either via .env file or sidebar inputs.")
        st.info("""
        **Option 1: Create .env file:**
        ```
        GEMINI_API_KEY=your_gemini_key_here
        TAVILY_API_KEY=your_tavily_key_here
        ```
        
        **Option 2: Enter keys in sidebar**
        - **Gemini API Key**: Get from [Google AI Studio](https://makersuite.google.com/app/apikey)
        - **Tavily API Key**: Get from [Tavily](https://tavily.com/)
        """)
        return
    
    # Initialize agent
    try:
        agent = ReActWebAgent(gemini_key, tavily_key)
    except Exception as e:
        st.error(f"Failed to initialize agent: {str(e)}")
        return
    
    # Main interface
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.header("Research Topic")
        topic = st.text_input("Enter the topic you want to research:", 
                             placeholder="e.g., Artificial Intelligence in Healthcare")
        
        if st.button("Start Research", type="primary"):
            if topic:
                # Progress tracking
                progress_bar = st.progress(0)
                status_text = st.empty()
                
                def update_progress(message):
                    status_text.text(message)
                
                # Conduct research
                with st.spinner("Conducting research..."):
                    research_data = agent.conduct_research(topic, update_progress)
                
                progress_bar.progress(100)
                status_text.text("Research completed!")
                
                # Display results
                st.success("Research completed successfully!")
                
                # Store results in session state
                st.session_state['research_data'] = research_data
                st.session_state['agent'] = agent
            else:
                st.error("Please enter a research topic.")
    
    with col2:
        st.header("Research Options")
        if st.button("Generate Report"):
            if 'agent' in st.session_state:
                report = st.session_state['agent'].generate_report()
                st.session_state['report'] = report
                st.success("Report generated!")
            else:
                st.error("Please conduct research first.")
        
        if st.button("Clear Results"):
            for key in ['research_data', 'agent', 'report']:
                if key in st.session_state:
                    del st.session_state[key]
            st.success("Results cleared!")
    
    # Display results
    if 'research_data' in st.session_state:
        st.header("Research Results")
        
        data = st.session_state['research_data']
        
        # Summary
        st.subheader("Summary")
        st.write(data['summary'])
        
        # Detailed findings
        st.subheader("Detailed Findings")
        
        for i, qa in enumerate(data['questions_and_answers'], 1):
            with st.expander(f"Question {i}: {qa['question']}"):
                st.write(qa['answer'])
                
                if qa['sources']:
                    st.write("**Sources:**")
                    for source in qa['sources']:
                        st.write(f"- [{source['title']}]({source['url']})")
    
    # Display report
    if 'report' in st.session_state:
        st.header("Generated Report")
        st.markdown(st.session_state['report'])
        
        # Download report
        st.download_button(
            label="Download Report",
            data=st.session_state['report'],
            file_name=f"research_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md",
            mime="text/markdown"
        )

if __name__ == "__main__":
    main()