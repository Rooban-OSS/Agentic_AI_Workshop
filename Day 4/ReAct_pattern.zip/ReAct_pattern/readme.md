# ReAct Web Research Agent

An intelligent research agent that uses the ReAct (Reasoning + Acting) pattern to systematically investigate topics, generate research questions, search the web, synthesize information, and produce a structured research report.

## Features

- **Automated Research Planning:** Generates focused research questions for any topic using Gemini AI.
- **Web Search Integration:** Uses Tavily API for advanced web search and information gathering.
- **LLM-Powered Synthesis:** Extracts and synthesizes key information from multiple sources.
- **Comprehensive Reporting:** Produces a detailed, well-structured research report with sources.
- **Streamlit UI:** User-friendly web interface for configuration, research, and report generation.

## Getting Started

### Prerequisites

- Python 3.8+
- [Streamlit](https://streamlit.io/)
- [google-generativeai](https://pypi.org/project/google-generativeai/)
- [tavily-python](https://pypi.org/project/tavily-python/)
- [python-dotenv](https://pypi.org/project/python-dotenv/)

Install dependencies:
```sh
pip install streamlit google-generativeai tavily-python python-dotenv
```

### API Keys

You need API keys for:
- **Gemini (Google Generative AI):** [Get your key](https://makersuite.google.com/app/apikey)
- **Tavily:** [Get your key](https://tavily.com/)

Create a `.env` file in the project directory:
```env
GEMINI_API_KEY=your_gemini_key_here
TAVILY_API_KEY=your_tavily_key_here
```

Or, enter the keys in the Streamlit sidebar when running the app.

GEMINI_API_KEY=AIzaSyCkC6OpUxidqhecrmisqIxzd4tyHb_kKHQ
TAVILY_API_KEY=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

### Running the App

```sh
streamlit run main.py
```

Open the provided URL in your browser to use the ReAct Web Research Agent.

## Usage

1. Enter your API keys via `.env` or the sidebar.
2. Input a research topic.
3. Click **Start Research** to begin.
4. View research questions, answers, and sources.
5. Generate and download a comprehensive research report.

## File Structure

- [`main.py`](main.py): Main application code.
- `.env`: API keys (not included in version control).

## License

This project is for educational and research purposes.

---

*Powered by Gemini AI, Tavily, and Streamlit.*