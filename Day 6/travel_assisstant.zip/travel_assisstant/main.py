# Travel Assistant AI - Complete Solution
# Requirements: pip install streamlit langchain langchain-google-genai langchain-community python-dotenv tavily-python

import streamlit as st
from langchain.tools import tool
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.agents import create_tool_calling_agent, AgentExecutor
from langchain.prompts import ChatPromptTemplate
from langchain_community.tools import TavilySearchResults
import os
from dotenv import load_dotenv
import json

# Load environment variables
load_dotenv()

# Configuration - Load from environment variables
TAVILY_API_KEY = os.getenv('TAVILY_API_KEY')
GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY')

# Initialize the LLM
@st.cache_resource
def initialize_llm():
    """Initialize the Gemini LLM"""
    try:
        llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            google_api_key=GOOGLE_API_KEY,
            temperature=0.3
        )
        return llm
    except Exception as e:
        st.error(f"Error initializing LLM: {str(e)}")
        return None

# Custom Weather Information Tool using Tavily Search
@tool
def get_weather_forecast(location: str) -> str:
    """
    Get current weather and forecast for a given location using Tavily search.
    
    Args:
        location (str): The city or location name
        
    Returns:
        str: Weather information including current conditions and forecast
    """
    try:
        tavily_search = TavilySearchResults(
            api_key=TAVILY_API_KEY,
            max_results=3,
            search_depth="advanced"
        )
        
        # Search for current weather
        weather_query = f"current weather forecast {location} temperature conditions today tomorrow"
        search_results = tavily_search.run(weather_query)
        
        if not search_results:
            return f"Unable to find weather information for {location}. Please try again with a more specific location."
        
        # Process and format weather information
        weather_info = f"🌍 **Weather Information for {location}**:\n\n"
        
        for i, result in enumerate(search_results[:2], 1):
            content = result.get('content', '')
            url = result.get('url', '')
            
            weather_info += f"**Source {i}**:\n{content[:500]}...\n"
            if url:
                weather_info += f"*Source: {url}*\n\n"
        
        weather_info += "\n💡 **Note**: Weather information sourced from real-time search results. For most accurate conditions, check local weather services."
        
        return weather_info
        
    except Exception as e:
        return f"Error fetching weather data: {str(e)}"

# Tourist Attractions Search Tool using Tavily
@tool
def search_tourist_attractions(location: str) -> str:
    """
    Search for top tourist attractions and places to visit in a given location using Tavily.
    
    Args:
        location (str): The city or location name
        
    Returns:
        str: Information about tourist attractions and places to visit
    """
    try:
        tavily_search = TavilySearchResults(
            api_key=TAVILY_API_KEY,
            max_results=5,
            search_depth="advanced"
        )
        
        # Search for tourist attractions
        attractions_query = f"top tourist attractions places to visit {location} travel guide landmarks"
        attractions_results = tavily_search.run(attractions_query)
        
        # Search for local experiences
        local_query = f"things to do {location} local experiences activities restaurants culture"
        local_results = tavily_search.run(local_query)
        
        if not attractions_results and not local_results:
            return f"Unable to find tourist information for {location}. Please try again with a more specific location."
        
        attractions_info = f"🏛️ **Top Tourist Attractions in {location}**:\n\n"
        
        # Process attractions results
        if attractions_results:
            attractions_info += "**🎯 Main Attractions & Landmarks**:\n"
            for i, result in enumerate(attractions_results[:3], 1):
                content = result.get('content', '')
                url = result.get('url', '')
                
                attractions_info += f"\n**{i}. {result.get('title', 'Attraction')}**\n"
                attractions_info += f"{content[:300]}...\n"
                if url:
                    attractions_info += f"*Source: {url}*\n"
        
        # Process local experiences results
        if local_results:
            attractions_info += "\n**🎭 Local Experiences & Activities**:\n"
            for i, result in enumerate(local_results[:2], 1):
                content = result.get('content', '')
                url = result.get('url', '')
                
                attractions_info += f"\n**Experience {i}**:\n{content[:250]}...\n"
                if url:
                    attractions_info += f"*Source: {url}*\n"
        
        attractions_info += "\n💡 **Tip**: For the most up-to-date information, visit official tourism websites and check recent reviews!"
        
        return attractions_info
        
    except Exception as e:
        return f"Error searching for attractions: {str(e)}"

# Initialize tools
def get_tools():
    """Get the list of available tools"""
    return [get_weather_forecast, search_tourist_attractions]

# Create the Travel Assistant Agent
@st.cache_resource
def create_travel_agent():
    """Create and return the travel assistant agent"""
    llm = initialize_llm()
    if not llm:
        return None, None
    
    # Define the prompt template
    prompt = ChatPromptTemplate.from_messages([
        ("system", """You are an intelligent Travel Assistant AI. Your role is to help users plan their trips by providing:

1. **Weather Information**: Current weather conditions and forecasts for their destination
2. **Tourist Attractions**: Top places to visit, local attractions, and activities

**Instructions**:
- Always use the available tools to get real-time information
- Provide comprehensive and helpful travel advice
- Format your responses in a clear, organized manner
- Include practical tips and recommendations
- Be enthusiastic and helpful in your tone
- If asked about a destination, always provide both weather and attractions information

**Available Tools**:
- get_weather_forecast: Get current weather and forecast using Tavily search
- search_tourist_attractions: Find top tourist attractions and experiences using Tavily

**Reasoning Process**:
1. First, I'll analyze the user's destination request
2. Use Tavily search to get current weather conditions and forecast
3. Use Tavily search to find popular attractions and activities
4. Combine and synthesize the information in an organized, helpful format
5. Provide additional travel tips and recommendations

Always think step by step and use both tools to provide complete travel assistance."""),
        ("placeholder", "{chat_history}"),
        ("human", "{input}"),
        ("placeholder", "{agent_scratchpad}")
    ])
    
    # Create the agent
    tools = get_tools()
    agent = create_tool_calling_agent(llm, tools, prompt)
    
    # Create the agent executor
    agent_executor = AgentExecutor(
        agent=agent,
        tools=tools,
        verbose=True,
        handle_parsing_errors=True,
        max_iterations=5
    )
    
    return agent, agent_executor

# Streamlit UI
def main():
    st.set_page_config(
        page_title="🧳 Travel Assistant AI",
        page_icon="🧳",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Header
    st.title("🧳 Intelligent Travel Assistant AI")
    st.markdown("### Your AI-powered travel companion for weather forecasts and destination insights!")
    
    # Sidebar for API keys
    with st.sidebar:
        st.header("🔑 Configuration")
        st.markdown("**Required API Keys:**")
        
        # Display current API key status
        if TAVILY_API_KEY:
            st.success("✅ Tavily API Key: Configured")
        else:
            st.error("❌ Tavily API Key: Missing")
            
        if GOOGLE_API_KEY:
            st.success("✅ Google Gemini API Key: Configured")
        else:
            st.error("❌ Google Gemini API Key: Missing")
            
        st.info("💡 Configure API keys in the .env file")
        
        st.markdown("---")
        st.markdown("**About this App:**")
        st.markdown("""
        This Travel Assistant uses:
        - 🤖 **Google Gemini** for AI reasoning
        - 🔍 **Tavily Search** for weather & attractions
        - ⚡ **LangChain** for agent orchestration
        - 🎯 **Advanced Search** for comprehensive results
        """)
    
    # Main interface
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("🌍 Where would you like to travel?")
        
        # Input for destination
        destination = st.text_input(
            "Enter your destination:",
            placeholder="e.g., Paris, Tokyo, New York, Bali",
            help="Enter any city or location worldwide"
        )
        
        # Search button
        search_button = st.button("🔍 Get Travel Information", type="primary")
        
        # Check if API keys are provided
        if not TAVILY_API_KEY or not GOOGLE_API_KEY:
            st.warning("⚠️ Please configure your API keys in the .env file to use the Travel Assistant.")
            st.info("""
            **To get started:**
            1. Create a .env file in your project directory
            2. Get a free Tavily API key from https://tavily.com/
            3. Get a free Google Gemini API key from Google AI Studio
            4. Add both keys to your .env file (see README for format)
            5. Restart the application
            """)
            return
    
    with col2:
        st.subheader("🎯 Features")
        st.markdown("""
        - **Real-time Weather** 🌤️
        - **3-Day Forecast** 📅
        - **Top Attractions** 🏛️
        - **Local Experiences** 🎭
        - **Travel Tips** 💡
        """)
    
    # Process the request
    if search_button and destination:
        if not TAVILY_API_KEY or not GOOGLE_API_KEY:
            st.error("Please configure your API keys in the .env file and restart the application.")
            return
        
        with st.spinner(f"🔍 Gathering travel information for {destination}..."):
            try:
                # Create the agent
                agent, agent_executor = create_travel_agent()
                
                if not agent_executor:
                    st.error("Error initializing the AI agent. Please check your Google API key.")
                    return
                
                # Execute the agent
                user_input = f"I want to travel to {destination}. Please provide me with current weather information and top tourist attractions for this destination."
                
                response = agent_executor.invoke({
                    "input": user_input,
                    "chat_history": []
                })
                
                # Display results
                st.success("✅ Travel information gathered successfully!")
                
                # Create tabs for organized display
                tab1, tab2, tab3 = st.tabs(["🤖 AI Assistant Response", "🌤️ Weather Details", "🏛️ Attractions"])
                
                with tab1:
                    st.subheader(f"🧳 Travel Guide for {destination}")
                    st.markdown(response['output'])
                
                with tab2:
                    st.subheader("🌤️ Weather Information")
                    with st.spinner("Searching for weather data..."):
                        weather_info = get_weather_forecast(destination)
                        st.markdown(weather_info)
                
                with tab3:
                    st.subheader("🏛️ Tourist Attractions")
                    with st.spinner("Searching for attractions..."):
                        attractions_info = search_tourist_attractions(destination)
                        st.markdown(attractions_info)
                
            except Exception as e:
                st.error(f"An error occurred: {str(e)}")
                st.info("Please check your API keys and try again.")
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style='text-align: center; color: #666;'>
        <p>🧳 Travel Assistant AI - Powered by LangChain, Google Gemini & Tavily Search</p>
        <p>Built with ❤️ using Streamlit</p>
    </div>
    """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
