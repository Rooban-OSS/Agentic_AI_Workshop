# README and Documentation
# Travel Assistant AI - Documentation

## Overview
This Travel Assistant AI is built using LangChain agents with Google Gemini as the reasoning engine. 
It provides comprehensive travel information including weather forecasts and tourist attractions.

## Architecture

### 1. LLM Reasoning with Google Gemini
The system uses Google Gemini Pro as the core reasoning engine:
- **Temperature**: Set to 0.3 for balanced creativity and consistency
- **Role**: Processes user queries and decides which tools to use
- **Reasoning Process**: 
  1. Analyzes user destination request
  2. Determines what information is needed
  3. Calls appropriate tools in sequence
  4. Synthesizes results into comprehensive travel advice

### 2. Custom Tools Implementation

#### Weather Tool (using Tavily Search)
- **Function**: `get_weather_forecast(location: str)`
- **Search Engine**: Tavily advanced search for weather data
- **Data**: Current conditions + forecast from real-time sources
- **Output**: Formatted weather information from multiple sources

#### Tourist Attractions Tool (using Tavily Search)
- **Function**: `search_tourist_attractions(location: str)`
- **Search Engine**: Tavily advanced search for comprehensive results
- **Queries**: Multiple targeted queries for attractions and experiences
- **Output**: Curated information from authoritative travel sources

### 3. Agent Architecture
- **Agent Type**: Tool-calling agent using `create_tool_calling_agent`
- **Executor**: AgentExecutor with error handling and iteration limits
- **Prompt Engineering**: Structured system prompt for consistent behavior
- **Tool Integration**: Seamless switching between weather and search tools

### 4. Code Flow

```
User Input (Destination) 
    ↓
Streamlit Interface
    ↓
LangChain Agent Initialization
    ↓
Gemini LLM Reasoning
    ↓
Tool Selection & Execution
    ├── Weather Tool (Tavily Search)
    └── Attractions Tool (Tavily Search)
    ↓
Result Synthesis
    ↓
Formatted Output Display
```

## Key Features

### Reasoning Process
1. **Input Analysis**: Gemini analyzes the destination request
2. **Tool Planning**: Decides which tools to use and in what order
3. **Execution**: Calls weather and search tools
4. **Synthesis**: Combines results into coherent travel advice
5. **Formatting**: Presents information in user-friendly format

### Error Handling
- API key validation
- Network error handling
- Parsing error management
- Graceful degradation

### User Experience
- Real-time feedback with spinners
- Organized tabbed interface
- Clear instructions and help text
- Responsive design

## Setup Instructions

### 1. Environment Setup

**Create a `.env` file** in your project directory with the following variables:

```env
# WeatherAPI Configuration
TAVILY_API_KEY=your_weatherapi_key_here

# Google Gemini API Configuration  
GOOGLE_API_KEY=your_google_gemini_api_key_here
```

TAVILY_API_KEY=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
GOOGLE_API_KEY=AIzaSyAYc1L8Tj5LfUo4S3CgogyJ4DOfPMAFdII


### 2. Install Dependencies

```bash
pip install streamlit langchain langchain-google-genai langchain-community requests python-dotenv
```

### 3. Get API Keys

**WeatherAPI Key (Free):**
1. Visit: https://www.weatherapi.com/
2. Sign up for a free account
3. Go to your dashboard to get your API key
4. Copy the key to your .env file as `WEATHER_API_KEY`

**Google Gemini API Key (Free):**
1. Visit: https://ai.google.dev/
2. Click "Get API key in Google AI Studio"
3. Create a new API key
4. Copy the key to your .env file as `GOOGLE_API_KEY`

### 4. Run the Application

```bash
streamlit run travel_assistant.py
```

### 5. Project Structure

```
travel-assistant/
├── travel_assistant.py    # Main application file
├── .env                  # Environment variables (create this)
├── .env.example         # Example environment file
├── requirements.txt     # Dependencies
└── README.md           # This file
```

### 6. Environment Variables

| Variable | Description | Required | Source |
|----------|-------------|----------|---------|
| `WEATHER_API_KEY` | API key for weather data | Yes | weatherapi.com |
| `GOOGLE_API_KEY` | API key for Gemini AI | Yes | Google AI Studio |

## Technical Implementation Details

### LangChain Agent Benefits
- **Modularity**: Each tool is independent and reusable
- **Extensibility**: Easy to add new tools (hotels, flights, etc.)
- **Error Handling**: Built-in retry and error management
- **Conversation Memory**: Maintains context across interactions

### Tavily Integration
- **Advanced Search**: Deep search capabilities for accurate information
- **Real-time Data**: Up-to-date weather and travel information
- **Multiple Sources**: Aggregates information from various reliable sources
- **Structured Results**: Clean, organized data perfect for AI processing

This implementation demonstrates a production-ready AI agent that uses Tavily's advanced search
capabilities to provide comprehensive travel assistance through an intuitive web interface.
The unified search approach ensures consistent, high-quality results for both weather and
attraction information."""