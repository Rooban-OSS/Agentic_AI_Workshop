from app.database import interviewers_collection, jobs_collection, candidates_collection, GEMINI_API_KEY, vector_store
from app.models import InterviewerType, ExperienceLevel, PanelMember, PanelRecommendation, ConflictStatus
from bson import ObjectId
from langchain_google_genai import GoogleGenerativeAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain.vectorstores import FAISS
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.docstore.document import Document
import json
import logging
from typing import List, Dict, Any
from app.crud import get_interviewer_relationships

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Gemini LLM
llm = GoogleGenerativeAI(model="gemini-1.5-flash", google_api_key=GEMINI_API_KEY)

# Initialize vector store with sample best practices
def initialize_vector_store():
    global vector_store
    if vector_store is None:
        embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
        best_practices = [
            Document(
                page_content="Optimal panel size is 3-5 members, balancing technical, behavioral, and managerial perspectives.",
                metadata={"source": "industry_best_practices"}
            ),
            Document(
                page_content="Include at least one technical interviewer for roles requiring specific skills like Python or Java.",
                metadata={"source": "industry_best_practices"}
            ),
            Document(
                page_content="Ensure panel includes diverse experience levels to cover both strategic and practical evaluation.",
                metadata={"source": "industry_best_practices"}
            ),
            Document(
                page_content="Behavioral interviewers should focus on cultural fit and soft skills for better team integration.",
                metadata={"source": "industry_best_practices"}
            )
        ]
        vector_store = FAISS.from_documents(best_practices, embeddings)

initialize_vector_store()

# Conflict Checker Agent
def check_panel_conflicts(selected_interviewers: List[Dict], candidate: Dict = None) -> Dict[str, Any]:
    """Check for conflicts of interest in the selected panel"""
    try:
        interviewer_ids = [str(interviewer["interviewer"]["_id"]) for interviewer in selected_interviewers]
        relationships = get_interviewer_relationships(interviewer_ids)
        conflicts_detected = []
        conflict_details = {}

        for i, interviewer in enumerate(selected_interviewers):
            interviewer_id = str(interviewer["interviewer"]["_id"])
            interviewer_data = next((r for r in relationships if str(r["_id"]) == interviewer_id), {})
            
            # Check for past collaborations
            past_collabs = set(interviewer_data.get("past_collaborations", []))
            for other_interviewer in selected_interviewers[i+1:]:
                other_id = str(other_interviewer["interviewer"]["_id"])
                if other_id in past_collabs:
                    conflict = f"Collaboration between {interviewer['interviewer']['name']} and {other_interviewer['interviewer']['name']}"
                    conflicts_detected.append(conflict)
                    conflict_details[interviewer_id] = conflict_details.get(interviewer_id, []) + [conflict]
                    conflict_details[other_id] = conflict_details.get(other_id, []) + [conflict]

            # Check for reporting structure conflicts
            reporting_id = interviewer_data.get("reporting_structure")
            if reporting_id and reporting_id in interviewer_ids:
                conflict = f"Reporting relationship with {interviewer['interviewer']['name']}"
                conflicts_detected.append(conflict)
                conflict_details[interviewer_id] = conflict_details.get(interviewer_id, []) + [conflict]

            # Check for departmental overlap with candidate
            if candidate and candidate.get("department") == interviewer_data.get("department"):
                conflict = f"Departmental overlap with candidate"
                conflicts_detected.append(conflict)
                conflict_details[interviewer_id] = conflict_details.get(interviewer_id, []) + [conflict]

        # Determine overall conflict level
        overall_conflict_level = "None"
        if conflicts_detected:
            overall_conflict_level = "Potential" if len(conflicts_detected) < len(selected_interviewers) else "Confirmed"

        # Assign conflict status to interviewers
        panel_conflicts = {}
        for interviewer in selected_interviewers:
            interviewer_id = str(interviewer["interviewer"]["_id"])
            details = conflict_details.get(interviewer_id, [])
            status = ConflictStatus.CONFIRMED if len(details) > 1 else ConflictStatus.POTENTIAL if details else ConflictStatus.NONE
            panel_conflicts[interviewer_id] = {
                "status": status,
                "details": "; ".join(details) if details else None
            }

        return {
            "overall_conflict_level": overall_conflict_level,
            "conflicts_detected": conflicts_detected,
            "panel_conflicts": panel_conflicts
        }
    except Exception as e:
        logger.error(f"Error checking panel conflicts: {e}")
        return {
            "overall_conflict_level": "None",
            "conflicts_detected": [],
            "panel_conflicts": {str(interviewer["interviewer"]["_id"]): {"status": ConflictStatus.NONE, "details": None} for interviewer in selected_interviewers}
        }

# Skill Match Agent
def calculate_skill_match_score(required_skills: List[str], interviewer_skills: List[str], job_description: str = "") -> float:
    """Calculate skill match score using both exact matches and semantic similarity"""
    if not required_skills or not interviewer_skills:
        return 0.0
    
    # Exact match score
    exact_matches = len(set(required_skills).intersection(set(interviewer_skills)))
    exact_score = exact_matches / len(required_skills)
    
    # Semantic match using Gemini
    semantic_prompt = PromptTemplate(
        input_variables=["required_skills", "interviewer_skills", "job_description"],
        template="""
        Analyze the skill match between required skills and interviewer skills for this job:
        
        Job Description: {job_description}
        Required Skills: {required_skills}
        Interviewer Skills: {interviewer_skills}
        
        Return a JSON with:
        {{
            "semantic_match_score": float (0.0 to 1.0),
            "matching_skills": [list of matching skills],
            "skill_gaps": [list of missing skills]
        }}
        """
    )
    
    try:
        chain = LLMChain(llm=llm, prompt=semantic_prompt)
        result = chain.run(
            required_skills=", ".join(required_skills),
            interviewer_skills=", ".join(interviewer_skills),
            job_description=job_description
        )
        semantic_data = json.loads(result.strip())
        semantic_score = semantic_data.get("semantic_match_score", 0.0)
        final_score = (exact_score * 0.4) + (semantic_score * 0.6)
        return min(final_score, 1.0)
    except Exception as e:
        logger.error(f"Error in semantic skill matching: {e}")
        return exact_score

# Panel Design Optimizer Agent with RAG
def generate_panel_composition_strategy(job: Dict, candidate: Dict = None) -> Dict[str, Any]:
    """Generate optimal panel composition strategy using Gemini with RAG"""
    job_info = f"Role: {job.get('job_role', 'N/A')}, Department: {job.get('department', 'N/A')}, Required Skills: {', '.join(job.get('required_skills', []))}"
    candidate_info = f"Experience Level: {candidate.get('experience_level', 'N/A')}, Skills: {', '.join(candidate.get('skills', []))}" if candidate else "Not provided"
    
    # Retrieve relevant best practices using RAG
    query = f"Optimal panel composition for job: {job_info}, candidate: {candidate_info}"
    try:
        relevant_docs = vector_store.similarity_search(query, k=3)
        context = "\n".join([doc.page_content for doc in relevant_docs])
    except Exception as e:
        logger.error(f"Error in RAG retrieval: {e}")
        context = "Default best practices: 3-5 member panel with technical and behavioral interviewers."

    strategy_prompt = PromptTemplate(
        input_variables=["job_info", "candidate_info", "context"],
        template="""
        As an expert in interview panel optimization, recommend the ideal panel composition based on industry best practices:

        Best Practices Context: {context}
        Job Information: {job_info}
        Candidate Information: {candidate_info}

        Provide recommendations for:
        1. Panel size
        2. Required interviewer types and their roles
        3. Experience level mix
        4. Specific skills needed

        Return a JSON response with:
        {{
            "recommended_panel_size": int,
            "interviewer_types_needed": [
                {{
                    "type": "technical|behavioral|domain_expert|hr|manager",
                    "count": int,
                    "primary_focus": "description",
                    "required_skills": [list]
                }}
            ],
            "experience_level_mix": {{
                "senior": int,
                "mid": int,
                "junior": int
            }},
            "special_considerations": [list]
        }}
        """
    )
    
    try:
        chain = LLMChain(llm=llm, prompt=strategy_prompt)
        result = chain.run(job_info=job_info, candidate_info=candidate_info, context=context)
        return json.loads(result.strip())
    except Exception as e:
        logger.error(f"Error generating panel strategy: {e}")
        return {
            "recommended_panel_size": 3,
            "interviewer_types_needed": [
                {"type": "technical", "count": 1, "primary_focus": "Technical skills assessment", "required_skills": job.get('required_skills', [])},
                {"type": "behavioral", "count": 1, "primary_focus": "Soft skills and cultural fit", "required_skills": []}
            ],
            "experience_level_mix": {"senior": 1, "mid": 1, "junior": 0},
            "special_considerations": []
        }

def score_interviewer_quality(interviewer: Dict) -> float:
    """Calculate interviewer quality score based on past performance"""
    feedback_score = interviewer.get('past_feedback_score', 0.0) / 5.0
    years_exp = interviewer.get('years_of_experience', 0)
    exp_factor = min(years_exp / 10, 1.0)
    quality_score = (feedback_score * 0.6) + (exp_factor * 0.4)
    return round(quality_score, 3)

def recommend_interviewers(entity_id: str, is_final: bool = False) -> PanelRecommendation:
    """Main function to recommend interviewers using Skill Match, Panel Design Optimizer, and Conflict Checker agents"""
    try:
        if is_final:
            candidate = candidates_collection.find_one({"_id": ObjectId(entity_id)})
            if not candidate:
                raise ValueError("Candidate not found")
            job = jobs_collection.find_one({"job_role": candidate["job_role"]})
            if not job:
                raise ValueError("Job not found")
            panel_strategy = generate_panel_composition_strategy(job, candidate)
        else:
            job = jobs_collection.find_one({"_id": ObjectId(entity_id)})
            if not job:
                raise ValueError("Job not found")
            candidate = None
            panel_strategy = generate_panel_composition_strategy(job)
        
        # Get all available interviewers
        all_interviewers = list(interviewers_collection.find())
        
        # Score interviewers using Skill Match Agent
        scored_interviewers = []
        for interviewer in all_interviewers:
            skill_score = calculate_skill_match_score(
                job.get('required_skills', []),
                interviewer.get('skills', []),
                job.get('job_description', '')
            )
            quality_score = score_interviewer_quality(interviewer)
            overall_score = (skill_score * 0.5) + (quality_score * 0.5)
            
            if overall_score >= 0.3:
                scored_interviewers.append({
                    "interviewer": interviewer,
                    "skill_score": skill_score,
                    "quality_score": quality_score,
                    "overall_score": overall_score
                })
        
        # Sort by overall score
        scored_interviewers.sort(key=lambda x: x["overall_score"], reverse=True)
        
        # Select optimal panel using Panel Design Optimizer Agent
        panel_size = panel_strategy.get("recommended_panel_size", 3)
        selected_panel = []
        by_type = {}
        for item in scored_interviewers:
            interviewer_type = item["interviewer"].get("interviewer_type", InterviewerType.TECHNICAL)
            if interviewer_type not in by_type:
                by_type[interviewer_type] = []
            by_type[interviewer_type].append(item)
        
        for type_req in panel_strategy.get("interviewer_types_needed", []):
            type_name = type_req["type"]
            count_needed = type_req["count"]
            if type_name in by_type:
                candidates = sorted(by_type[type_name], key=lambda x: x["overall_score"], reverse=True)
                selected_panel.extend(candidates[:count_needed])
        
        remaining_slots = panel_size - len(selected_panel)
        if remaining_slots > 0:
            selected_ids = {item["interviewer"]["_id"] for item in selected_panel}
            remaining_candidates = [
                item for item in scored_interviewers 
                if item["interviewer"]["_id"] not in selected_ids
            ]
            remaining_candidates.sort(key=lambda x: x["overall_score"], reverse=True)
            selected_panel.extend(remaining_candidates[:remaining_slots])
        
        selected_panel = selected_panel[:panel_size]
        
        # Check for conflicts using Conflict Checker Agent
        conflict_info = check_panel_conflicts(selected_panel, candidate)
        
        # Create panel member objects
        panel_members = [
            PanelMember(
                interviewer_id=str(item["interviewer"]["_id"]),
                name=item["interviewer"]["name"],
                match_score=item["skill_score"],
                role_in_panel=item["interviewer"].get("interviewer_type", InterviewerType.TECHNICAL),
                recommendation_reason=f"Skill match score: {item['skill_score']:.2f}, Quality score: {item['quality_score']:.2f}",
                conflict_status=conflict_info["panel_conflicts"][str(item["interviewer"]["_id"])]["status"],
                conflict_details=conflict_info["panel_conflicts"][str(item["interviewer"]["_id"])]["details"]
            )
            for item in selected_panel
        ]
        
        # Calculate skill coverage
        panel_skills = set()
        for item in selected_panel:
            panel_skills.update(item["interviewer"].get("skills", []))
        covered_skills = list(set(job.get('required_skills', [])).intersection(panel_skills))
        missing_skills = list(set(job.get('required_skills', [])).difference(panel_skills))
        coverage_score = len(covered_skills) / len(job.get('required_skills', [])) if job.get('required_skills', []) else 1.0
        
        # Calculate quality metrics
        avg_overall_score = sum(item["overall_score"] for item in selected_panel) / len(selected_panel) if selected_panel else 0.0
        quality_metrics = {
            "overall_quality": round(avg_overall_score, 3),
            "panel_size": len(selected_panel),
            "quality_rating": "excellent" if avg_overall_score >= 0.8 else "good" if avg_overall_score >= 0.6 else "fair"
        }
        
        # Generate alternative suggestions
        selected_ids = {item["interviewer"]["_id"] for item in selected_panel}
        alternatives = [
            {
                "interviewer_id": str(item["interviewer"]["_id"]),
                "name": item["interviewer"]["name"],
                "overall_score": item["overall_score"],
                "reason": f"Alternative with score {item['overall_score']:.2f}"
            }
            for item in scored_interviewers if item["interviewer"]["_id"] not in selected_ids and item["overall_score"] >= 0.4
        ][:3]
        
        return PanelRecommendation(
            recommended_panel=panel_members,
            skill_coverage={
                "coverage_score": coverage_score,
                "covered_skills": covered_skills,
                "missing_skills": missing_skills
            },
            quality_metrics=quality_metrics,
            alternatives=alternatives,
            conflict_summary={
                "overall_conflict_level": conflict_info["overall_conflict_level"],
                "conflicts_detected": conflict_info["conflicts_detected"]
            }
        )
    
    except Exception as e:
        logger.error(f"Error in recommendation: {e}")
        raise