Interview Panel Optimizer
The Interview Panel Optimizer is an AI-powered web application designed to streamline the process of creating optimized interview panels for job candidates. By leveraging advanced AI agents, including Skill Match, Panel Design Optimizer, and Conflict Checker, the system ensures that interview panels are tailored to job requirements, candidate profiles, and organizational constraints while minimizing conflicts of interest. The application is built using FastAPI for the backend, Streamlit for the frontend, and MongoDB for data persistence, with Gemini AI and Retrieval-Augmented Generation (RAG) for intelligent panel recommendations.
This README provides a comprehensive guide to setting up, running, and using the Interview Panel Optimizer, as well as an overview of its architecture, features, and dependencies.

Table of Contents

Overview
Features
Architecture
File Structure
Prerequisites
Setup Instructions
Running the Application
Usage
API Endpoints
Environment Variables
Contributing
License


Overview
The Interview Panel Optimizer automates the creation of interview panels by matching interviewers to job requirements and candidate profiles based on skills, experience, and availability. It uses AI-driven agents to:

Skill Match Agent: Matches interviewer skills with job requirements using exact matching and semantic similarity powered by Gemini AI.
Panel Design Optimizer Agent: Designs optimal panel compositions using industry best practices retrieved via RAG.
Conflict Checker Agent: Identifies potential conflicts of interest, such as past collaborations or reporting relationships, to ensure fair evaluations.

The application provides a user-friendly interface through Streamlit, allowing users to manage jobs, interviewers, candidates, and generate panel recommendations. The backend, built with FastAPI, exposes RESTful APIs for seamless integration with other systems.

Features

Job Management:

Create and list jobs with details like role, description, required skills, experience level, and department.
Visualize job distribution by department using interactive charts.


Interviewer Management:

Add and manage interviewer profiles, including skills, availability, experience level, and past collaborations.
Filter interviewers by department and type, with visualizations of interviewer type distribution.


Candidate Management:

Register and manage candidate profiles, including skills, job role, and experience level.
Filter candidates by job role and visualize experience level distribution.


Panel Recommendations:

Generate optimized interview panels based on job or candidate requirements.
Provide detailed analysis of skill coverage, quality metrics, and conflict status.
Offer alternative interviewer suggestions to address conflicts or improve panel quality.


Health Monitoring:

Check system and database status via a health endpoint.
Display active features and system version.


Visualization:

Interactive charts (bar, pie) for job, interviewer, and candidate distributions.
Visual analysis of skill coverage and panel quality metrics.


AI Integration:

Uses Gemini AI for semantic skill matching and panel composition recommendations.
Implements RAG with FAISS for retrieving industry best practices.


Responsive UI:

Streamlit-based interface with custom CSS for a professional look and feel.
Sidebar navigation for easy access to different sections.




Architecture
The Interview Panel Optimizer follows a modular architecture with the following components:

Frontend (Streamlit):

Built with Streamlit for a responsive, interactive user interface.
Handles user input, displays data, and visualizes analytics using Plotly.
Custom CSS for styling, including badges for conflict status and button hover effects.


Backend (FastAPI):

Provides RESTful APIs for managing jobs, interviewers, candidates, and panel recommendations.
Integrates with MongoDB for data storage and retrieval.
Uses Pydantic models for data validation and serialization.
Implements CORS middleware for cross-origin requests.


Database (MongoDB):

Stores job, interviewer, candidate, and panel data in separate collections.
Uses MongoDB Atlas for cloud-hosted database management.
Supports CRUD operations via the crud.py module.


AI Components:

Skill Match Agent: Combines exact skill matching with semantic similarity using Gemini AI.
Panel Design Optimizer Agent: Uses RAG with FAISS and Gemini AI to recommend optimal panel compositions.
Conflict Checker Agent: Analyzes interviewer relationships and candidate overlaps to detect conflicts.


Vector Store (FAISS):

Stores industry best practices for panel composition, retrieved via similarity search for RAG.




File Structure
Below is the structure of the project files and their purposes:
interview_panel_optimizer/
│
├── app/
│   ├── __init__.py              # Package initializer
│   ├── main.py                  # FastAPI application with API endpoints
│   ├── database.py              # MongoDB connection and vector store setup
│   ├── models.py                # Pydantic models for data validation
│   ├── crud.py                  # CRUD operations for MongoDB
│   ├── utils.py                 # AI agents and utility functions
│
├── streamlit_app.py             # Streamlit frontend application
├── .env                         # Environment variables (e.g., GEMINI_API_KEY)
├── requirements.txt             # Python dependencies
└── README.md                    # Project documentation (this file)


main.py: Defines the FastAPI application, including endpoints for job, interviewer, candidate, and panel management, as well as a health check endpoint.
database.py: Configures the MongoDB connection and initializes the FAISS vector store for RAG.
models.py: Defines Pydantic models for Job, Interviewer, Candidate, and PanelRecommendation with validation rules.
crud.py: Implements CRUD operations for interacting with MongoDB collections.
utils.py: Contains the AI agents (Skill Match, Panel Design Optimizer, Conflict Checker) and utility functions for panel recommendations.
streamlit_app.py: Implements the Streamlit frontend with pages for managing jobs, interviewers, candidates, and generating panel recommendations.


Prerequisites
To run the Interview Panel Optimizer, ensure you have the following installed:

Python: Version 3.8 or higher
MongoDB: A running MongoDB instance (local or cloud-based, e.g., MongoDB Atlas)
Node.js: Required for some dependencies (e.g., FAISS)
pip: Python package manager
Virtual Environment: Recommended for dependency isolation

Required Python packages are listed in requirements.txt. Key dependencies include:

fastapi
streamlit
pymongo
requests
pandas
plotly
langchain
langchain-google-genai
langchain-community
faiss-cpu
python-dotenv
pydantic


Setup Instructions

Clone the Repository:
git clone https://github.com/your-repo/interview-panel-optimizer.git
cd interview-panel-optimizer


Set Up a Virtual Environment:
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate


Install Dependencies:
pip install -r requirements.txt


Configure Environment Variables:Create a .env file in the project root with the following content:
GEMINI_API_KEY=AIzaSyDm1hEuwB40_ER9gM-PpKnKhMl_flboPQs

Replace the MongoDB connection string in database.py with your own if using a different MongoDB instance:
client = MongoClient("your-mongodb-connection-string")


Initialize the Vector Store:The vector store is initialized automatically in utils.py with sample best practices. To add custom best practices, modify the initialize_vector_store function in utils.py.



Running the Application

Start the FastAPI Backend:
uvicorn app.main:app --host 0.0.0.0 --port 8000

The API will be available at http://localhost:8000. Access the API documentation at http://localhost:8000/docs.

Start the Streamlit Frontend:
streamlit run streamlit_app.py

The Streamlit app will be available at http://localhost:8501.

Verify Setup:

Check the API health endpoint at http://localhost:8000/health.
Navigate to the Streamlit app and verify the "Home" page displays system status and features.




Usage
Streamlit Interface
The Streamlit app provides a user-friendly interface with the following pages:

Home:

Displays system status, database connection, version, and active features.
Use the sidebar to navigate to other sections.


Manage Jobs:

Create Job: Enter job details (role, description, skills, experience level, department, interviewer types) to create a new job.
List Jobs: View existing jobs with pagination and filter by skip/limit. Visualize job distribution by department.


Manage Interviewers:

Add Interviewer: Enter interviewer details (name, email, department, skills, availability, etc.) to add a new interviewer.
List Interviewers: Filter by department or interviewer type and view details. Visualize interviewer type distribution.


Manage Candidates:

Register Candidate: Enter candidate details (name, email, job role, skills, experience level) to register a new candidate.
List Candidates: Filter by job role and view details. Visualize candidate experience level distribution.


Panel Recommendations:

Select a job or candidate to generate an optimized interview panel.
View recommended panel members, skill coverage, quality metrics, conflict summary, and alternative suggestions.
Visualize skill coverage and quality metrics with interactive charts.



API Usage
The FastAPI backend provides RESTful endpoints for programmatic access. Key endpoints include:

Health Check: GET /health
Job Management:
POST /job/create: Create a new job.
GET /job/{job_id}: Retrieve job details.
GET /jobs: List jobs with pagination.


Interviewer Management:
POST /interviewer/add: Add a new interviewer.
GET /interviewers: List interviewers with filters.


Candidate Management:
POST /candidate/register: Register a new candidate.
GET /candidates: List candidates with filters.


Panel Recommendations:
GET /job/{job_id}/recommend_panel: Generate panel for a job.
GET /candidate/{candidate_id}/suggest_panel: Generate panel for a candidate.



See the API Endpoints section for detailed endpoint descriptions.

API Endpoints
Health Check

GET /health
Description: Check system and database status.
Response:{
  "status": "healthy",
  "database": "connected",
  "version": "2.1.0",
  "features_active": ["skill_matching", "panel_design_optimization", "conflict_checking"]
}





Job Management

POST /job/create

Description: Create a new job.
Request Body: JSON conforming to the Job model (see models.py).
Response:{
  "message": "Job created successfully",
  "job_id": "string",
  "job_role": "string",
  "department": "string"
}




GET /job/{job_id}

Description: Retrieve job details by ID.
Response: Job details or 404 if not found.


GET /jobs?skip={skip}&limit={limit}

Description: List jobs with pagination.
Response:{
  "jobs": [{...}],
  "count": integer,
  "skip": integer,
  "limit": integer
}





Interviewer Management

POST /interviewer/add

Description: Add a new interviewer.
Request Body: JSON conforming to the Interviewer model.
Response:{
  "message": "Interviewer added successfully",
  "interviewer_id": "string",
  "name": "string",
  "department": "string"
}




GET /interviewers?department={department}&interviewer_type={type}&skip={skip}&limit={limit}

Description: List interviewers with optional filters.
Response:{
  "interviewers": [{...}],
  "count": integer,
  "filters": {...}
}





Candidate Management

POST /candidate/register

Description: Register a new candidate.
Request Body: JSON conforming to the Candidate model.
Response:{
  "message": "Candidate registered successfully",
  "candidate_id": "string",
  "name": "string",
  "job_role": "string"
}




GET /candidates?job_role={job_role}&skip={skip}&limit={limit}

Description: List candidates with optional job role filter.
Response:{
  "candidates": [{...}],
  "count": integer,
  "filters": {...}
}





Panel Recommendations

GET /job/{job_id}/recommend_panel

Description: Generate an interview panel for a job.
Response: JSON conforming to the PanelRecommendation model.


GET /candidate/{candidate_id}/suggest_panel

Description: Generate an interview panel for a candidate.
Response: JSON conforming to the PanelRecommendation model.




Environment Variables
The application requires the following environment variable to be set in a .env file:
GEMINI_API_KEY=AIzaSyDm1hEuwB40_ER9gM-PpKnKhMl_flboPQs


GEMINI_API_KEY: API key for accessing the Gemini AI model used for semantic skill matching and panel composition.

Ensure the MongoDB connection string in database.py is updated to match your MongoDB instance.

Contributing
Contributions are welcome! To contribute:

Fork the repository.
Create a new branch for your feature or bug fix:git checkout -b feature/your-feature-name


Make changes and commit:git commit -m "Add your feature description"


Push to your fork:git push origin feature/your-feature-name


Create a pull request with a detailed description of your changes.

Please ensure your code follows the project's coding standards and includes appropriate tests.

License
This project is licensed under the MIT License. See the LICENSE file for details.
