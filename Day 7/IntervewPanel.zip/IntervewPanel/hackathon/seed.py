from app.database import jobs_collection, interviewers_collection, candidates_collection, panels_collection
from datetime import datetime, timedelta
import logging
from bson import ObjectId

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def seed_database():
    """Seed the database with sample data for testing the Interview Panel Optimizer"""
    try:
        # Clear existing collections to avoid duplicates
        jobs_collection.delete_many({})
        interviewers_collection.delete_many({})
        candidates_collection.delete_many({})
        panels_collection.delete_many({})
        logger.info("Cleared existing collections")

        # Define sample data
        jobs = [
            {
                "_id": ObjectId(),
                "job_role": "Software Engineer",
                "job_description": "Develop and maintain web applications using Python and JavaScript.",
                "required_skills": ["Python", "JavaScript", "React", "SQL", "AWS"],
                "experience_level": "mid",
                "department": "Engineering",
                "interviewer_types_needed": ["technical", "behavioral", "manager"],
                "created_at": datetime.now(),
                "status": "active"
            },
            {
                "_id": ObjectId(),
                "job_role": "Data Scientist",
                "job_description": "Analyze large datasets to provide business insights using machine learning.",
                "required_skills": ["Python", "R", "Machine Learning", "SQL", "Tableau"],
                "experience_level": "senior",
                "department": "Data Science",
                "interviewer_types_needed": ["technical", "domain_expert"],
                "created_at": datetime.now(),
                "status": "active"
            },
            {
                "_id": ObjectId(),
                "job_role": "Product Manager",
                "job_description": "Lead product development with cross-functional teams.",
                "required_skills": ["Product Management", "Agile", "Leadership", "UX Design"],
                "experience_level": "lead",
                "department": "Product",
                "interviewer_types_needed": ["behavioral", "manager", "hr"],
                "created_at": datetime.now(),
                "status": "active"
            },
            {
                "_id": ObjectId(),
                "job_role": "DevOps Engineer",
                "job_description": "Manage CI/CD pipelines and cloud infrastructure.",
                "required_skills": ["Docker", "Kubernetes", "AWS", "Jenkins", "Linux"],
                "experience_level": "mid",
                "department": "Engineering",
                "interviewer_types_needed": ["technical", "behavioral"],
                "created_at": datetime.now(),
                "status": "active"
            },
            {
                "_id": ObjectId(),
                "job_role": "UX Designer",
                "job_description": "Design user-friendly interfaces for web and mobile applications.",
                "required_skills": ["Figma", "UI/UX Design", "Prototyping", "User Research"],
                "experience_level": "junior",
                "department": "Design",
                "interviewer_types_needed": ["domain_expert", "behavioral"],
                "created_at": datetime.now(),
                "status": "active"
            }
        ]

        # Define interviewers without past_collaborations and reporting_structure initially
        interviewers = [
            {
                "_id": ObjectId(),
                "name": "Madhu",
                "email": "madhu@example.com",
                "department": "Engineering",
                "skills": ["Python", "JavaScript", "React", "SQL", "AWS", "Leadership"],
                "availability": [
                    {"from": (datetime.now() + timedelta(days=1)).isoformat(), "to": (datetime.now() + timedelta(days=1, hours=8)).isoformat()}
                ],
                "past_feedback_score": 4.8,
                "experience_level": "senior",
                "interviewer_type": "technical",
                "years_of_experience": 8,
                "past_collaborations": [],
                "reporting_structure": None,
                "created_at": datetime.now(),
                "status": "active"
            },
            {
                "_id": ObjectId(),
                "name": "Venkat",
                "email": "venkat@example.com",
                "department": "Engineering",
                "skills": ["Docker", "Kubernetes", "AWS", "Jenkins"],
                "availability": [
                    {"from": (datetime.now() + timedelta(days=2)).isoformat(), "to": (datetime.now() + timedelta(days=2, hours=8)).isoformat()}
                ],
                "past_feedback_score": 4.2,
                "experience_level": "mid",
                "interviewer_type": "technical",
                "years_of_experience": 5,
                "past_collaborations": [],
                "reporting_structure": None,
                "created_at": datetime.now(),
                "status": "active"
            },
            {
                "_id": ObjectId(),
                "name": "Alex",
                "email": "alex@example.com",
                "department": "Data Science",
                "skills": ["Python", "R", "Machine Learning", "SQL"],
                "availability": [
                    {"from": (datetime.now() + timedelta(days=3)).isoformat(), "to": (datetime.now() + timedelta(days=3, hours=8)).isoformat()}
                ],
                "past_feedback_score": 4.5,
                "experience_level": "senior",
                "interviewer_type": "domain_expert",
                "years_of_experience": 7,
                "past_collaborations": [],
                "reporting_structure": None,
                "created_at": datetime.now(),
                "status": "active"
            },
            {
                "_id": ObjectId(),
                "name": "Vignesh",
                "email": "vignesh@example.com",
                "department": "Product",
                "skills": ["Product Management", "Agile", "Leadership"],
                "availability": [
                    {"from": (datetime.now() + timedelta(days=4)).isoformat(), "to": (datetime.now() + timedelta(days=4, hours=8)).isoformat()}
                ],
                "past_feedback_score": 4.0,
                "experience_level": "lead",
                "interviewer_type": "manager",
                "years_of_experience": 10,
                "past_collaborations": [],
                "reporting_structure": None,
                "created_at": datetime.now(),
                "status": "active"
            },
            {
                "_id": ObjectId(),
                "name": "Surya Prakash",
                "email": "surya@example.com",
                "department": "Engineering",
                "skills": ["Python", "JavaScript", "Node.js"],
                "availability": [
                    {"from": (datetime.now() + timedelta(days=5)).isoformat(), "to": (datetime.now() + timedelta(days=5, hours=8)).isoformat()}
                ],
                "past_feedback_score": 3.8,
                "experience_level": "mid",
                "interviewer_type": "technical",
                "years_of_experience": 4,
                "past_collaborations": [],
                "reporting_structure": None,
                "created_at": datetime.now(),
                "status": "active"
            },
            {
                "_id": ObjectId(),
                "name": "Lakshman",
                "email": "lakshman@example.com",
                "department": "Design",
                "skills": ["Figma", "UI/UX Design", "Prototyping"],
                "availability": [
                    {"from": (datetime.now() + timedelta(days=6)).isoformat(), "to": (datetime.now() + timedelta(days=6, hours=8)).isoformat()}
                ],
                "past_feedback_score": 4.3,
                "experience_level": "junior",
                "interviewer_type": "domain_expert",
                "years_of_experience": 2,
                "past_collaborations": [],
                "reporting_structure": None,
                "created_at": datetime.now(),
                "status": "active"
            }
        ]

        # Update past_collaborations and reporting_structure after defining interviewers
        interviewers[1]["past_collaborations"] = [str(interviewers[0]["_id"])]  # Venkat collaborated with Madhu
        interviewers[1]["reporting_structure"] = str(interviewers[0]["_id"])  # Venkat reports to Madhu
        interviewers[3]["past_collaborations"] = [str(interviewers[2]["_id"])]  # Vignesh collaborated with Alex
        interviewers[4]["past_collaborations"] = [str(interviewers[1]["_id"])]  # Surya Prakash collaborated with Venkat
        interviewers[4]["reporting_structure"] = str(interviewers[0]["_id"])  # Surya Prakash reports to Madhu

        # Define candidates
        candidates = [
            {
                "_id": ObjectId(),
                "name": "Swetha",
                "email": "swetha@example.com",
                "job_role": "Software Engineer",
                "skills": ["Python", "JavaScript", "React", "SQL"],
                "experience_level": "mid",
                "department": "Engineering",
                "created_at": datetime.now(),
                "status": "active"
            },
            {
                "_id": ObjectId(),
                "name": "Rooban",
                "email": "rooban@example.com",
                "job_role": "Data Scientist",
                "skills": ["Python", "R", "Machine Learning", "Tableau"],
                "experience_level": "senior",
                "department": "Data Science",
                "created_at": datetime.now(),
                "status": "active"
            },
            {
                "_id": ObjectId(),
                "name": "Afrin",
                "email": "afrin@example.com",
                "job_role": "Product Manager",
                "skills": ["Product Management", "Agile", "UX Design"],
                "experience_level": "lead",
                "department": "Product",
                "created_at": datetime.now(),
                "status": "active"
            },
            {
                "_id": ObjectId(),
                "name": "Shanmitha",
                "email": "shanmitha@example.com",
                "job_role": "DevOps Engineer",
                "skills": ["Docker", "Kubernetes", "AWS"],
                "experience_level": "mid",
                "department": "Engineering",
                "created_at": datetime.now(),
                "status": "active"
            },
            {
                "_id": ObjectId(),
                "name": "Roshini",
                "email": "roshini@example.com",
                "job_role": "UX Designer",
                "skills": ["Figma", "UI/UX Design"],
                "experience_level": "junior",
                "department": "Design",
                "created_at": datetime.now(),
                "status": "active"
            },
            {
                "_id": ObjectId(),
                "name": "Rudra",
                "email": "rudra@example.com",
                "job_role": "Software Engineer",
                "skills": ["Python", "Node.js"],
                "experience_level": "mid",
                "department": "Engineering",
                "created_at": datetime.now(),
                "status": "active"
            }
        ]

        # Define sample panels
        panels = [
            {
                "_id": ObjectId(),
                "job_id": str(jobs[0]["_id"]),
                "candidate_id": str(candidates[0]["_id"]),  # Swetha for Software Engineer
                "panel_members": [
                    {"interviewer_id": str(interviewers[0]["_id"]), "name": "Madhu", "role": "technical"},
                    {"interviewer_id": str(interviewers[4]["_id"]), "name": "Surya Prakash", "role": "technical"},
                    {"interviewer_id": str(interviewers[3]["_id"]), "name": "Vignesh", "role": "manager"}
                ],
                "created_at": datetime.now(),
                "status": "scheduled"
            },
            {
                "_id": ObjectId(),
                "job_id": str(jobs[1]["_id"]),
                "candidate_id": str(candidates[1]["_id"]),  # Rooban for Data Scientist
                "panel_members": [
                    {"interviewer_id": str(interviewers[2]["_id"]), "name": "Alex", "role": "domain_expert"},
                    {"interviewer_id": str(interviewers[0]["_id"]), "name": "Madhu", "role": "technical"}
                ],
                "created_at": datetime.now(),
                "status": "scheduled"
            }
        ]

        # Insert data into MongoDB
        jobs_collection.insert_many(jobs)
        interviewers_collection.insert_many(interviewers)
        candidates_collection.insert_many(candidates)
        panels_collection.insert_many(panels)

        logger.info(f"Seeded database with {len(jobs)} jobs, {len(interviewers)} interviewers, {len(candidates)} candidates, and {len(panels)} panels")
        
        # Print IDs for reference
        print("Seeded Job IDs:")
        for job in jobs:
            print(f"- {job['job_role']}: {job['_id']}")
        print("\nSeeded Interviewer IDs:")
        for interviewer in interviewers:
            print(f"- {interviewer['name']}: {interviewer['_id']}")
        print("\nSeeded Candidate IDs:")
        for candidate in candidates:
            print(f"- {candidate['name']}: {candidate['_id']}")

    except Exception as e:
        logger.error(f"Error seeding database: {e}")
        raise

if __name__ == "__main__":
    seed_database()