import streamlit as st
import os
import asyncio
import time
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from abc import ABC, abstractmethod
import PyPDF2
from io import BytesIO
import json
from dotenv import load_dotenv
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors

# LangChain imports
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain.output_parsers import PydanticOutputParser
from pydantic import BaseModel, Field

# Multi-agent framework
from langgraph.graph import StateGraph, END
from typing_extensions import TypedDict

load_dotenv()

class QuizQuestion(BaseModel):
    question: str = Field(description="The quiz question")
    options: List[str] = Field(description="Four multiple choice options")
    correct_answer: str = Field(description="The correct answer")
    explanation: str = Field(description="Brief explanation of the correct answer")
    key_point_source: str = Field(description="The key point this question is based on")

class StudySummary(BaseModel):
    key_points: List[str] = Field(description="List of key bullet points")
    topic: str = Field(description="Main topic or subject")
    complexity_level: str = Field(description="Complexity level: beginner, intermediate, or advanced")

class ProcessingResult(BaseModel):
    summary: StudySummary
    quiz_questions: List[QuizQuestion]
    content_length: int
    processing_status: str
    agent_workflow: List[str] = Field(description="List of agents that processed this content")

class StudyAssistantState(TypedDict):
    content: str
    source_type: str
    raw_content: Optional[str]
    summary: Optional[StudySummary]
    quiz_questions: Optional[List[QuizQuestion]]
    processing_status: str
    error_message: Optional[str]
    agent_workflow: List[str]

class RateLimiter:
    def __init__(self, calls_per_minute: int = 10):
        self.calls_per_minute = calls_per_minute
        self.calls = []
    
    async def wait_if_needed(self):
        now = time.time()
        self.calls = [call_time for call_time in self.calls if now - call_time < 60]
        
        if len(self.calls) >= self.calls_per_minute:
            wait_time = 60 - (now - self.calls[0]) + 1
            if wait_time > 0:
                st.info(f"Rate limiting: waiting {wait_time:.1f} seconds...")
                await asyncio.sleep(wait_time)
                now = time.time()
                self.calls = [call_time for call_time in self.calls if now - call_time < 60]
        
        self.calls.append(now)

class BaseAgent(ABC):
    def __init__(self, name: str, llm: ChatGoogleGenerativeAI, rate_limiter: RateLimiter):
        self.name = name
        self.llm = llm
        self.rate_limiter = rate_limiter
    
    @abstractmethod
    async def process(self, state: StudyAssistantState) -> StudyAssistantState:
        pass

class ContentLoaderAgent(BaseAgent):
    def __init__(self, llm: ChatGoogleGenerativeAI, rate_limiter: RateLimiter):
        super().__init__("ContentLoader", llm, rate_limiter)
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=2000, chunk_overlap=200, length_function=len,
            separators=["\n\n", "\n", ". ", " ", ""]
        )
    
    def load_pdf_content(self, pdf_file) -> str:
        try:
            pdf_reader = PyPDF2.PdfReader(pdf_file)
            content = ""
            for page in pdf_reader.pages:
                content += page.extract_text() + "\n"
            return content.strip()
        except Exception as e:
            raise Exception(f"Error loading PDF: {str(e)}")
    
    async def process(self, state: StudyAssistantState) -> StudyAssistantState:
        try:
            if state["source_type"].lower() == "pdf":
                content = self.load_pdf_content(state["content"])
            else:
                content = state["content"].strip()
            
            if not content:
                raise ValueError("No content found in the provided source")
            
            if len(content) > 8000:
                content = content[:8000] + "..."
                st.warning("Content truncated to 8,000 characters to stay within API limits")
            
            state["raw_content"] = content
            state["content"] = content
            state["processing_status"] = "content_loaded"
            state["agent_workflow"].append(self.name)
            
        except Exception as e:
            state["processing_status"] = "failed"
            state["error_message"] = f"Content loading failed: {str(e)}"
        
        return state

class SummarizationAgent(BaseAgent):
    def __init__(self, llm: ChatGoogleGenerativeAI, rate_limiter: RateLimiter):
        super().__init__("Summarizer", llm, rate_limiter)
        self.parser = PydanticOutputParser(pydantic_object=StudySummary)
        self.prompt_template = PromptTemplate(
            input_variables=["content"],
            template="""
            You are an expert educational content analyst. Analyze the following study material and create a comprehensive summary.
            
            Instructions:
            1. Identify the main topic and subject area
            2. Extract 5-8 key points that cover the most important concepts
            3. Each key point should be substantial enough to generate a meaningful quiz question
            4. Assess the complexity level of the material
            5. Focus on concepts that students need to understand and remember
            
            Study Material:
            {content}
            
            {format_instructions}
            
            Keep the summary concise but comprehensive.
            """,
            partial_variables={"format_instructions": self.parser.get_format_instructions()}
        )
    
    async def process(self, state: StudyAssistantState) -> StudyAssistantState:
        try:
            await self.rate_limiter.wait_if_needed()
            chain = LLMChain(llm=self.llm, prompt=self.prompt_template)
            result = await chain.arun(content=state["content"])
            summary = self.parser.parse(result)
            
            state["summary"] = summary
            state["processing_status"] = "summarized"
            state["agent_workflow"].append(self.name)
            
        except Exception as e:
            state["processing_status"] = "failed"
            state["error_message"] = f"Summarization failed: {str(e)}"
        
        return state

class QuizGenerationAgent(BaseAgent):
    def __init__(self, llm: ChatGoogleGenerativeAI, rate_limiter: RateLimiter):
        super().__init__("QuizGenerator", llm, rate_limiter)
        self.parser = PydanticOutputParser(pydantic_object=QuizQuestion)
        self.prompt_template = PromptTemplate(
            input_variables=["key_point", "topic", "complexity_level"],
            template="""
            You are an expert educational assessment creator. Create a high-quality multiple-choice question based on the given key point.
            
            Topic: {topic}
            Complexity Level: {complexity_level}
            Key Point to Focus On: {key_point}
            
            Instructions:
            1. Create a question that tests understanding
            2. Make sure the question is directly related to the key point
            3. Provide four plausible options with only one correct answer
            4. Ensure distractors are believable but clearly incorrect
            5. Include a brief explanation of why the correct answer is right
            6. Match the complexity level of the material
            
            {format_instructions}
            
            Keep the question clear and concise.
            """,
            partial_variables={"format_instructions": self.parser.get_format_instructions()}
        )
    
    async def generate_question_for_point(self, key_point: str, topic: str, complexity_level: str) -> QuizQuestion:
        await self.rate_limiter.wait_if_needed()
        chain = LLMChain(llm=self.llm, prompt=self.prompt_template)
        result = await chain.arun(key_point=key_point, topic=topic, complexity_level=complexity_level)
        question = self.parser.parse(result)
        question.key_point_source = key_point
        return question
    
    async def process(self, state: StudyAssistantState) -> StudyAssistantState:
        try:
            summary = state["summary"]
            if not summary or not summary.key_points:
                raise ValueError("No summary or key points available for quiz generation")
            
            quiz_questions = []
            key_points_to_process = summary.key_points[:5]
            
            for key_point in key_points_to_process:
                try:
                    question = await self.generate_question_for_point(
                        key_point=key_point, topic=summary.topic, complexity_level=summary.complexity_level
                    )
                    quiz_questions.append(question)
                except Exception as e:
                    st.warning(f"Failed to generate question for key point: {key_point[:50]}...")
                    continue
            
            if not quiz_questions:
                raise ValueError("No quiz questions could be generated")
            
            state["quiz_questions"] = quiz_questions
            state["processing_status"] = "completed"
            state["agent_workflow"].append(self.name)
            
        except Exception as e:
            state["processing_status"] = "failed"
            state["error_message"] = f"Quiz generation failed: {str(e)}"
        
        return state

class QualityAssuranceAgent(BaseAgent):
    def __init__(self, llm: ChatGoogleGenerativeAI, rate_limiter: RateLimiter):
        super().__init__("QualityAssurance", llm, rate_limiter)
    
    async def process(self, state: StudyAssistantState) -> StudyAssistantState:
        try:
            summary = state["summary"]
            questions = state["quiz_questions"]
            
            quality_issues = []
            
            if len(summary.key_points) < 2:
                quality_issues.append("Summary has too few key points")
            
            valid_questions = []
            for question in questions:
                if (len(question.options) == 4 and 
                    question.correct_answer in question.options and
                    len(question.question) > 10 and
                    len(question.explanation) > 10):
                    valid_questions.append(question)
                else:
                    quality_issues.append(f"Invalid question detected")
            
            state["quiz_questions"] = valid_questions
            
            if quality_issues:
                st.info(f"Quality issues detected and handled: {len(quality_issues)} issues")
            
            state["processing_status"] = "quality_assured"
            state["agent_workflow"].append(self.name)
            
        except Exception as e:
            state["processing_status"] = "failed"
            state["error_message"] = f"Quality assurance failed: {str(e)}"
        
        return state

class PDFGenerator:
    @staticmethod
    def create_study_pdf(results: ProcessingResult) -> bytes:
        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=18)
        
        styles = getSampleStyleSheet()
        title_style = ParagraphStyle('CustomTitle', parent=styles['Title'], fontSize=20, spaceAfter=30)
        heading_style = ParagraphStyle('CustomHeading', parent=styles['Heading1'], fontSize=16, spaceAfter=12)
        normal_style = styles['Normal']
        
        story = []
        
        # Title
        story.append(Paragraph(f"Study Summary: {results.summary.topic}", title_style))
        story.append(Spacer(1, 12))
        
        # Summary information
        story.append(Paragraph("Study Information", heading_style))
        info_data = [
            ['Topic:', results.summary.topic],
            ['Complexity Level:', results.summary.complexity_level.title()],
            ['Content Length:', f"{results.content_length:,} characters"],
            ['Questions Generated:', str(len(results.quiz_questions))]
        ]
        info_table = Table(info_data, colWidths=[2*inch, 4*inch])
        info_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
            ('BACKGROUND', (1, 0), (1, -1), colors.beige),
        ]))
        story.append(info_table)
        story.append(Spacer(1, 20))
        
        # Key Points
        story.append(Paragraph("Key Points", heading_style))
        for i, point in enumerate(results.summary.key_points, 1):
            story.append(Paragraph(f"{i}. {point}", normal_style))
            story.append(Spacer(1, 6))
        story.append(Spacer(1, 20))
        
        # Quiz Questions
        story.append(Paragraph("Quiz Questions", heading_style))
        for i, question in enumerate(results.quiz_questions, 1):
            story.append(Paragraph(f"Question {i}: {question.question}", ParagraphStyle('Question', parent=normal_style, fontName='Helvetica-Bold')))
            story.append(Spacer(1, 6))
            
            for j, option in enumerate(question.options, 1):
                prefix = "✓" if option == question.correct_answer else "  "
                story.append(Paragraph(f"{prefix} {chr(96+j)}) {option}", normal_style))
            
            story.append(Spacer(1, 6))
            story.append(Paragraph(f"Explanation: {question.explanation}", ParagraphStyle('Explanation', parent=normal_style, fontName='Helvetica-Oblique')))
            story.append(Spacer(1, 12))
        
        doc.build(story)
        buffer.seek(0)
        return buffer.getvalue()

class MultiAgentStudyAssistant:
    def __init__(self):
        google_api_key = os.getenv("GOOGLE_API_KEY")
        if not google_api_key:
            st.error("Google API Key not found! Please add GOOGLE_API_KEY to your .env file")
            st.stop()
        
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash", temperature=0.3, google_api_key=google_api_key
        )
        
        self.rate_limiter = RateLimiter(calls_per_minute=8)
        self.content_loader = ContentLoaderAgent(self.llm, self.rate_limiter)
        self.summarizer = SummarizationAgent(self.llm, self.rate_limiter)
        self.quiz_generator = QuizGenerationAgent(self.llm, self.rate_limiter)
        self.quality_assurance = QualityAssuranceAgent(self.llm, self.rate_limiter)
        self.workflow = self._build_workflow()
    
    def _build_workflow(self) -> StateGraph:
        workflow = StateGraph(StudyAssistantState)
        workflow.add_node("content_loader", self.content_loader.process)
        workflow.add_node("summarizer", self.summarizer.process)
        workflow.add_node("quiz_generator", self.quiz_generator.process)
        workflow.add_node("quality_assurance", self.quality_assurance.process)
        
        workflow.add_edge("content_loader", "summarizer")
        workflow.add_edge("summarizer", "quiz_generator")
        workflow.add_edge("quiz_generator", "quality_assurance")
        workflow.add_edge("quality_assurance", END)
        workflow.set_entry_point("content_loader")
        
        return workflow.compile()
    
    async def process_study_material(self, input_source: str, source_type: str = "text") -> ProcessingResult:
        initial_state = StudyAssistantState(
            content=input_source, source_type=source_type, raw_content=None,
            summary=None, quiz_questions=None, processing_status="initialized",
            error_message=None, agent_workflow=[]
        )
        
        try:
            final_state = await self.workflow.ainvoke(initial_state)
            
            if final_state["processing_status"] == "failed":
                raise Exception(final_state.get("error_message", "Unknown error occurred"))
            
            return ProcessingResult(
                summary=final_state["summary"], quiz_questions=final_state["quiz_questions"],
                content_length=len(final_state["raw_content"]), processing_status=final_state["processing_status"],
                agent_workflow=final_state["agent_workflow"]
            )
            
        except Exception as e:
            return ProcessingResult(
                summary=StudySummary(key_points=[], topic="Error", complexity_level="unknown"),
                quiz_questions=[], content_length=0, processing_status="failed", agent_workflow=initial_state["agent_workflow"]
            )

def main():
    st.set_page_config(
        page_title="Multi-Agent Study Assistant", page_icon="🎓",
        layout="wide", initial_sidebar_state="expanded"
    )
    
    st.markdown("""
    <style>
    .main-header {
        font-size: 2.5rem; font-weight: bold; text-align: center;
        background: linear-gradient(90deg, #FF6B6B, #4ECDC4, #45B7D1);
        -webkit-background-clip: text; -webkit-text-fill-color: transparent;
        margin-bottom: 2rem;
    }
    .stat-box {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1rem; border-radius: 10px; text-align: center;
        color: white; min-width: 150px;
    }
    .question-box {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        padding: 1.5rem; border-radius: 10px; margin: 1rem 0;
        border-left: 5px solid #0066cc;
    }
    .correct-answer {
        background-color: #d4edda; color: #155724;
        padding: 0.5rem; border-radius: 5px; font-weight: bold;
    }
    </style>
    """, unsafe_allow_html=True)
    
    st.markdown('<h1 class="main-header">Multi-Agent Study Assistant</h1>', unsafe_allow_html=True)
    st.markdown('<p style="text-align: center; font-size: 1.2rem; color: #666;">Powered by Google Gemini Flash & LangChain Multi-Agent System</p>', unsafe_allow_html=True)
    
    with st.sidebar:
        st.header("Input Options")
        input_method = st.radio("Choose input method:", ["Text Input", "PDF Upload"], index=0)
        st.markdown("---")
        
        google_api_key = os.getenv("GOOGLE_API_KEY")
        if google_api_key:
            st.success("Google API Key loaded from .env")
        else:
            st.error("Google API Key not found in .env file")
            st.info("Add GOOGLE_API_KEY=your_key_here to your .env file")
        
        st.markdown("---")
        st.subheader("Instructions")
        st.write("""
        1. Choose your input method (Text or PDF)
        2. Provide your study material (max 8,000 characters)
        3. Click 'Generate Study Assistant'
        4. Review the AI-generated summary and quiz questions
        """)
        
        st.markdown("---")
        st.subheader("Multi-Agent Pipeline")
        st.write("ContentLoader → Summarizer → QuizGenerator → QualityAssurance")
        
        st.markdown("---")
        st.subheader("Rate Limiting")
        st.write("Max 8 API calls per minute with automatic waiting when limits approached")
    
    content_input = None
    source_type = "text"
    
    if input_method == "Text Input":
        st.subheader("Enter Your Study Material")
        content_input = st.text_area(
            "Paste your study content here:", height=300, max_chars=8000,
            placeholder="Enter your study material, lecture notes, or any educational content here...",
            help="Provide detailed study material for best results. Limited to 8,000 characters."
        )
        
        if content_input:
            char_count = len(content_input)
            if char_count > 7000:
                st.warning(f"Character count: {char_count}/8000 - Approaching limit!")
            else:
                st.info(f"Character count: {char_count}/8000")
        
    elif input_method == "PDF Upload":
        st.subheader("Upload Your PDF Document")
        uploaded_file = st.file_uploader(
            "Choose a PDF file", type=["pdf"],
            help="Upload a PDF document containing your study material"
        )
        
        if uploaded_file is not None:
            content_input = uploaded_file
            source_type = "pdf"
            st.info(f"File uploaded: {uploaded_file.name} ({uploaded_file.size} bytes)")
            st.warning("PDF content will be truncated to 8,000 characters if needed")
    
    if st.button("Generate Study Assistant", type="primary", use_container_width=True):
        if not content_input:
            st.error("Please provide study material (text or PDF) to continue.")
            return
        
        if not google_api_key:
            st.error("Google API Key not found. Please check your .env file.")
            return
        
        with st.spinner("Initializing Multi-Agent System..."):
            try:
                assistant = MultiAgentStudyAssistant()
            except Exception as e:
                st.error(f"Failed to initialize assistant: {str(e)}")
                return
        
        with st.spinner("Multi-Agent Pipeline Processing..."):
            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                results = loop.run_until_complete(
                    assistant.process_study_material(content_input, source_type)
                )
                loop.close()
                
            except Exception as e:
                st.error(f"Processing failed: {str(e)}")
                st.info("If you encountered a quota error, please wait a few minutes and try again.")
                return
        
        if results.processing_status == "failed":
            st.error("Processing failed. Please try again with different content or wait for rate limits to reset.")
            return
        
        st.success("Multi-Agent Processing Complete!")
        
        # Statistics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.markdown(f'<div class="stat-box"><h3>{len(results.summary.key_points)}</h3><p>Key Points</p></div>', unsafe_allow_html=True)
        with col2:
            st.markdown(f'<div class="stat-box"><h3>{len(results.quiz_questions)}</h3><p>Quiz Questions</p></div>', unsafe_allow_html=True)
        with col3:
            st.markdown(f'<div class="stat-box"><h3>{results.summary.complexity_level.title()}</h3><p>Complexity</p></div>', unsafe_allow_html=True)
        with col4:
            st.markdown(f'<div class="stat-box"><h3>{results.content_length:,}</h3><p>Characters</p></div>', unsafe_allow_html=True)
        
        # Summary Section
        st.markdown("---")
        st.subheader(f"Study Summary: {results.summary.topic}")
        st.write(f"**Complexity Level:** {results.summary.complexity_level.title()}")
        
        st.subheader("Key Points")
        for i, point in enumerate(results.summary.key_points, 1):
            st.write(f"**{i}.** {point}")
        
        # Quiz Section
        st.markdown("---")
        st.subheader(f"Generated Quiz Questions ({len(results.quiz_questions)} Questions)")
        
        for i, question in enumerate(results.quiz_questions, 1):
            with st.container():
                st.markdown(f'<div class="question-box"><h4>Question {i}: {question.question}</h4></div>', unsafe_allow_html=True)
                
                for j, option in enumerate(question.options, 1):
                    if option == question.correct_answer:
                        st.markdown(f'<div class="correct-answer">✓ {chr(96+j)}) {option}</div>', unsafe_allow_html=True)
                    else:
                        st.write(f"   {chr(96+j)}) {option}")
                
                st.info(f"**Explanation:** {question.explanation}")
                st.markdown("---")
        
        # Download options
        st.subheader("Download Results")
        
        download_data = {
            "topic": results.summary.topic,
            "complexity_level": results.summary.complexity_level,
            "key_points": results.summary.key_points,
            "quiz_questions": [
                {
                    "question": q.question, "options": q.options, "correct_answer": q.correct_answer,
                    "explanation": q.explanation, "key_point_source": q.key_point_source
                }
                for q in results.quiz_questions
            ]
        }
        
        col1, col2 = st.columns(2)
        
        with col1:
            json_data = json.dumps(download_data, indent=2)
            st.download_button(
                label="Download as JSON", data=json_data,
                file_name=f"study_assistant_{results.summary.topic.replace(' ', '_').lower()}.json",
                mime="application/json"
            )
        
        with col2:
            try:
                pdf_data = PDFGenerator.create_study_pdf(results)
                st.download_button(
                    label="Download as PDF", data=pdf_data,
                    file_name=f"study_assistant_{results.summary.topic.replace(' ', '_').lower()}.pdf",
                    mime="application/pdf"
                )
            except Exception as e:
                st.error(f"PDF generation failed: {str(e)}")

if __name__ == "__main__":
    main()