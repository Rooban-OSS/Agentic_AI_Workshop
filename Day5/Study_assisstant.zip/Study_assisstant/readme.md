# Multi-Agent Study Assistant

This project is a Streamlit web application that uses a multi-agent system powered by Google Gemini Flash and LangChain to analyze study materials (text or PDF), generate concise summaries, and create high-quality quiz questions. The results can be downloaded as JSON or PDF.

## Features

- **Text or PDF Input:** Paste study material or upload a PDF.
- **Automated Summarization:** Extracts key points and assesses complexity.
- **Quiz Generation:** Creates multiple-choice questions with explanations.
- **Quality Assurance:** Ensures the quality of generated questions.
- **Download Results:** Export your summary and quiz as JSON or PDF.
- **Rate Limiting:** Prevents exceeding API quotas.

## Getting Started

### Prerequisites

- Python 3.8+
- [Streamlit](https://streamlit.io/)
- [LangChain](https://python.langchain.com/)
- [Google Gemini API access](https://ai.google.dev/)
- Other dependencies: `PyPDF2`, `reportlab`, `python-dotenv`, `pydantic`, etc.

Install dependencies:
```sh
pip install -r requirements.txt
```

### .env File

Create a `.env` file in the project root with your Google API key:

```properties
GOOGLE_API_KEY=AIzaSyBJJ95LHa-ccWjsLHI0yMPVaYayG7N0UDI
```

> **Note:** Replace the value with your own Google API key if needed.

### Running the App

Start the Streamlit app:

```sh
streamlit run main.py
```

## Usage

1. Choose your input method (Text or PDF) in the sidebar.
2. Provide your study material (max 8,000 characters).
3. Click **Generate Study Assistant**.
4. Review the AI-generated summary and quiz questions.
5. Download the results as JSON or PDF.

## Project Structure

- [`main.py`](main.py): Main Streamlit application and multi-agent logic.
- `.env`: Environment variables (API keys).

## Environment Variables

| Variable         | Description                |
|------------------|---------------------------|
| `GOOGLE_API_KEY` | Your Google Gemini API key|

## License

This project is for educational purposes.

---

**Powered by Google Gemini Flash & LangChain Multi-Agent System**