from pymongo import MongoClient

from dotenv import load_dotenv
import os

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

client = MongoClient("mongodb+srv://roobanrihub:thisisthepassword@cluster0.rxkm1vt.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
db = client["interview_panel_optimizer"]

jobs_collection = db["jobs"]
interviewers_collection = db["interviewers"]
candidates_collection = db["candidates"]
panels_collection = db["panels"]
