from pydantic import BaseModel, EmailStr, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum

class ExperienceLevel(str, Enum):
    JUNIOR = "junior"
    MID = "mid"
    SENIOR = "senior"
    LEAD = "lead"
    PRINCIPAL = "principal"

class InterviewerType(str, Enum):
    TECHNICAL = "technical"
    BEHAVIORAL = "behavioral"
    DOMAIN_EXPERT = "domain_expert"
    HR = "hr"
    MANAGER = "manager"

class Job(BaseModel):
    job_role: str
    job_description: str
    required_skills: List[str]
    experience_level: ExperienceLevel
    special_requirements: Optional[str] = None
    department: str
    interviewer_types_needed: List[InterviewerType] = Field(
        default=[InterviewerType.TECHNICAL, InterviewerType.BEHAVIORAL]
    )

class Interviewer(BaseModel):
    name: str
    email: EmailStr
    department: str
    skills: List[str]
    gender: str
    race: str
    availability: List[Dict[str, Any]]  # [{from: datetime, to: datetime}]
    past_feedback_score: float = Field(ge=0.0, le=5.0)
    past_companies: List[str]
    experience_level: ExperienceLevel
    interviewer_type: InterviewerType
    total_interviews_conducted: int = 0
    average_interview_rating: float = Field(default=0.0, ge=0.0, le=5.0)
    specializations: List[str] = Field(default_factory=list)
    years_of_experience: int = Field(ge=0)

class Candidate(BaseModel):
    name: str
    email: EmailStr
    job_role: str
    skills: List[str]
    previous_companies: List[str]
    experience_level: ExperienceLevel
    current_company: Optional[str] = None
    linkedin_profile: Optional[str] = None
    resume_summary: Optional[str] = None

class PanelMember(BaseModel):
    interviewer_id: str
    name: str
    match_score: float
    conflict_status: bool
    diversity_contribution: float
    role_in_panel: InterviewerType
    recommendation_reason: str

class Panel(BaseModel):
    candidate_id: str
    job_id: str
    panel_members: List[PanelMember]
    overall_diversity_score: float
    skill_coverage_score: float
    conflict_flags: List[Dict[str, Any]]
    panel_quality_score: float
    recommendations: List[str]
    created_at: datetime = Field(default_factory=datetime.now)

class PanelRecommendation(BaseModel):
    recommended_panel: List[PanelMember]
    diversity_analysis: Dict[str, Any]
    skill_coverage_analysis: Dict[str, Any]
    conflict_analysis: Dict[str, Any]
    quality_metrics: Dict[str, Any]
    alternative_suggestions: List[Dict[str, Any]]