from app.database import interviewers_collection, jobs_collection, candidates_collection, GEMINI_API_KEY
from app.models import InterviewerType, ExperienceLevel, PanelMember, PanelRecommendation
from bson import ObjectId
from langchain.llms import GooglePalm
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain_google_genai import GoogleGenerativeAI
import json
import re
from typing import List, Dict, Any, Tuple
from collections import Counter
import logging

# Initialize Gemini LLM
llm = GoogleGenerativeAI(model="gemini-1.5-flash", google_api_key=GEMINI_API_KEY)

# Enhanced skill matching with semantic understanding
def calculate_skill_match_score(required_skills: List[str], interviewer_skills: List[str], job_description: str = "") -> float:
    """Calculate skill match score using both exact matches and semantic similarity"""
    if not required_skills or not interviewer_skills:
        return 0.0
    
    # Exact match score
    exact_matches = len(set(required_skills).intersection(set(interviewer_skills)))
    exact_score = exact_matches / len(required_skills)
    
    # Semantic match using Gemini
    semantic_prompt = PromptTemplate(
        input_variables=["required_skills", "interviewer_skills", "job_description"],
        template="""
        Analyze the skill match between required skills and interviewer skills for this job:
        
        Job Description: {job_description}
        Required Skills: {required_skills}
        Interviewer Skills: {interviewer_skills}
        
        Consider:
        1. Direct skill matches
        2. Related/transferable skills
        3. Skill hierarchy (senior skills covering junior requirements)
        4. Domain expertise overlap
        
        Return a JSON with:
        {{
            "semantic_match_score": float (0.0 to 1.0),
            "matching_skills": [list of matching skills],
            "transferable_skills": [list of transferable skills],
            "skill_gaps": [list of missing skills]
        }}
        """
    )
    
    try:
        chain = LLMChain(llm=llm, prompt=semantic_prompt)
        result = chain.run(
            required_skills=", ".join(required_skills),
            interviewer_skills=", ".join(interviewer_skills),
            job_description=job_description
        )
        
        # Parse JSON response
        semantic_data = json.loads(result.strip())
        semantic_score = semantic_data.get("semantic_match_score", 0.0)
        
        # Weighted combination of exact and semantic scores
        final_score = (exact_score * 0.4) + (semantic_score * 0.6)
        return min(final_score, 1.0)
    
    except Exception as e:
        logging.error(f"Error in semantic skill matching: {e}")
        return exact_score

def calculate_comprehensive_diversity_score(panel_members: List[Dict]) -> Dict[str, Any]:
    """Calculate comprehensive diversity metrics"""
    if not panel_members:
        return {"overall_score": 0.0, "breakdown": {}}
    
    total_members = len(panel_members)
    
    # Gender diversity
    genders = [member.get('gender', 'unknown') for member in panel_members]
    gender_counts = Counter(genders)
    gender_diversity = 1 - sum((count/total_members)**2 for count in gender_counts.values())
    
    # Racial diversity
    races = [member.get('race', 'unknown') for member in panel_members]
    race_counts = Counter(races)
    race_diversity = 1 - sum((count/total_members)**2 for count in race_counts.values())
    
    # Experience level diversity
    exp_levels = [member.get('experience_level', 'unknown') for member in panel_members]
    exp_counts = Counter(exp_levels)
    exp_diversity = 1 - sum((count/total_members)**2 for count in exp_counts.values())
    
    # Department diversity
    departments = [member.get('department', 'unknown') for member in panel_members]
    dept_counts = Counter(departments)
    dept_diversity = 1 - sum((count/total_members)**2 for count in dept_counts.values())
    
    # Company background diversity
    all_companies = []
    for member in panel_members:
        all_companies.extend(member.get('past_companies', []))
    company_counts = Counter(all_companies)
    company_diversity = 1 - sum((count/len(all_companies))**2 for count in company_counts.values()) if all_companies else 0
    
    # Overall diversity score (weighted average)
    overall_score = (
        gender_diversity * 0.25 +
        race_diversity * 0.25 +
        exp_diversity * 0.20 +
        dept_diversity * 0.15 +
        company_diversity * 0.15
    )
    
    return {
        "overall_score": round(overall_score, 3),
        "breakdown": {
            "gender_diversity": round(gender_diversity, 3),
            "race_diversity": round(race_diversity, 3),
            "experience_diversity": round(exp_diversity, 3),
            "department_diversity": round(dept_diversity, 3),
            "company_diversity": round(company_diversity, 3)
        },
        "representation": {
            "gender_distribution": dict(gender_counts),
            "race_distribution": dict(race_counts),
            "experience_distribution": dict(exp_counts),
            "department_distribution": dict(dept_counts)
        }
    }

def detect_conflicts_of_interest(candidate: Dict, interviewer: Dict) -> Dict[str, Any]:
    """Enhanced conflict detection with detailed analysis"""
    conflicts = []
    
    # Company overlap
    candidate_companies = set(candidate.get('previous_companies', []))
    if candidate.get('current_company'):
        candidate_companies.add(candidate['current_company'])
    
    interviewer_companies = set(interviewer.get('past_companies', []))
    
    company_overlap = candidate_companies.intersection(interviewer_companies)
    if company_overlap:
        conflicts.append({
            "type": "company_overlap",
            "details": f"Shared companies: {', '.join(company_overlap)}",
            "severity": "high"
        })
    
    # Email domain check (same company)
    candidate_domain = candidate.get('email', '').split('@')[-1] if '@' in candidate.get('email', '') else ''
    interviewer_domain = interviewer.get('email', '').split('@')[-1] if '@' in interviewer.get('email', '') else ''
    
    if candidate_domain and interviewer_domain and candidate_domain == interviewer_domain:
        conflicts.append({
            "type": "same_organization",
            "details": f"Same email domain: {candidate_domain}",
            "severity": "medium"
        })
    
    # LinkedIn connection check (placeholder - would need LinkedIn API)
    # This could be enhanced with actual LinkedIn API integration
    
    return {
        "has_conflicts": len(conflicts) > 0,
        "conflicts": conflicts,
        "risk_level": "high" if any(c["severity"] == "high" for c in conflicts) else "medium" if conflicts else "low"
    }

def generate_panel_composition_strategy(job: Dict, candidate: Dict = None) -> Dict[str, Any]:
    """Generate optimal panel composition strategy using Gemini"""
    strategy_prompt = PromptTemplate(
        input_variables=["job_info", "candidate_info"],
        template="""
        As an expert in interview panel optimization, recommend the ideal panel composition for this role:
        
        Job Information:
        Role: {job_info}
        
        Candidate Information (if available):
        {candidate_info}
        
        Provide recommendations for:
        1. Panel size (3-5 members typically)
        2. Required interviewer types and their roles
        3. Experience level mix
        4. Diversity considerations
        5. Specific skills/expertise needed
        
        Return a JSON response with:
        {{
            "recommended_panel_size": int,
            "interviewer_types_needed": [
                {{
                    "type": "technical|behavioral|domain_expert|hr|manager",
                    "count": int,
                    "primary_focus": "description",
                    "required_skills": [list]
                }}
            ],
            "experience_level_mix": {{
                "senior": int,
                "mid": int,
                "junior": int
            }},
            "diversity_targets": {{
                "gender_balance": "description",
                "department_mix": "description",
                "background_diversity": "description"
            }},
            "special_considerations": [list of additional requirements]
        }}
        """
    )
    
    try:
        job_info = f"Role: {job.get('job_role', 'N/A')}, Department: {job.get('department', 'N/A')}, Required Skills: {', '.join(job.get('required_skills', []))}"
        candidate_info = f"Experience Level: {candidate.get('experience_level', 'N/A')}, Skills: {', '.join(candidate.get('skills', []))}" if candidate else "Not provided"
        
        chain = LLMChain(llm=llm, prompt=strategy_prompt)
        result = chain.run(job_info=job_info, candidate_info=candidate_info)
        
        return json.loads(result.strip())
    
    except Exception as e:
        logging.error(f"Error generating panel strategy: {e}")
        return {
            "recommended_panel_size": 3,
            "interviewer_types_needed": [
                {"type": "technical", "count": 1, "primary_focus": "Technical skills assessment", "required_skills": job.get('required_skills', [])},
                {"type": "behavioral", "count": 1, "primary_focus": "Soft skills and cultural fit", "required_skills": []},
                {"type": "manager", "count": 1, "primary_focus": "Leadership and strategic thinking", "required_skills": []}
            ],
            "experience_level_mix": {"senior": 2, "mid": 1, "junior": 0},
            "diversity_targets": {
                "gender_balance": "Aim for balanced representation",
                "department_mix": "Include cross-functional perspectives",
                "background_diversity": "Diverse company backgrounds"
            },
            "special_considerations": []
        }

def score_interviewer_quality(interviewer: Dict) -> float:
    """Calculate interviewer quality score based on past performance"""
    feedback_score = interviewer.get('past_feedback_score', 0.0) / 5.0  # Normalize to 0-1
    avg_rating = interviewer.get('average_interview_rating', 0.0) / 5.0  # Normalize to 0-1
    
    # Experience factor
    total_interviews = interviewer.get('total_interviews_conducted', 0)
    experience_factor = min(total_interviews / 50, 1.0)  # Cap at 50 interviews
    
    # Years of experience factor
    years_exp = interviewer.get('years_of_experience', 0)
    exp_factor = min(years_exp / 10, 1.0)  # Cap at 10 years
    
    quality_score = (
        feedback_score * 0.3 +
        avg_rating * 0.3 +
        experience_factor * 0.2 +
        exp_factor * 0.2
    )
    
    return round(quality_score, 3)

def recommend_interviewers_enhanced(entity_id: str, is_final: bool = False) -> PanelRecommendation:
    """Enhanced interviewer recommendation system"""
    try:
        if is_final:
            # Candidate-based final panel recommendation
            candidate = candidates_collection.find_one({"_id": ObjectId(entity_id)})
            if not candidate:
                raise ValueError("Candidate not found")
            
            job = jobs_collection.find_one({"job_role": candidate["job_role"]})
            if not job:
                raise ValueError("Job not found")
            
            # Generate panel strategy
            panel_strategy = generate_panel_composition_strategy(job, candidate)
            
        else:
            # Job-based initial recommendation
            job = jobs_collection.find_one({"_id": ObjectId(entity_id)})
            if not job:
                raise ValueError("Job not found")
            
            candidate = None
            panel_strategy = generate_panel_composition_strategy(job)
        
        # Get all available interviewers
        all_interviewers = list(interviewers_collection.find())
        
        # Score and filter interviewers
        scored_interviewers = []
        for interviewer in all_interviewers:
            # Calculate skill match
            skill_score = calculate_skill_match_score(
                job.get('required_skills', []),
                interviewer.get('skills', []),
                job.get('job_description', '')
            )
            
            # Calculate quality score
            quality_score = score_interviewer_quality(interviewer)
            
            # Check conflicts (only for final recommendations)
            conflict_info = detect_conflicts_of_interest(candidate, interviewer) if candidate else {"has_conflicts": False, "risk_level": "low"}
            
            # Overall interviewer score
            overall_score = (skill_score * 0.4) + (quality_score * 0.6)
            
            if overall_score >= 0.3:  # Minimum threshold
                scored_interviewers.append({
                    "interviewer": interviewer,
                    "skill_score": skill_score,
                    "quality_score": quality_score,
                    "overall_score": overall_score,
                    "conflict_info": conflict_info
                })
        
        # Sort by overall score
        scored_interviewers.sort(key=lambda x: x["overall_score"], reverse=True)
        
        # Select optimal panel based on strategy
        recommended_panel = select_optimal_panel(scored_interviewers, panel_strategy, is_final)
        
        # Calculate final metrics
        panel_members_data = [item["interviewer"] for item in recommended_panel]
        diversity_analysis = calculate_comprehensive_diversity_score(panel_members_data)
        
        # Create panel member objects
        panel_members = []
        for item in recommended_panel:
            interviewer = item["interviewer"]
            panel_member = PanelMember(
                interviewer_id=str(interviewer["_id"]),
                name=interviewer["name"],
                match_score=item["skill_score"],
                conflict_status=item["conflict_info"]["has_conflicts"],
                diversity_contribution=0.0,  # Would need complex calculation
                role_in_panel=interviewer.get("interviewer_type", InterviewerType.TECHNICAL),
                recommendation_reason=f"Strong skill match ({item['skill_score']:.2f}) and quality score ({item['quality_score']:.2f})"
            )
            panel_members.append(panel_member)
        
        return PanelRecommendation(
            recommended_panel=panel_members,
            diversity_analysis=diversity_analysis,
            skill_coverage_analysis=analyze_skill_coverage(panel_members_data, job.get('required_skills', [])),
            conflict_analysis=analyze_conflicts(recommended_panel),
            quality_metrics=calculate_panel_quality_metrics(recommended_panel),
            alternative_suggestions=generate_alternative_suggestions(scored_interviewers, recommended_panel)
        )
    
    except Exception as e:
        logging.error(f"Error in enhanced recommendation: {e}")
        raise

def select_optimal_panel(scored_interviewers: List[Dict], strategy: Dict, is_final: bool) -> List[Dict]:
    """Select optimal panel based on strategy and constraints"""
    panel_size = strategy.get("recommended_panel_size", 3)
    selected_panel = []
    
    # Filter out interviewers with conflicts for final panels
    if is_final:
        available_interviewers = [i for i in scored_interviewers if not i["conflict_info"]["has_conflicts"]]
    else:
        available_interviewers = scored_interviewers
    
    # Group by interviewer type
    by_type = {}
    for item in available_interviewers:
        interviewer_type = item["interviewer"].get("interviewer_type", InterviewerType.TECHNICAL)
        if interviewer_type not in by_type:
            by_type[interviewer_type] = []
        by_type[interviewer_type].append(item)
    
    # Select based on required types
    for type_req in strategy.get("interviewer_types_needed", []):
        type_name = type_req["type"]
        count_needed = type_req["count"]
        
        if type_name in by_type:
            # Sort by overall score and select top candidates
            candidates = sorted(by_type[type_name], key=lambda x: x["overall_score"], reverse=True)
            selected_panel.extend(candidates[:count_needed])
    
    # Fill remaining slots with best available candidates
    remaining_slots = panel_size - len(selected_panel)
    if remaining_slots > 0:
        # Get candidates not already selected
        selected_ids = {item["interviewer"]["_id"] for item in selected_panel}
        remaining_candidates = [
            item for item in available_interviewers 
            if item["interviewer"]["_id"] not in selected_ids
        ]
        
        # Sort by overall score and select top candidates
        remaining_candidates.sort(key=lambda x: x["overall_score"], reverse=True)
        selected_panel.extend(remaining_candidates[:remaining_slots])
    
    return selected_panel[:panel_size]

def analyze_skill_coverage(panel_members: List[Dict], required_skills: List[str]) -> Dict[str, Any]:
    """Analyze how well the panel covers required skills"""
    if not required_skills:
        return {"coverage_score": 1.0, "covered_skills": [], "missing_skills": []}
    
    all_panel_skills = set()
    for member in panel_members:
        all_panel_skills.update(member.get("skills", []))
    
    covered_skills = list(set(required_skills).intersection(all_panel_skills))
    missing_skills = list(set(required_skills) - all_panel_skills)
    
    coverage_score = len(covered_skills) / len(required_skills)
    
    return {
        "coverage_score": round(coverage_score, 3),
        "covered_skills": covered_skills,
        "missing_skills": missing_skills,
        "skill_redundancy": len(all_panel_skills) / len(set(all_panel_skills)) if all_panel_skills else 1.0
    }

def analyze_conflicts(panel_selections: List[Dict]) -> Dict[str, Any]:
    """Analyze conflicts in the selected panel"""
    conflicts = []
    high_risk_count = 0
    
    for item in panel_selections:
        conflict_info = item["conflict_info"]
        if conflict_info["has_conflicts"]:
            conflicts.extend(conflict_info["conflicts"])
            if conflict_info["risk_level"] == "high":
                high_risk_count += 1
    
    return {
        "total_conflicts": len(conflicts),
        "high_risk_conflicts": high_risk_count,
        "conflict_details": conflicts,
        "overall_risk": "high" if high_risk_count > 0 else "medium" if conflicts else "low"
    }

def calculate_panel_quality_metrics(panel_selections: List[Dict]) -> Dict[str, Any]:
    """Calculate overall panel quality metrics"""
    if not panel_selections:
        return {"overall_quality": 0.0}
    
    avg_skill_score = sum(item["skill_score"] for item in panel_selections) / len(panel_selections)
    avg_quality_score = sum(item["quality_score"] for item in panel_selections) / len(panel_selections)
    avg_overall_score = sum(item["overall_score"] for item in panel_selections) / len(panel_selections)
    
    return {
        "overall_quality": round(avg_overall_score, 3),
        "average_skill_match": round(avg_skill_score, 3),
        "average_interviewer_quality": round(avg_quality_score, 3),
        "panel_size": len(panel_selections),
        "quality_rating": "excellent" if avg_overall_score >= 0.8 else "good" if avg_overall_score >= 0.6 else "fair"
    }

def generate_alternative_suggestions(all_interviewers: List[Dict], selected_panel: List[Dict]) -> List[Dict[str, Any]]:
    """Generate alternative panel suggestions"""
    selected_ids = {item["interviewer"]["_id"] for item in selected_panel}
    alternatives = [
        item for item in all_interviewers 
        if item["interviewer"]["_id"] not in selected_ids and item["overall_score"] >= 0.4
    ]
    
    alternatives.sort(key=lambda x: x["overall_score"], reverse=True)
    
    suggestions = []
    for alt in alternatives[:3]:  # Top 3 alternatives
        suggestions.append({
            "interviewer_id": str(alt["interviewer"]["_id"]),
            "name": alt["interviewer"]["name"],
            "overall_score": alt["overall_score"],
            "reason": f"Alternative with score {alt['overall_score']:.2f}, strong in {', '.join(alt['interviewer'].get('skills', [])[:3])}"
        })
    
    return suggestions

# Legacy function for backward compatibility
def recommend_interviewers(entity_id: str, is_final: bool = False) -> Dict[str, Any]:
    """Legacy function wrapper for backward compatibility"""
    try:
        enhanced_recommendation = recommend_interviewers_enhanced(entity_id, is_final)
        
        # Convert to legacy format
        if is_final:
            return {
                "panel": [
                    {
                        "interviewer_id": member.interviewer_id,
                        "name": member.name,
                        "match_score": member.match_score,
                        "conflict": member.conflict_status
                    }
                    for member in enhanced_recommendation.recommended_panel
                ],
                "diversity_score": enhanced_recommendation.diversity_analysis["overall_score"]
            }
        else:
            return {
                "recommended_panel": [
                    {
                        "interviewer_id": member.interviewer_id,
                        "name": member.name,
                        "match_score": member.match_score
                    }
                    for member in enhanced_recommendation.recommended_panel
                ],
                "diversity_score": enhanced_recommendation.diversity_analysis["overall_score"]
            }
    
    except Exception as e:
        logging.error(f"Error in legacy recommendation wrapper: {e}")
        return {
            "recommended_panel" if not is_final else "panel": [],
            "diversity_score": 0.0,
            "error": str(e)
        }