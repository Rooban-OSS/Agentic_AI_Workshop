import streamlit as st
import requests
import pandas as pd
import json
from datetime import datetime
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# API Base URL
API_BASE_URL = "http://localhost:8000"  # Update with your API's actual URL

# Helper function to make API calls
def make_api_call(endpoint, method="GET", data=None):
    try:
        url = f"{API_BASE_URL}{endpoint}"
        headers = {"Content-Type": "application/json"}
        
        if method == "GET":
            response = requests.get(url)
        elif method == "POST":
            response = requests.post(url, json=data, headers=headers)
        elif method == "PUT":
            response = requests.put(url, json=data, headers=headers)
        
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        logger.error(f"API call failed: {e}")
        st.error(f"Error: {str(e)}")
        return None

# Streamlit App
st.set_page_config(page_title="Interview Panel Optimizer", layout="wide")

st.title("Interview Panel Optimizer")
st.markdown("""
AI-powered interview panel optimization with DEI compliance and conflict detection.
""")

# Sidebar for navigation
st.sidebar.title("Navigation")
page = st.sidebar.radio("Go to", [
    "Home",
    "Manage Jobs",
    "Manage Interviewers",
    "Manage Candidates",
    "Panel Recommendations",
    "Analytics"
])

# Home Page
if page == "Home":
    st.header("Welcome to Interview Panel Optimizer")
    health = make_api_call("/health")
    if health:
        st.write(f"System Status: {health['status']}")
        st.write(f"Database: {health['database']}")
        st.write(f"Version: {health['version']}")
        st.write("Features Active:")
        for feature in health.get('features_active', []):
            st.write(f"- {feature}")

# Manage Jobs
elif page == "Manage Jobs":
    st.header("Manage Jobs")
    
    # Create Job
    with st.form("create_job_form"):
        st.subheader("Create New Job")
        job_role = st.text_input("Job Role")
        job_description = st.text_area("Job Description")
        required_skills = st.text_input("Required Skills (comma-separated)")
        experience_level = st.selectbox("Experience Level", ["junior", "mid", "senior", "lead", "principal"])
        department = st.text_input("Department")
        special_requirements = st.text_area("Special Requirements (Optional)")
        interviewer_types = st.multiselect("Interviewer Types Needed", ["technical", "behavioral", "domain_expert", "hr", "manager"])
        submit_job = st.form_submit_button("Create Job")
        
        if submit_job:
            job_data = {
                "job_role": job_role,
                "job_description": job_description,
                "required_skills": [skill.strip() for skill in required_skills.split(",")],
                "experience_level": experience_level,
                "department": department,
                "special_requirements": special_requirements,
                "interviewer_types_needed": interviewer_types
            }
            result = make_api_call("/job/create", method="POST", data=job_data)
            if result:
                st.success(f"Job created successfully! Job ID: {result['job_id']}")
    
    # List Jobs
    st.subheader("Existing Jobs")
    skip = st.number_input("Skip", min_value=0, value=0)
    limit = st.number_input("Limit", min_value=1, max_value=100, value=10)
    if st.button("List Jobs"):
        jobs_data = make_api_call(f"/jobs?skip={skip}&limit={limit}")
        if jobs_data and jobs_data["jobs"]:
            df = pd.DataFrame(jobs_data["jobs"])
            st.dataframe(df[["_id", "job_role", "department", "experience_level", "status"]])
        else:
            st.warning("No jobs found.")

# Manage Interviewers
elif page == "Manage Interviewers":
    st.header("Manage Interviewers")
    
    # Add Interviewer
    with st.form("add_interviewer_form"):
        st.subheader("Add New Interviewer")
        name = st.text_input("Name")
        email = st.text_input("Email")
        department = st.text_input("Department")
        skills = st.text_input("Skills (comma-separated)")
        gender = st.text_input("Gender")
        race = st.text_input("Race")
        availability = st.text_area("Availability (JSON format, e.g., [{'from': '2025-06-16T09:00:00', 'to': '2025-06-16T17:00:00'}])")
        past_feedback_score = st.number_input("Past Feedback Score", min_value=0.0, max_value=5.0, value=0.0)
        past_companies = st.text_input("Past Companies (comma-separated)")
        experience_level = st.selectbox("Experience Level", ["junior", "mid", "senior", "lead", "principal"])
        interviewer_type = st.selectbox("Interviewer Type", ["technical", "behavioral", "domain_expert", "hr", "manager"])
        years_of_experience = st.number_input("Years of Experience", min_value=0, value=0)
        submit_interviewer = st.form_submit_button("Add Interviewer")
        
        if submit_interviewer:
            try:
                availability_list = json.loads(availability)
                interviewer_data = {
                    "name": name,
                    "email": email,
                    "department": department,
                    "skills": [skill.strip() for skill in skills.split(",")],
                    "gender": gender,
                    "race": race,
                    "availability": availability_list,
                    "past_feedback_score": past_feedback_score,
                    "past_companies": [company.strip() for company in past_companies.split(",")],
                    "experience_level": experience_level,
                    "interviewer_type": interviewer_type,
                    "years_of_experience": years_of_experience
                }
                result = make_api_call("/interviewer/add", method="POST", data=interviewer_data)
                if result:
                    st.success(f"Interviewer added successfully! ID: {result['interviewer_id']}")
            except json.JSONDecodeError:
                st.error("Invalid availability JSON format")
    
    # List Interviewers
    st.subheader("Existing Interviewers")
    department_filter = st.text_input("Filter by Department (Optional)")
    interviewer_type_filter = st.selectbox("Filter by Interviewer Type (Optional)", [None, "technical", "behavioral", "domain_expert", "hr", "manager"])
    skip = st.number_input("Skip", min_value=0, value=0)
    limit = st.number_input("Limit", min_value=1, max_value=100, value=20)
    if st.button("List Interviewers"):
        query = f"/interviewers?skip={skip}&limit={limit}"
        if department_filter:
            query += f"&department={department_filter}"
        if interviewer_type_filter:
            query += f"&interviewer_type={interviewer_type_filter}"
        interviewers_data = make_api_call(query)
        if interviewers_data and interviewers_data["interviewers"]:
            df = pd.DataFrame(interviewers_data["interviewers"])
            st.dataframe(df[["_id", "name", "email", "department", "interviewer_type", "experience_level"]])
        else:
            st.warning("No interviewers found.")

# Manage Candidates
elif page == "Manage Candidates":
    st.header("Manage Candidates")
    
    # Register Candidate
    with st.form("register_candidate_form"):
        st.subheader("Register New Candidate")
        name = st.text_input("Name")
        email = st.text_input("Email")
        job_role = st.text_input("Job Role")
        skills = st.text_input("Skills (comma-separated)")
        previous_companies = st.text_input("Previous Companies (comma-separated)")
        experience_level = st.selectbox("Experience Level", ["junior", "mid", "senior", "lead"])
        current_company = st.text_input("Current Company (Optional)")
        linkedin_profile = st.text_input("LinkedIn Profile (Optional)")
        resume_summary = st.text_area("Resume Summary (Optional)")
        submit_candidate = st.form_submit_button("Register Candidate")
        
        if submit_candidate:
            candidate_data = {
                "name": name,
                "email": email,
                "job_role": role,
                "skills": [skill.strip() for skill in skills.split(",")],
                "previous_companies": [company.strip() for company in previous_companies.split(",")],
                "experience_level": experience_level,
                "current_company": current_company or None,
                "linkedin_profile": profile or None,
                "resume_summary": summary or None
            }
            result = make_api_call("/candidate/register", method="POST", data=candidate_data)
            if result:
                st.success(f"Candidate registered successfully! ID: {result['candidate_id']}")
    
    # List Candidates
    st.subheader("Existing Candidates")
    job_role_filter = st.text_input("Filter by Role (Optional)")
    skip = st.number_input("Skip", min_value=0, value=0)
    limit = st.number_input("Limit", min_value=1, max_value=100, value=20)
    if st.button("List Candidates"):
        query = f"/candidates?skip={skip}&limit={limit}"
        if job_role_filter:
            query += f"&job_role={job_role_filter}"
        candidates_data = make_api_call(query)
        if candidates_data and candidates_data["candidates"]:
            df = pd.DataFrame(candidates_data["candidates"])
            st.dataframe(df[["_id", "name", "email", "job_role", "experience_level"]])
        else:
            st.warning("No candidates found.")

# Panel Recommendations
elif page == "Panel Recommendations":
    st.header("Panel Recommendations")
    
    # Subheader
    st.subheader("Generate Panel Recommendations")
    
    # Fetch jobs and candidates for dropdowns
    jobs_data = make_api_call("/jobs?skip=0&limit=100")
    candidates_data = make_api_call("/candidates?skip=0&limit=100")
    
    job_options = {None: "Select a Job"} if not jobs_data or not jobs_data["jobs"] else {j["_id"]: f"{j['job_role']} ({j['_id']})" for j in jobs_data["jobs"]}
    candidate_options = {None: "Select a Candidate"} if not candidates_data or not candidates_data["candidates"] else {c["_id"]: f"{c['name']} ({c['_id']})" for c in candidates_data["candidates"]}
    
    # Dropdowns for Job ID and Candidate ID
    job_id = st.selectbox("Select Job for Initial Panel", options=list(job_options.keys()), format_func=lambda x: job_options[x])
    candidate_id = st.selectbox("Select Candidate for Final Panel", options=list(candidate_options.keys()), format_func=lambda x: candidate_options[x])
    enhanced = st.checkbox("Enhanced Analysis", value=True)
    
    # Button to get recommendations
    if st.button("Get Recommendations"):
        if job_id and not candidate_id:
            result = make_api_call(f"/job/{job_id}/recommend_panel?enhanced={str(enhanced).lower()}")
            if result:
                st.subheader("Recommended Panel")
                for member in result["recommended_panel"]:
                    st.write(f"- {member['name']} (ID: {member['interviewer_id']}, Role: {member['role_in_panel']}, Match Score: {member['match_score']:.2f})")
                    st.write(f"  Reason: {member['recommendation_reason']}")
                
                if enhanced:
                    st.subheader("Detailed Analysis")
                    st.write("Diversity Analysis:")
                    diversity = result["diversity_analysis"]
                    st.write(f"Overall Score: {diversity['overall_score']:.2f}")
                    for key, value in diversity["breakdown"].items():
                        st.write(f"{key}: {value:.2f}")
                    
                    st.write("Skill Coverage:")
                    skills = result["skill_coverage"]
                    st.write(f"Coverage Score: {skills['coverage_score']:.2f}")
                    st.write(f"Covered Skills: {', '.join(skills['covered_skills'])}")
                    st.write(f"Missing Skills: {', '.join(skills['missing_skills'])}")
                    
                    st.write("Quality Metrics:")
                    quality = result["quality_metrics"]
                    st.write(f"Overall Quality: {quality['overall_quality']:.2f}")
                    st.write(f"Panel Size: {quality['panel_size']}")
                    st.write(f"Quality Rating: {quality['quality_rating']}")
                    
                    st.write("Alternatives:")
                    for alt in result["alternatives"]:
                        st.write(f"- {alt['name']} (Score: {alt['overall_score']:.2f}, Reason: {alt['reason']})")
        
        elif candidate_id:
            result = make_api_call(f"/candidate/{candidate_id}/suggest_panel?enhanced={str(enhanced).lower()}")
            if result:
                st.subheader("Suggested Panel")
                for member in result["suggested_panel"]["panel"]:
                    st.write(f"- {member['name']} (ID: {member['interviewer_id']}, Role: {member['role_in_panel']}, Match Score: {member['match_score']:.2f}, Conflict: {member['conflict']})")
                    st.write(f"  Reason: {member['recommendation_reason']}")
                
                if enhanced:
                    st.subheader("Detailed Analysis")
                    diversity = result["detailed_analysis"]["diversity_breakdown"]
                    st.write(f"Diversity Score: {result['suggested_panel']['diversity_score']:.2f}")
                    for key, value in diversity.items():
                        st.write(f"{key}: {value:.2f}")
                    
                    st.write("Skill Coverage:")
                    skills = result["detailed_analysis"]["skill_coverage"]
                    st.write(f"Coverage Score: {skills['coverage_score']:.2f}")
                    st.write(f"Covered Skills: {', '.join(skills['covered_skills'])}")
                    st.write(f"Missing Skills: {', '.join(skills['missing_skills'])}")
                    
                    st.write("Conflict Analysis:")
                    conflicts = result["detailed_analysis"]["conflict_analysis"]
                    st.write(f"Total Conflicts: {conflicts['total_conflicts']}")
                    st.write(f"Overall Risk: {conflicts['overall_risk']}")
                    
                    st.write("Quality Metrics:")
                    quality = result["detailed_analysis"]["quality_metrics"]
                    st.write(f"Overall Quality: {quality['overall_quality']:.2f}")
                    # st.write(f"Panel Size: {quality['panel_size']}")
                    # st.write(f"Quality Rating: {quality['quality_rating']}")
                    
                    st.write("Alternatives:")
                    for alt in result["alternatives"]:
                        st.write(f"- {alt['name']} (Score: {alt['overall_score']:.2f}, Reason: {alt['reason']})")
    
    # Create Final Panel
    with st.form("create_panel_form"):
        st.subheader("Create Final Panel")
        candidate_id_panel = st.selectbox("Select Candidate", options=list(candidate_options.keys()), format_func=lambda x: candidate_options[x], key="candidate_panel")
        interviewer_ids = st.text_input("Interviewer IDs (comma-separated)")
        submit_panel = st.form_submit_button("Create Panel")
        
        if submit_panel:
            panel_data = {
                "candidate_id": candidate_id_panel,
                "interviewer_ids": [id.strip() for id in interviewer_ids.split(",")]
            }
            result = make_api_call("/panel/create", method="POST", data=panel_data)
            if result:
                st.success(f"Panel created successfully! ID: {result['panel_id']}")

# Analytics
elif page == "Analytics":
    st.header("Analytics")
    
    # Diversity Report
    st.subheader("Diversity Report")
    if st.button("Generate Diversity Report"):
        report = make_api_call("/analytics/diversity-report")
        if report:
            st.write(f"Generated at: {report['generated_at']}")
            st.write(f"Summary: {report['summary']}")
            metrics = report["detailed_metrics"]
            st.write("Detailed Metrics Report:")
            st.write(f"Total Interviewers: {metrics['total_interviewers']}")
            st.write("Diversity Scores:")
            for key, value in metrics["diversity_scores"].items():
                st.write(f"{key}: {value:.2f}")
            st.write("Recommendations:")
            for rec in report["recommendations"]:
                st.write(f"- {rec}")
    
    # Panel Quality Analytics
    st.subheader("Panel Quality Analytics")
    if st.button("Generate Panel Quality Analytics"):
        analytics = make_api_call("/analytics/panel-quality")
        if analytics:
            st.write("Quality Metrics:")
            metrics = analytics["metrics"]
            if "message" in metrics:
                st.write(metrics["message"])
            else:
                st.write(f"Total Completed Panels: {metrics['total_completed_panels']}")
                st.write(f"Average Quality Score: {metrics['average_quality_score']:.2f}")
                st.write(f"Average Diversity Score: {metrics['average_diversity_score']:.2f}")
            # st.write("Improvement Areas:")
            # for imp in analytics["improvements"]:
            #     st.write(f"- {imp}")