from app.database import jobs_collection, interviewers_collection, candidates_collection, panels_collection
from bson import ObjectId
from typing import List, Dict, Any, Optional
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

# ----------------------------
# Job CRUD Operations
# ----------------------------
def create_job(job_data: Dict[str, Any]) -> str:
    """Create a new job with enhanced data structure"""
    try:
        job_data['created_at'] = datetime.now()
        job_data['status'] = 'active'
        result = jobs_collection.insert_one(job_data)
        return str(result.inserted_id)
    except Exception as e:
        logger.error(f"Error creating job: {e}")
        raise

def get_job(job_id: str) -> Optional[Dict[str, Any]]:
    """Get job by ID"""
    try:
        return jobs_collection.find_one({"_id": ObjectId(job_id)})
    except Exception as e:
        logger.error(f"Error fetching job {job_id}: {e}")
        return None

def get_all_jobs(skip: int = 0, limit: int = 10) -> List[Dict[str, Any]]:
    """Get all jobs with pagination"""
    try:
        jobs = list(jobs_collection.find().skip(skip).limit(limit))
        for job in jobs:
            job['_id'] = str(job['_id'])
        return jobs
    except Exception as e:
        logger.error(f"Error fetching jobs: {e}")
        return []

def update_job(job_id: str, update_data: Dict[str, Any]) -> bool:
    """Update job information"""
    try:
        update_data['updated_at'] = datetime.now()
        result = jobs_collection.update_one(
            {"_id": ObjectId(job_id)},
            {"$set": update_data}
        )
        return result.modified_count > 0
    except Exception as e:
        logger.error(f"Error updating job {job_id}: {e}")
        return False

def delete_job(job_id: str) -> bool:
    """Soft delete a job"""
    try:
        result = jobs_collection.update_one(
            {"_id": ObjectId(job_id)},
            {"$set": {"status": "deleted", "deleted_at": datetime.now()}}
        )
        return result.modified_count > 0
    except Exception as e:
        logger.error(f"Error deleting job {job_id}: {e}")
        return False

# ----------------------------
# Interviewer CRUD Operations
# ----------------------------
def create_interviewer(interviewer_data: Dict[str, Any]) -> str:
    """Create a new interviewer with enhanced profile"""
    try:
        interviewer_data['created_at'] = datetime.now()
        interviewer_data['status'] = 'active'
        # Initialize performance metrics if not provided
        if 'total_interviews_conducted' not in interviewer_data:
            interviewer_data['total_interviews_conducted'] = 0
        if 'average_interview_rating' not in interviewer_data:
            interviewer_data['average_interview_rating'] = 0.0
        
        result = interviewers_collection.insert_one(interviewer_data)
        return str(result.inserted_id)
    except Exception as e:
        logger.error(f"Error creating interviewer: {e}")
        raise

def get_interviewer(interviewer_id: str) -> Optional[Dict[str, Any]]:
    """Get interviewer by ID"""
    try:
        return interviewers_collection.find_one({"_id": ObjectId(interviewer_id)})
    except Exception as e:
        logger.error(f"Error fetching interviewer {interviewer_id}: {e}")
        return None

def get_all_interviewers() -> List[Dict[str, Any]]:
    """Get all active interviewers"""
    try:
        interviewers = list(interviewers_collection.find({"status": {"$ne": "deleted"}}))
        for interviewer in interviewers:
            interviewer['_id'] = str(interviewer['_id'])
        return interviewers
    except Exception as e:
        logger.error(f"Error fetching interviewers: {e}")
        return []

def get_filtered_interviewers(
    department: str = None,
    interviewer_type: str = None,
    experience_level: str = None,
    skills: List[str] = None,
    skip: int = 0,
    limit: int = 20
) -> List[Dict[str, Any]]:
    """Get interviewers with advanced filtering"""
    try:
        filter_query = {"status": {"$ne": "deleted"}}
        
        if department:
            filter_query["department"] = department
        if interviewer_type:
            filter_query["interviewer_type"] = interviewer_type
        if experience_level:
            filter_query["experience_level"] = experience_level
        if skills:
            filter_query["skills"] = {"$in": skills}
        
        interviewers = list(
            interviewers_collection.find(filter_query)
            .skip(skip)
            .limit(limit)
        )
        
        for interviewer in interviewers:
            interviewer['_id'] = str(interviewer['_id'])
        
        return interviewers
    except Exception as e:
        logger.error(f"Error filtering interviewers: {e}")
        return []

def update_interviewer(interviewer_id: str, update_data: Dict[str, Any]) -> bool:
    """Update interviewer information"""
    try:
        update_data['updated_at'] = datetime.now()
        result = interviewers_collection.update_one(
            {"_id": ObjectId(interviewer_id)},
            {"$set": update_data}
        )
        return result.modified_count > 0
    except Exception as e:
        logger.error(f"Error updating interviewer {interviewer_id}: {e}")
        return False

def update_interviewer_availability(interviewer_id: str, availability: List[Dict]) -> bool:
    """Update interviewer availability"""
    try:
        result = interviewers_collection.update_one(
            {"_id": ObjectId(interviewer_id)},
            {"$set": {"availability": availability, "updated_at": datetime.now()}}
        )
        return result.modified_count > 0
    except Exception as e:
        logger.error(f"Error updating availability for {interviewer_id}: {e}")
        return False

def update_interviewer_performance(interviewer_id: str, rating: float) -> bool:
    """Update interviewer performance metrics after an interview"""
    try:
        interviewer = get_interviewer(interviewer_id)
        if not interviewer:
            return False
        
        total_interviews = interviewer.get('total_interviews_conducted', 0)
        current_avg = interviewer.get('average_interview_rating', 0.0)
        
        # Calculate new average
        new_total = total_interviews + 1
        new_avg = ((current_avg * total_interviews) + rating) / new_total
        
        result = interviewers_collection.update_one(
            {"_id": ObjectId(interviewer_id)},
            {"$set": {
                "total_interviews_conducted": new_total,
                "average_interview_rating": round(new_avg, 2),
                "updated_at": datetime.now()
            }}
        )
        return result.modified_count > 0
    except Exception as e:
        logger.error(f"Error updating performance for {interviewer_id}: {e}")
        return False

# ----------------------------
# Candidate CRUD Operations
# ----------------------------
def create_candidate(candidate_data: Dict[str, Any]) -> str:
    """Create a new candidate with enhanced profile"""
    try:
        candidate_data['created_at'] = datetime.now()
        candidate_data['status'] = 'active'
        result = candidates_collection.insert_one(candidate_data)
        return str(result.inserted_id)
    except Exception as e:
        logger.error(f"Error creating candidate: {e}")
        raise

def get_candidate(candidate_id: str) -> Optional[Dict[str, Any]]:
    """Get candidate by ID"""
    try:
        return candidates_collection.find_one({"_id": ObjectId(candidate_id)})
    except Exception as e:
        logger.error(f"Error fetching candidate {candidate_id}: {e}")
        return None

def get_filtered_candidates(
    job_role: str = None,
    experience_level: str = None,
    skills: List[str] = None,
    skip: int = 0,
    limit: int = 20
) -> List[Dict[str, Any]]:
    """Get candidates with filtering"""
    try:
        filter_query = {"status": {"$ne": "deleted"}}
        
        if job_role:
            filter_query["job_role"] = {"$regex": job_role, "$options": "i"}
        if experience_level:
            filter_query["experience_level"] = experience_level
        if skills:
            filter_query["skills"] = {"$in": skills}
        
        candidates = list(
            candidates_collection.find(filter_query)
            .skip(skip)
            .limit(limit)
        )
        
        for candidate in candidates:
            candidate['_id'] = str(candidate['_id'])
        
        return candidates
    except Exception as e:
        logger.error(f"Error filtering candidates: {e}")
        return []

def update_candidate(candidate_id: str, update_data: Dict[str, Any]) -> bool:
    """Update candidate information"""
    try:
        update_data['updated_at'] = datetime.now()
        result = candidates_collection.update_one(
            {"_id": ObjectId(candidate_id)},
            {"$set": update_data}
        )
        return result.modified_count > 0
    except Exception as e:
        logger.error(f"Error updating candidate {candidate_id}: {e}")
        return False

# ----------------------------
# Panel CRUD Operations
# ----------------------------
def create_panel(panel_data: Dict[str, Any]) -> str:
    """Create a finalized interview panel"""
    try:
        panel_data['created_at'] = datetime.now()
        panel_data['status'] = 'scheduled'
        result = panels_collection.insert_one(panel_data)
        return str(result.inserted_id)
    except Exception as e:
        logger.error(f"Error creating panel: {e}")
        raise

def create_finalized_panel(candidate_id: str, interviewer_ids: List[str]) -> str:
    """Create a finalized panel with interviewer IDs"""
    try:
        panel_data = {
            "candidate_id": candidate_id,
            "interviewer_ids": interviewer_ids,
            "status": "finalized",
            "created_at": datetime.now()
        }
        result = panels_collection.insert_one(panel_data)
        return str(result.inserted_id)
    except Exception as e:
        logger.error(f"Error creating finalized panel: {e}")
        raise

def get_panel(panel_id: str) -> Optional[Dict[str, Any]]:
    """Get panel by ID"""
    try:
        return panels_collection.find_one({"_id": ObjectId(panel_id)})
    except Exception as e:
        logger.error(f"Error fetching panel {panel_id}: {e}")
        return None

def get_candidate_panel(candidate_id: str) -> Optional[Dict[str, Any]]:
    """Get panel for a specific candidate"""
    try:
        return panels_collection.find_one({"candidate_id": candidate_id})
    except Exception as e:
        logger.error(f"Error fetching panel for candidate {candidate_id}: {e}")
        return None

def get_panels_by_interviewer(interviewer_id: str) -> List[Dict[str, Any]]:
    """Get all panels where an interviewer is involved"""
    try:
        panels = list(panels_collection.find({
            "interviewer_ids": interviewer_id,
            "status": {"$ne": "cancelled"}
        }))
        for panel in panels:
            panel['_id'] = str(panel['_id'])
        return panels
    except Exception as e:
        logger.error(f"Error fetching panels for interviewer {interviewer_id}: {e}")
        return []

def update_panel_status(panel_id: str, status: str, feedback: Dict[str, Any] = None) -> bool:
    """Update panel status and optionally add feedback"""
    try:
        update_data = {
            "status": status,
            "updated_at": datetime.now()
        }
        
        if feedback:
            update_data["feedback"] = feedback
        
        result = panels_collection.update_one(
            {"_id": ObjectId(panel_id)},
            {"$set": update_data}
        )
        return result.modified_count > 0
    except Exception as e:
        logger.error(f"Error updating panel {panel_id}: {e}")
        return False

# ----------------------------
# Analytics and Reporting Functions
# ----------------------------
def generate_diversity_report() -> Dict[str, Any]:
    """Generate comprehensive diversity analytics"""
    try:
        # Get all active interviewers
        interviewers = list(interviewers_collection.find({"status": {"$ne": "deleted"}}))
        
        if not interviewers:
            return {
                "timestamp": datetime.now(),
                "summary": "No interviewer data available",
                "metrics": {},
                "recommendations": ["Add interviewer profiles to generate diversity analytics"]
            }
        
        total_interviewers = len(interviewers)
        
        # Gender distribution
        gender_counts = {}
        for interviewer in interviewers:
            gender = interviewer.get('gender', 'Unknown')
            gender_counts[gender] = gender_counts.get(gender, 0) + 1
        
        # Race distribution
        race_counts = {}
        for interviewer in interviewers:
            race = interviewer.get('race', 'Unknown')
            race_counts[race] = race_counts.get(race, 0) + 1
        
        # Department distribution
        dept_counts = {}
        for interviewer in interviewers:
            dept = interviewer.get('department', 'Unknown')
            dept_counts[dept] = dept_counts.get(dept, 0) + 1
        
        # Experience level distribution
        exp_counts = {}
        for interviewer in interviewers:
            exp = interviewer.get('experience_level', 'Unknown')
            exp_counts[exp] = exp_counts.get(exp, 0) + 1
        
        # Calculate diversity scores (Simpson's Diversity Index)
        def calculate_simpson_diversity(counts):
            total = sum(counts.values())
            if total <= 1:
                return 0.0
            return 1 - sum((count/total)**2 for count in counts.values())
        
        diversity_scores = {
            "gender_diversity": calculate_simpson_diversity(gender_counts),
            "race_diversity": calculate_simpson_diversity(race_counts),
            "department_diversity": calculate_simpson_diversity(dept_counts),
            "experience_diversity": calculate_simpson_diversity(exp_counts)
        }
        
        overall_diversity = sum(diversity_scores.values()) / len(diversity_scores)
        
        # Generate recommendations
        recommendations = []
        if diversity_scores["gender_diversity"] < 0.4:
            recommendations.append("Consider recruiting more diverse gender representation")
        if diversity_scores["race_diversity"] < 0.4:
            recommendations.append("Improve racial diversity in interviewer pool")
        if diversity_scores["department_diversity"] < 0.5:
            recommendations.append("Include interviewers from more departments")
        
        return {
            "timestamp": datetime.now(),
            "summary": f"Analyzed {total_interviewers} interviewers. Overall diversity score: {overall_diversity:.2f}",
            "metrics": {
                "total_interviewers": total_interviewers,
                "diversity_scores": diversity_scores,
                "overall_diversity_score": overall_diversity,
                "distributions": {
                    "gender": gender_counts,
                    "race": race_counts,
                    "department": dept_counts,
                    "experience_level": exp_counts
                }
            },
            "recommendations": recommendations
        }
    except Exception as e:
        logger.error(f"Error generating diversity report: {e}")
        return {
            "timestamp": datetime.now(),
            "summary": "Error generating report",
            "metrics": {},
            "recommendations": []
        }

def get_panel_quality_analytics() -> Dict[str, Any]:
    """Get panel quality analytics across all interviews"""
    try:
        # Get completed panels
        panels = list(panels_collection.find({"status": "completed"}))
        
        if not panels:
            return {
                "quality_metrics": {"message": "No completed panels found"},
                "trends": {},
                "improvements": ["Complete more interviews to generate analytics"]
            }
        
        # Calculate quality metrics
        total_panels = len(panels)
        avg_quality_scores = []
        diversity_scores = []
        
        for panel in panels:
            if 'panel_quality_score' in panel:
                avg_quality_scores.append(panel['panel_quality_score'])
            if 'overall_diversity_score' in panel:
                diversity_scores.append(panel['overall_diversity_score'])
        
        analytics = {
            "quality_metrics": {
                "total_completed_panels": total_panels,
                "average_quality_score": sum(avg_quality_scores) / len(avg_quality_scores) if avg_quality_scores else 0.0,
                "average_diversity_score": sum(diversity_scores) / len(diversity_scores) if diversity_scores else 0.0
            },
            "trends": {
                "panel_completion_rate": "Data insufficient for trend analysis",
                "quality_improvement": "Requires historical data"
            },
            "improvements": [
                "Track interview outcomes for better quality metrics",
                "Collect feedback from candidates and interviewers",
                "Monitor long-term hiring success rates"
            ]
        }
        
        return analytics
    except Exception as e:
        logger.error(f"Error generating quality analytics: {e}")
        return {
            "quality_metrics": {},
            "trends": {},
            "improvements": ["Fix analytics system errors"]
        }

def check_database_connection() -> bool:
    """Check if database connection is healthy"""
    try:
        # Try to perform a simple operation
        jobs_collection.find_one({})
        return True
    except Exception as e:
        logger.error(f"Database connection check failed: {e}")
        return False

# ----------------------------
# Search and Query Functions
# ----------------------------
def search_interviewers_by_skills(skills: List[str], limit: int = 10) -> List[Dict[str, Any]]:
    """Search interviewers by skills"""
    try:
        interviewers = list(
            interviewers_collection.find({
                "skills": {"$in": skills},
                "status": {"$ne": "deleted"}
            }).limit(limit)
        )
        
        for interviewer in interviewers:
            interviewer['_id'] = str(interviewer['_id'])
            # Calculate skill match score
            interviewer_skills = set(interviewer.get('skills', []))
            required_skills = set(skills)
            match_score = len(interviewer_skills.intersection(required_skills)) / len(required_skills)
            interviewer['skill_match_score'] = round(match_score, 2)
        
        # Sort by skill match score
        interviewers.sort(key=lambda x: x['skill_match_score'], reverse=True)
        return interviewers
    except Exception as e:
        logger.error(f"Error searching interviewers by skills: {e}")
        return []

def get_interviewer_workload(interviewer_id: str) -> Dict[str, Any]:
    """Get interviewer's current workload"""
    try:
        # Count active panels
        active_panels = panels_collection.count_documents({
            "interviewer_ids": interviewer_id,
            "status": {"$in": ["scheduled", "in_progress"]}
        })
        
        # Get recent interview count (last 30 days)
        thirty_days_ago = datetime.now().replace(day=datetime.now().day-30)
        recent_panels = panels_collection.count_documents({
            "interviewer_ids": interviewer_id,
            "created_at": {"$gte": thirty_days_ago}
        })
        
        interviewer = get_interviewer(interviewer_id)
        total_interviews = interviewer.get('total_interviews_conducted', 0) if interviewer else 0
        
        return {
            "interviewer_id": interviewer_id,
            "active_panels": active_panels,
            "recent_interviews": recent_panels,
            "total_interviews": total_interviews,
            "workload_status": "high" if active_panels > 5 else "medium" if active_panels > 2 else "low"
        }
    except Exception as e:
        logger.error(f"Error getting workload for {interviewer_id}: {e}")
        return {
            "interviewer_id": interviewer_id,
            "active_panels": 0,
            "recent_interviews": 0,
            "total_interviews": 0,
            "workload_status": "unknown"
        }