from fastapi import FastAPI, HTTPException, Query
from app.models import Job, Interviewer, Candidate, PanelRecommendation
from app import crud
from app.utils import recommend_interviewers_enhanced, recommend_interviewers
from fastapi.middleware.cors import CORSMiddleware
from typing import Optional, List
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Interview Panel Optimizer API",
    description="AI-powered interview panel optimization with DEI compliance and conflict detection",
    version="2.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {
        "message": "Interview Panel Optimizer API",
        "version": "2.0.0",
        "features": [
            "AI-powered panel recommendations",
            "DEI compliance checking",
            "Conflict of interest detection",
            "Skill matching with semantic analysis",
            "Diversity optimization"
        ]
    }

# ----------------------------------
# Job Management Endpoints
# ----------------------------------

@app.post("/job/create")
def create_job(job: Job):
    """Create a new job posting with enhanced requirements"""
    try:
        job_id = crud.create_job(job.dict())
        logger.info(f"Job created successfully: {job_id}")
        return {
            "message": "Job created successfully",
            "job_id": job_id,
            "job_role": job.job_role,
            "department": job.department
        }
    except Exception as e:
        logger.error(f"Error creating job: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to create job: {str(e)}")

@app.get("/job/{job_id}")
def get_job(job_id: str):
    """Get job details by ID"""
    try:
        job = crud.get_job(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Job not found")
        
        # Convert ObjectId to string for JSON serialization
        job['_id'] = str(job['_id'])
        return job
    except Exception as e:
        logger.error(f"Error fetching job {job_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch job: {str(e)}")

@app.get("/jobs")
def list_jobs(skip: int = Query(0, ge=0), limit: int = Query(10, ge=1, le=100)):
    """List all jobs with pagination"""
    try:
        jobs = crud.get_all_jobs(skip=skip, limit=limit)
        return {
            "jobs": jobs,
            "count": len(jobs),
            "skip": skip,
            "limit": limit
        }
    except Exception as e:
        logger.error(f"Error listing jobs: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list jobs: {str(e)}")

# ----------------------------------
# Interviewer Management Endpoints
# ----------------------------------

@app.post("/interviewer/add")
def add_interviewer(interviewer: Interviewer):
    """Add a new interviewer to the system"""
    try:
        interviewer_id = crud.create_interviewer(interviewer.dict())
        logger.info(f"Interviewer added successfully: {interviewer_id}")
        return {
            "message": "Interviewer added successfully",
            "interviewer_id": interviewer_id,
            "name": interviewer.name,
            "department": interviewer.department
        }
    except Exception as e:
        logger.error(f"Error adding interviewer: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to add interviewer: {str(e)}")

@app.get("/interviewer/{interviewer_id}")
def get_interviewer(interviewer_id: str):
    """Get interviewer details by ID"""
    try:
        interviewer = crud.get_interviewer(interviewer_id)
        if not interviewer:
            raise HTTPException(status_code=404, detail="Interviewer not found")
        
        interviewer['_id'] = str(interviewer['_id'])
        return interviewer
    except Exception as e:
        logger.error(f"Error fetching interviewer {interviewer_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch interviewer: {str(e)}")

@app.get("/interviewers")
def list_interviewers(
    department: Optional[str] = None,
    interviewer_type: Optional[str] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100)
):
    """List interviewers with optional filtering"""
    try:
        interviewers = crud.get_filtered_interviewers(
            department=department,
            interviewer_type=interviewer_type,
            skip=skip,
            limit=limit
        )
        return {
            "interviewers": interviewers,
            "count": len(interviewers),
            "filters": {
                "department": department,
                "interviewer_type": interviewer_type
            }
        }
    except Exception as e:
        logger.error(f"Error listing interviewers: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list interviewers: {str(e)}")

@app.put("/interviewer/{interviewer_id}/availability")
def update_availability(interviewer_id: str, availability: List[dict]):
    """Update interviewer availability"""
    try:
        success = crud.update_interviewer_availability(interviewer_id, availability)
        if not success:
            raise HTTPException(status_code=404, detail="Interviewer not found")
        
        return {
            "message": "Availability updated successfully",
            "interviewer_id": interviewer_id
        }
    except Exception as e:
        logger.error(f"Error updating availability for {interviewer_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to update availability: {str(e)}")

# ----------------------------------
# Panel Recommendation Endpoints
# ----------------------------------

@app.get("/job/{job_id}/recommend_panel")
def recommend_initial_panel(job_id: str, enhanced: bool = Query(False)):
    """Recommend initial panel for a job with optional enhanced analysis"""
    try:
        if enhanced:
            recommendation = recommend_interviewers_enhanced(job_id, is_final=False)
            return {
                "job_id": job_id,
                "recommendation_type": "enhanced_initial",
                "recommended_panel": [
                    {
                        "interviewer_id": member.interviewer_id,
                        "name": member.name,
                        "match_score": member.match_score,
                        "role_in_panel": member.role_in_panel,
                        "recommendation_reason": member.recommendation_reason
                    }
                    for member in recommendation.recommended_panel
                ],
                "diversity_analysis": recommendation.diversity_analysis,
                "skill_coverage": recommendation.skill_coverage_analysis,
                "quality_metrics": recommendation.quality_metrics,
                "alternatives": recommendation.alternative_suggestions
            }
        else:
            # Legacy format for backward compatibility
            panel_data = recommend_interviewers(job_id, is_final=False)
            return {
                "job_id": job_id,
                "recommendation_type": "initial",
                "recommended_panel": panel_data
            }
            
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Error recommending panel for job {job_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate recommendations: {str(e)}")

# ----------------------------------
# Candidate Management Endpoints
# ----------------------------------

@app.post("/candidate/register")
def register_candidate(candidate: Candidate):
    """Register a new candidate"""
    try:
        candidate_id = crud.create_candidate(candidate.dict())
        logger.info(f"Candidate registered successfully: {candidate_id}")
        return {
            "message": "Candidate registered successfully",
            "candidate_id": candidate_id,
            "name": candidate.name,
            "job_role": candidate.job_role
        }
    except Exception as e:
        logger.error(f"Error registering candidate: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to register candidate: {str(e)}")

@app.get("/candidate/{candidate_id}")
def get_candidate(candidate_id: str):
    """Get candidate details by ID"""
    try:
        candidate = crud.get_candidate(candidate_id)
        if not candidate:
            raise HTTPException(status_code=404, detail="Candidate not found")
        
        candidate['_id'] = str(candidate['_id'])
        return candidate
    except Exception as e:
        logger.error(f"Error fetching candidate {candidate_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch candidate: {str(e)}")

@app.get("/candidates")
def list_candidates(
    job_role: Optional[str] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100)
):
    """List candidates with optional filtering"""
    try:
        candidates = crud.get_filtered_candidates(
            job_role=job_role,
            skip=skip,
            limit=limit
        )
        return {
            "candidates": candidates,
            "count": len(candidates),
            "filters": {"job_role": job_role}
        }
    except Exception as e:
        logger.error(f"Error listing candidates: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to list candidates: {str(e)}")

# ----------------------------------
# Final Panel Recommendation Endpoints
# ----------------------------------

@app.get("/candidate/{candidate_id}/suggest_panel")
def suggest_final_panel(candidate_id: str, enhanced: bool = Query(True)):
    """Suggest final interview panel for a specific candidate"""
    try:
        if enhanced:
            recommendation = recommend_interviewers_enhanced(candidate_id, is_final=True)
            return {
                "candidate_id": candidate_id,
                "recommendation_type": "enhanced_final",
                "suggested_panel": {
                    "panel": [
                        {
                            "interviewer_id": member.interviewer_id,
                            "name": member.name,
                            "match_score": member.match_score,
                            "conflict": member.conflict_status,
                            "role_in_panel": member.role_in_panel,
                            "recommendation_reason": member.recommendation_reason,
                            "diversity_contribution": member.diversity_contribution
                        }
                        for member in recommendation.recommended_panel
                    ],
                    "diversity_score": recommendation.diversity_analysis["overall_score"]
                },
                "detailed_analysis": {
                    "diversity_breakdown": recommendation.diversity_analysis["breakdown"],
                    "skill_coverage": recommendation.skill_coverage_analysis,
                    "conflict_analysis": recommendation.conflict_analysis,
                    "quality_metrics": recommendation.quality_metrics
                },
                "alternatives": recommendation.alternative_suggestions
            }
        else:
            # Legacy format
            panel_data = recommend_interviewers(candidate_id, is_final=True)
            return {
                "candidate_id": candidate_id,
                "recommendation_type": "final",
                "suggested_panel": panel_data
            }
            
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Error suggesting panel for candidate {candidate_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate final panel: {str(e)}")

# ----------------------------------
# Panel Management Endpoints
# ----------------------------------

@app.post("/panel/create")
def create_panel(candidate_id: str, interviewer_ids: List[str]):
    """Create and save a finalized interview panel"""
    try:
        panel_id = crud.create_finalized_panel(candidate_id, interviewer_ids)
        return {
            "message": "Panel created successfully",
            "panel_id": panel_id,
            "candidate_id": candidate_id,
            "interviewer_count": len(interviewer_ids)
        }
    except Exception as e:
        logger.error(f"Error creating panel: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to create panel: {str(e)}")

@app.get("/panel/{panel_id}")
def get_panel(panel_id: str):
    """Get panel details by ID"""
    try:
        panel = crud.get_panel(panel_id)
        if not panel:
            raise HTTPException(status_code=404, detail="Panel not found")
        
        panel['_id'] = str(panel['_id'])
        return panel
    except Exception as e:
        logger.error(f"Error fetching panel {panel_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch panel: {str(e)}")

# ----------------------------------
# Analytics and Reporting Endpoints
# ----------------------------------

@app.get("/analytics/diversity-report")
def get_diversity_report():
    """Get system-wide diversity analytics"""
    try:
        report = crud.generate_diversity_report()
        return {
            "report_type": "diversity_analytics",
            "generated_at": report.get("timestamp"),
            "summary": report.get("summary"),
            "detailed_metrics": report.get("metrics"),
            "recommendations": report.get("recommendations", [])
        }
    except Exception as e:
        logger.error(f"Error generating diversity report: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate report: {str(e)}")

@app.get("/analytics/panel-quality")
def get_panel_quality_analytics():
    """Get panel quality analytics across all interviews"""
    try:
        analytics = crud.get_panel_quality_analytics()
        return {
            "report_type": "panel_quality",
            "metrics": analytics.get("quality_metrics"),
            "trends": analytics.get("trends"),
            "improvement_areas": analytics.get("improvements", [])
        }
    except Exception as e:
        logger.error(f"Error generating quality analytics: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate analytics: {str(e)}")

# ----------------------------------
# Health Check and System Status
# ----------------------------------

@app.get("/health")
def health_check():
    """System health check endpoint"""
    try:
        db_status = crud.check_database_connection()
        return {
            "status": "healthy" if db_status else "unhealthy",
            "database": "connected" if db_status else "disconnected",
            "version": "2.0.0",
            "features_active": [
                "ai_recommendations",
                "dei_compliance",
                "conflict_detection",
                "skill_matching"
            ]
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e),
            "version": "2.0.0"
        }