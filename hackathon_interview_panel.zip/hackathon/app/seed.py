from datetime import datetime, timedelta
from enum import Enum
from typing import List, Optional, Dict, Any

# Define Enums (assuming they are in your main application or can be copied here)
class ExperienceLevel(str, Enum):
    JUNIOR = "junior"
    MID = "mid"
    SENIOR = "senior"
    LEAD = "lead"
    PRINCIPAL = "principal"

class InterviewerType(str, Enum):
    TECHNICAL = "technical"
    BEHAVIORAL = "behavioral"
    DOMAIN_EXPERT = "domain_expert"
    HR = "hr"
    MANAGER = "manager"

# --- Job Data ---
jobs_data = [
    {
        "job_role": "Senior Software Engineer",
        "job_description": "Develop and maintain scalable web applications.",
        "required_skills": ["Python", "Django", "React", "AWS", "SQL"],
        "experience_level": ExperienceLevel.SENIOR,
        "special_requirements": "Experience with microservices architecture preferred.",
        "department": "Engineering",
        "interviewer_types_needed": [InterviewerType.TECHNICAL, InterviewerType.BEHAVIORAL, InterviewerType.MANAGER]
    },
    {
        "job_role": "Junior Frontend Developer",
        "job_description": "Assist in building user interfaces and interactive web components.",
        "required_skills": ["HTML", "CSS", "JavaScript", "Vue.js"],
        "experience_level": ExperienceLevel.JUNIOR,
        "department": "Engineering",
        "interviewer_types_needed": [InterviewerType.TECHNICAL, InterviewerType.HR]
    },
    {
        "job_role": "Data Scientist",
        "job_description": "Analyze large datasets and build predictive models.",
        "required_skills": ["Python", "R", "Machine Learning", "SQL", "Statistics"],
        "experience_level": ExperienceLevel.MID,
        "department": "Data Science",
        "interviewer_types_needed": [InterviewerType.TECHNICAL, InterviewerType.DOMAIN_EXPERT, InterviewerType.BEHAVIORAL]
    },
    {
        "job_role": "Product Manager",
        "job_description": "Define product vision, strategy, and roadmap.",
        "required_skills": ["Product Management", "Market Research", "Agile", "Roadmapping"],
        "experience_level": ExperienceLevel.SENIOR,
        "department": "Product",
        "interviewer_types_needed": [InterviewerType.MANAGER, InterviewerType.BEHAVIORAL, InterviewerType.DOMAIN_EXPERT]
    },
    {
        "job_role": "HR Business Partner",
        "job_description": "Support employees and management on HR-related issues.",
        "required_skills": ["HR Policies", "Employee Relations", "Recruitment", "Communication"],
        "experience_level": ExperienceLevel.MID,
        "department": "Human Resources",
        "interviewer_types_needed": [InterviewerType.HR, InterviewerType.MANAGER]
    },
    {
        "job_role": "Lead DevOps Engineer",
        "job_description": "Design, implement, and manage CI/CD pipelines and cloud infrastructure.",
        "required_skills": ["Kubernetes", "Docker", "Terraform", "AWS", "CI/CD"],
        "experience_level": ExperienceLevel.LEAD,
        "special_requirements": "Strong leadership skills and experience mentoring.",
        "department": "Infrastructure",
        "interviewer_types_needed": [InterviewerType.TECHNICAL, InterviewerType.MANAGER, InterviewerType.DOMAIN_EXPERT]
    },
    {
        "job_role": "UI/UX Designer",
        "job_description": "Create intuitive and aesthetically pleasing user interfaces.",
        "required_skills": ["Figma", "Sketch", "User Research", "Prototyping"],
        "experience_level": ExperienceLevel.MID,
        "department": "Design",
        "interviewer_types_needed": [InterviewerType.TECHNICAL, InterviewerType.BEHAVIORAL]
    },
    {
        "job_role": "Principal Architect",
        "job_description": "Define the overall technical architecture for large-scale systems.",
        "required_skills": ["System Design", "Distributed Systems", "Cloud Architecture", "Strategic Planning"],
        "experience_level": ExperienceLevel.PRINCIPAL,
        "special_requirements": "Proven track record of delivering complex projects.",
        "department": "Engineering",
        "interviewer_types_needed": [InterviewerType.TECHNICAL, InterviewerType.MANAGER, InterviewerType.DOMAIN_EXPERT]
    },
    {
        "job_role": "Sales Executive",
        "job_description": "Drive revenue by identifying and closing new business opportunities.",
        "required_skills": ["Sales Strategy", "Negotiation", "CRM Software", "Client Relationship Management"],
        "experience_level": ExperienceLevel.JUNIOR,
        "department": "Sales",
        "interviewer_types_needed": [InterviewerType.BEHAVIORAL, InterviewerType.MANAGER]
    },
    {
        "job_role": "Customer Support Specialist",
        "job_description": "Provide excellent support to customers via various channels.",
        "required_skills": ["Customer Service", "Problem Solving", "Communication", "CRM"],
        "experience_level": ExperienceLevel.JUNIOR,
        "department": "Customer Service",
        "interviewer_types_needed": [InterviewerType.HR, InterviewerType.BEHAVIORAL]
    }
]

# --- Interviewer Data ---
interviewers_data = [
    {
        "name": "Alice Johnson",
        "email": "alice.j@example.com",
        "department": "Engineering",
        "skills": ["Python", "Django", "SQL", "System Design"],
        "gender": "Female",
        "race": "Asian",
        "availability": [{"from": (datetime.now() + timedelta(days=2)).isoformat(), "to": (datetime.now() + timedelta(days=2, hours=2)).isoformat()}],
        "past_feedback_score": 4.5,
        "past_companies": ["Tech Solutions Inc.", "Global Innovators"],
        "experience_level": ExperienceLevel.SENIOR,
        "interviewer_type": InterviewerType.TECHNICAL,
        "total_interviews_conducted": 120,
        "average_interview_rating": 4.3,
        "specializations": ["Backend Development", "API Design"],
        "years_of_experience": 10
    },
    {
        "name": "Bob Williams",
        "email": "bob.w@example.com",
        "department": "Engineering",
        "skills": ["React", "Vue.js", "JavaScript", "HTML", "CSS"],
        "gender": "Male",
        "race": "Caucasian",
        "availability": [{"from": (datetime.now() + timedelta(days=3)).isoformat(), "to": (datetime.now() + timedelta(days=3, hours=1)).isoformat()}],
        "past_feedback_score": 4.2,
        "past_companies": ["WebCrafters", "Frontend Masters"],
        "experience_level": ExperienceLevel.MID,
        "interviewer_type": InterviewerType.TECHNICAL,
        "total_interviews_conducted": 85,
        "average_interview_rating": 4.1,
        "specializations": ["Frontend Frameworks", "UI/UX Implementation"],
        "years_of_experience": 6
    },
    {
        "name": "Carol Davis",
        "email": "carol.d@example.com",
        "department": "Human Resources",
        "skills": ["Behavioral Interviewing", "Employee Relations", "Recruitment"],
        "gender": "Female",
        "race": "African American",
        "availability": [{"from": (datetime.now() + timedelta(days=4)).isoformat(), "to": (datetime.now() + timedelta(days=4, hours=0, minutes=45)).isoformat()}],
        "past_feedback_score": 4.8,
        "past_companies": ["HR Pro Group", "Talent Connect"],
        "experience_level": ExperienceLevel.LEAD,
        "interviewer_type": InterviewerType.HR,
        "total_interviews_conducted": 200,
        "average_interview_rating": 4.7,
        "specializations": ["Diversity & Inclusion", "Candidate Experience"],
        "years_of_experience": 15
    },
    {
        "name": "David Brown",
        "email": "david.b@example.com",
        "department": "Data Science",
        "skills": ["Machine Learning", "Python", "TensorFlow", "Statistics"],
        "gender": "Male",
        "race": "Hispanic",
        "availability": [{"from": (datetime.now() + timedelta(days=5)).isoformat(), "to": (datetime.now() + timedelta(days=5, hours=1, minutes=30)).isoformat()}],
        "past_feedback_score": 4.6,
        "past_companies": ["Data Insights Co.", "AI Innovations"],
        "experience_level": ExperienceLevel.SENIOR,
        "interviewer_type": InterviewerType.DOMAIN_EXPERT,
        "total_interviews_conducted": 90,
        "average_interview_rating": 4.5,
        "specializations": ["NLP", "Computer Vision"],
        "years_of_experience": 9
    },
    {
        "name": "Eve Adams",
        "email": "eve.a@example.com",
        "department": "Product",
        "skills": ["Product Strategy", "Agile Methodologies", "Market Analysis"],
        "gender": "Female",
        "race": "Caucasian",
        "availability": [{"from": (datetime.now() + timedelta(days=6)).isoformat(), "to": (datetime.now() + timedelta(days=6, hours=1)).isoformat()}],
        "past_feedback_score": 4.7,
        "past_companies": ["Product Powerhouse", "Growth Labs"],
        "experience_level": "mid",
        "interviewer_type": InterviewerType.MANAGER,
        "total_interviews_conducted": 70,
        "average_interview_rating": 4.6,
        "specializations": ["SaaS Products", "B2B Solutions"],
        "years_of_experience": 12
    },
    {
        "name": "Frank White",
        "email": "frank.w@example.com",
        "department": "Engineering",
        "skills": ["Go", "Kubernetes", "AWS", "Microservices"],
        "gender": "Male",
        "race": "Asian",
        "availability": [{"from": (datetime.now() + timedelta(days=7)).isoformat(), "to": (datetime.now() + timedelta(days=7, hours=2)).isoformat()}],
        "past_feedback_score": 4.4,
        "past_companies": ["CloudOps Ltd.", "DevOps Gurus"],
        "experience_level": ExperienceLevel.LEAD,
        "interviewer_type": InterviewerType.TECHNICAL,
        "total_interviews_conducted": 150,
        "average_interview_rating": 4.3,
        "specializations": ["Cloud Infrastructure", "Distributed Systems"],
        "years_of_experience": 11
    },
    {
        "name": "Grace Lee",
        "email": "grace.l@example.com",
        "department": "Design",
        "skills": ["Figma", "Sketch", "User Research", "Wireframing"],
        "gender": "Female",
        "race": "Asian",
        "availability": [{"from": (datetime.now() + timedelta(days=8)).isoformat(), "to": (datetime.now() + timedelta(days=8, hours=1)).isoformat()}],
        "past_feedback_score": 4.3,
        "past_companies": ["Creative Designs", "UI/UX Studio"],
        "experience_level": ExperienceLevel.MID,
        "interviewer_type": InterviewerType.TECHNICAL,
        "total_interviews_conducted": 60,
        "average_interview_rating": 4.2,
        "specializations": ["Mobile UI", "Web UX"],
        "years_of_experience": 7
    },
    {
        "name": "Henry King",
        "email": "henry.k@example.com",
        "department": "Engineering",
        "skills": ["Java", "Spring Boot", "Kafka", "Databases"],
        "gender": "Male",
        "race": "Caucasian",
        "availability": [{"from": (datetime.now() + timedelta(days=9)).isoformat(), "to": (datetime.now() + timedelta(days=9, hours=1, minutes=30)).isoformat()}],
        "past_feedback_score": 4.5,
        "past_companies": ["Enterprise Systems", "Software Giants"],
        "experience_level": ExperienceLevel.PRINCIPAL,
        "interviewer_type": InterviewerType.TECHNICAL,
        "total_interviews_conducted": 180,
        "average_interview_rating": 4.4,
        "specializations": ["Enterprise Architecture", "Performance Tuning"],
        "years_of_experience": 18
    },
    {
        "name": "Ivy Chen",
        "email": "ivy.c@example.com",
        "department": "Human Resources",
        "skills": ["Conflict Resolution", "Performance Management", "Coaching"],
        "gender": "Female",
        "race": "Asian",
        "availability": [{"from": (datetime.now() + timedelta(days=10)).isoformat(), "to": (datetime.now() + timedelta(days=10, hours=0, minutes=45)).isoformat()}],
        "past_feedback_score": 4.9,
        "past_companies": ["People First HR", "Success Partners"],
        "experience_level": ExperienceLevel.SENIOR,
        "interviewer_type": InterviewerType.BEHAVIORAL,
        "total_interviews_conducted": 100,
        "average_interview_rating": 4.8,
        "specializations": ["Leadership Development", "Organizational Change"],
        "years_of_experience": 13
    },
    {
        "name": "Jack Taylor",
        "email": "jack.t@example.com",
        "department": "Sales",
        "skills": ["Sales Operations", "CRM", "Client Acquisition"],
        "gender": "Male",
        "race": "Caucasian",
        "availability": [{"from": (datetime.now() + timedelta(days=11)).isoformat(), "to": (datetime.now() + timedelta(days=11, hours=1)).isoformat()}],
        "past_feedback_score": 4.1,
        "past_companies": ["SalesForce Solutions", "Market Movers"],
        "experience_level": ExperienceLevel.MID,
        "interviewer_type": InterviewerType.MANAGER,
        "total_interviews_conducted": 50,
        "average_interview_rating": 4.0,
        "specializations": ["B2B Sales", "SaaS Sales"],
        "years_of_experience": 8
    }
]

# --- Candidate Data ---
candidates_data = [
    {
        "name": "Charlie Puth",
        "email": "charlie.p@example.com",
        "job_role": "Senior Software Engineer",
        "skills": ["Python", "Django", "PostgreSQL", "AWS", "Docker"],
        "previous_companies": ["CodeCraft Inc.", "Digital Frontier"],
        "experience_level": ExperienceLevel.SENIOR,
        "current_company": "Innovate Solutions",
        "linkedin_profile": "https://linkedin.com/in/charlieputh",
        "resume_summary": "Highly experienced software engineer with a focus on backend development and cloud architecture."
    },
    {
        "name": "Dana Scully",
        "email": "dana.s@example.com",
        "job_role": "Junior Frontend Developer",
        "skills": ["HTML", "CSS", "JavaScript", "Vue.js", "Git"],
        "previous_companies": ["Startup Spark"],
        "experience_level": ExperienceLevel.JUNIOR,
        "current_company": "Web Wizards",
        "linkedin_profile": "https://linkedin.com/in/danascully",
        "resume_summary": "Enthusiastic junior developer with a passion for creating engaging user interfaces."
    },
    {
        "name": "Ethan Hunt",
        "email": "ethan.h@example.com",
        "job_role": "Data Scientist",
        "skills": ["Python", "Pandas", "Scikit-learn", "SQL", "Data Visualization"],
        "previous_companies": ["Quantify Analytics", "Data Nexus"],
        "experience_level": ExperienceLevel.MID,
        "current_company": "Insightful Corp.",
        "linkedin_profile": "https://linkedin.com/in/ethanhunt",
        "resume_summary": "Data Scientist with experience in statistical modeling and data analysis."
    },
    {
        "name": "Fiona Gallagher",
        "email": "fiona.g@example.com",
        "job_role": "Product Manager",
        "skills": ["Product Roadmapping", "Agile", "User Stories", "Jira"],
        "previous_companies": ["Product Forge", "Market Vision"],
        "experience_level": ExperienceLevel.SENIOR,
        "current_company": "Strategize Now",
        "linkedin_profile": "https://linkedin.com/in/fionagallagher",
        "resume_summary": "Experienced Product Manager skilled in leading cross-functional teams and defining product strategy."
    },
    {
        "name": "George Constanza",
        "email": "george.c@example.com",
        "job_role": "HR Business Partner",
        "skills": ["HRIS", "Compensation & Benefits", "Onboarding", "Compliance"],
        "previous_companies": ["PeopleWorks", "HR Link"],
        "experience_level": ExperienceLevel.MID,
        "current_company": "Connect HR",
        "linkedin_profile": "https://linkedin.com/in/georgeconstanza",
        "resume_summary": "Dedicated HR professional with a strong background in employee relations and HR operations."
    },
    {
        "name": "Hannah Montana",
        "email": "hannah.m@example.com",
        "job_role": "Lead DevOps Engineer",
        "skills": ["Kubernetes", "Terraform", "Azure DevOps", "Ansible", "Linux"],
        "previous_companies": ["InfraScale", "Cloud Native Solutions"],
        "experience_level": ExperienceLevel.LEAD,
        "current_company": "DevOps Dynamics",
        "linkedin_profile": "https://linkedin.com/in/hannahmontana",
        "resume_summary": "Lead DevOps Engineer with extensive experience in automating infrastructure and CI/CD pipelines."
    },
    {
        "name": "Ivan Drago",
        "email": "ivan.d@example.com",
        "job_role": "UI/UX Designer",
        "skills": ["Adobe XD", "Figma", "User Flows", "Interaction Design"],
        "previous_companies": ["Pixel Perfect", "Design Innovators"],
        "experience_level": ExperienceLevel.MID,
        "current_company": "Aesthetic Apps",
        "linkedin_profile": "https://linkedin.com/in/ivandrago",
        "resume_summary": "Creative UI/UX Designer focused on user-centered design principles and intuitive interfaces."
    },
    {
        "name": "Julia Roberts",
        "email": "julia.r@example.com",
        "job_role": "Principal Architect",
        "skills": ["Enterprise Architecture", "Scalability", "Security Architecture", "Cloud Strategy"],
        "previous_companies": ["Global Systems", "Apex Architecture"],
        "experience_level": ExperienceLevel.PRINCIPAL,
        "current_company": "Future Tech Solutions",
        "linkedin_profile": "https://linkedin.com/in/juliaroberts",
        "resume_summary": "Principal Architect specializing in designing robust and scalable enterprise solutions."
    },
    {
        "name": "Kevin Hart",
        "email": "kevin.h@example.com",
        "job_role": "Sales Executive",
        "skills": ["B2B Sales", "Lead Generation", "Salesforce CRM", "Public Speaking"],
        "previous_companies": ["Growth Partners"],
        "experience_level": ExperienceLevel.JUNIOR,
        "current_company": "Sales Accelerators",
        "linkedin_profile": "https://linkedin.com/in/kevinhart",
        "resume_summary": "Ambitious Sales Executive with a track record of exceeding targets."
    },
    {
        "name": "Linda Smith",
        "email": "linda.s@example.com",
        "job_role": "Customer Support Specialist",
        "skills": ["Zendesk", "Troubleshooting", "Active Listening", "Email Support"],
        "previous_companies": ["Client First Support"],
        "experience_level": ExperienceLevel.JUNIOR,
        "current_company": "HelpDesk Heroes",
        "linkedin_profile": "https://linkedin.com/in/lindasmith",
        "resume_summary": "Dedicated Customer Support Specialist committed to resolving issues efficiently."
    }
]

# --- Panel Data (Example linkages) ---
# Note: You'd typically generate these dynamically based on job, interviewer, and candidate IDs.
# For demonstration, we'll link some predefined ones.
panels_data = [
    {
        "candidate_id": "charlie.p@example.com", # Email acting as ID for simplicity
        "job_id": "Senior Software Engineer",     # Job role acting as ID for simplicity
        "panel_members": [
            {
                "interviewer_id": "alice.j@example.com",
                "name": "Alice Johnson",
                "match_score": 0.95,
                "conflict_status": False,
                "diversity_contribution": 0.2,
                "role_in_panel": InterviewerType.TECHNICAL,
                "recommendation_reason": "Strong Python/Django expertise, high feedback score."
            },
            {
                "interviewer_id": "frank.w@example.com",
                "name": "Frank White",
                "match_score": 0.88,
                "conflict_status": False,
                "diversity_contribution": 0.1,
                "role_in_panel": InterviewerType.TECHNICAL,
                "recommendation_reason": "Expertise in AWS and Microservices."
            },
            {
                "interviewer_id": "eve.a@example.com",
                "name": "Eve Adams",
                "match_score": 0.90,
                "conflict_status": False,
                "diversity_contribution": 0.15,
                "role_in_panel": InterviewerType.MANAGER,
                "recommendation_reason": "Product leadership perspective, good behavioral interviewer."
            }
        ],
        "overall_diversity_score": 0.75,
        "skill_coverage_score": 0.92,
        "conflict_flags": [],
        "panel_quality_score": 0.90,
        "recommendations": ["Ensure behavioral fit is thoroughly assessed."],
        "created_at": datetime.now().isoformat()
    },
    {
        "candidate_id": "dana.s@example.com",
        "job_id": "Junior Frontend Developer",
        "panel_members": [
            {
                "interviewer_id": "bob.w@example.com",
                "name": "Bob Williams",
                "match_score": 0.90,
                "conflict_status": False,
                "diversity_contribution": 0.1,
                "role_in_panel": InterviewerType.TECHNICAL,
                "recommendation_reason": "Strong frontend skills (Vue.js, JS, CSS)."
            },
            {
                "interviewer_id": "carol.d@example.com",
                "name": "Carol Davis",
                "match_score": 0.85,
                "conflict_status": False,
                "diversity_contribution": 0.3,
                "role_in_panel": InterviewerType.HR,
                "recommendation_reason": "Excellent behavioral interviewer, D&I focus."
            }
        ],
        "overall_diversity_score": 0.80,
        "skill_coverage_score": 0.85,
        "conflict_flags": [],
        "panel_quality_score": 0.88,
        "recommendations": ["Focus on foundational JavaScript knowledge."],
        "created_at": (datetime.now() - timedelta(days=1)).isoformat()
    }
]

# --- Example of how you might load this data into your Pydantic models ---
if __name__ == "__main__":
    from pydantic import BaseModel, EmailStr, Field # Import here for standalone execution
    # Redefine models if running this file directly for testing, otherwise import them.
    # (Copied from your prompt for self-contained example)
    class Job(BaseModel):
        job_role: str
        job_description: str
        required_skills: List[str]
        experience_level: ExperienceLevel
        special_requirements: Optional[str] = None
        department: str
        interviewer_types_needed: List[InterviewerType] = Field(
            default=[InterviewerType.TECHNICAL, InterviewerType.BEHAVIORAL]
        )

    class Interviewer(BaseModel):
        name: str
        email: EmailStr
        department: str
        skills: List[str]
        gender: str
        race: str
        availability: List[Dict[str, Any]]  # [{from: datetime, to: datetime}]
        past_feedback_score: float = Field(ge=0.0, le=5.0)
        past_companies: List[str]
        experience_level: ExperienceLevel
        interviewer_type: InterviewerType
        total_interviews_conducted: int = 0
        average_interview_rating: float = Field(default=0.0, ge=0.0, le=5.0)
        specializations: List[str] = Field(default_factory=list)
        years_of_experience: int = Field(ge=0)

    class Candidate(BaseModel):
        name: str
        email: EmailStr
        job_role: str
        skills: List[str]
        previous_companies: List[str]
        experience_level: ExperienceLevel
        current_company: Optional[str] = None
        linkedin_profile: Optional[str] = None
        resume_summary: Optional[str] = None

    class PanelMember(BaseModel):
        interviewer_id: str
        name: str
        match_score: float
        conflict_status: bool
        diversity_contribution: float
        role_in_panel: InterviewerType
        recommendation_reason: str

    class Panel(BaseModel):
        candidate_id: str
        job_id: str
        panel_members: List[PanelMember]
        overall_diversity_score: float
        skill_coverage_score: float
        conflict_flags: List[Dict[str, Any]]
        panel_quality_score: float
        recommendations: List[str]
        created_at: datetime = Field(default_factory=datetime.now)

    loaded_jobs = [Job(**data) for data in jobs_data]
    print(f"Loaded {len(loaded_jobs)} jobs.")
    # print(loaded_jobs[0].model_dump_json(indent=2)) # Use model_dump_json for Pydantic v2+

    loaded_interviewers = []
    for data in interviewers_data:
        # Convert string dates back to datetime objects for Pydantic validation
        for avail in data["availability"]:
            avail["from"] = datetime.fromisoformat(avail["from"])
            avail["to"] = datetime.fromisoformat(avail["to"])
        loaded_interviewers.append(Interviewer(**data))
    print(f"Loaded {len(loaded_interviewers)} interviewers.")
    # print(loaded_interviewers[0].model_dump_json(indent=2))

    loaded_candidates = [Candidate(**data) for data in candidates_data]
    print(f"Loaded {len(loaded_candidates)} candidates.")
    # print(loaded_candidates[0].model_dump_json(indent=2))

    loaded_panels = []
    for data in panels_data:
        # Convert string date back to datetime object
        data["created_at"] = datetime.fromisoformat(data["created_at"])
        loaded_panels.append(Panel(**data))
    print(f"Loaded {len(loaded_panels)} panels.")
    # print(loaded_panels[0].model_dump_json(indent=2))