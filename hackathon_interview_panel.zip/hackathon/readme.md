# Interview Panel Optimizer

AI-powered interview panel optimization with DEI (Diversity, Equity, and Inclusion) compliance and conflict detection.

## Features

- Create and manage job postings
- Add and manage interviewers and candidates
- AI-powered panel recommendations with enhanced skill and diversity analysis
- Conflict of interest detection
- Diversity and panel quality analytics
- Streamlit web UI and FastAPI backend
- **LLM Agents:** The backend uses LLM-based agents (via LangChain and Google Gemini) for advanced reasoning, skill matching, and panel composition strategies.

## Project Structure

```
.
├── .env
├── requirements.txt
├── streamlit_app.py
└── app/
    ├── crud.py
    ├── database.py
    ├── main.py
    ├── models.py
    ├── seed.py
    ├── utils.py
    └── __pycache__/
```

## Getting Started

### Prerequisites

- Python 3.8+
- MongoDB Atlas cluster (or local MongoDB)
- Google Gemini API key (for AI features)

### Installation

1. **Clone the repository**

2. **Install dependencies**
   ```sh
   pip install -r requirements.txt
   ```

3. **Set up environment variables**

   Create a `.env` file in the root directory with the following variables:
   ```
   GEMINI_API_KEY=your_google_gemini_api_key
   MONGODB_URI=your_mongodb_connection_string
   ```

   - `GEMINI_API_KEY`: Your Google Gemini API key for LLM agent features.
   - `MONGODB_URI`: Your MongoDB connection string.

4. **Configure MongoDB**

   Update the MongoDB connection string in [`app/database.py`](app/database.py) if needed.

### Running the Backend (FastAPI)

```sh
uvicorn app.main:app --reload
```

The API will be available at [http://localhost:8000](http://localhost:8000).

### Running the Frontend (Streamlit)

```sh
streamlit run streamlit_app.py
```

The Streamlit app will open in your browser.

## API Endpoints

See [`app/main.py`](app/main.py) for all endpoints. Key endpoints include:

- `/job/create` - Create a new job
- `/interviewer/add` - Add a new interviewer
- `/candidate/register` - Register a new candidate
- `/job/{job_id}/recommend_panel` - Get panel recommendations for a job
- `/candidate/{candidate_id}/suggest_panel` - Get panel recommendations for a candidate
- `/analytics/diversity-report` - Diversity analytics
- `/analytics/panel-quality` - Panel quality analytics

## Customization

- **LLM agent logic** and scoring are in [`app/utils.py`](app/utils.py)
- Data models are in [`app/models.py`](app/models.py)
- Database CRUD operations are in [`app/crud.py`](app/crud.py)

## License

MIT License

---

**Note:** This project uses Google Gemini for AI-powered recommendations. Ensure you comply with Google API usage policies.