import google.generativeai as genai
from tavily import TavilyClient
from typing import List, Dict, Any, Optional
import json
from models import Candidate, Panelist, InterviewPanel, PanelRecommendation
from rag_system import RAGSystem
import os
from dotenv import load_dotenv

load_dotenv()

class BaseAgent:
    def __init__(self):
        genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
        self.llm = genai.GenerativeModel('gemini-pro')
        self.rag_system = RAGSystem()
        
    def generate_response(self, prompt: str) -> str:
        """Generate response using Gemini"""
        try:
            response = self.llm.generate_content(prompt)
            return response.text
        except Exception as e:
            return f"Error generating response: {str(e)}"

class SkillMatchAgent(BaseAgent):
    def __init__(self):
        super().__init__()
        self.agent_name = "Skill Match Agent"
        
    def analyze_skill_match(self, candidate: Candidate, available_panelists: List[Panelist]) -> Dict[str, Any]:
        """Analyze skill match between candidate requirements and available panelists"""
        
        # Get RAG guidance for this specific role
        rag_guidance = self.rag_system.get_role_specific_guidance(
            candidate.role, 
            candidate.experience_level.value
        )
        
        prompt = f"""
        As the Skill Match Agent, analyze the skill alignment between the candidate and potential panelists.
        
        **Candidate Profile:**
        - Role: {candidate.role}
        - Department: {candidate.department.value}
        - Experience Level: {candidate.experience_level.value}
        - Required Skills: {', '.join(candidate.required_skills)}
        - Behavioral Competencies: {', '.join(candidate.behavioral_competencies)}
        - Years of Experience: {candidate.years_of_experience}
        
        **Available Panelists:**
        {self._format_panelists_for_prompt(available_panelists)}
        
        **Industry Best Practices (from RAG):**
        {rag_guidance}
        
        **Analysis Required:**
        1. Calculate skill match scores (0-1) for each panelist based on:
           - Technical skill overlap with candidate requirements
           - Relevant experience level for evaluation
           - Past interview performance
        
        2. Recommend top 3-4 panelists for the panel
        
        3. Identify any skill gaps in the recommended panel
        
        Return your analysis in JSON format:
        {{
            "panelist_scores": {{
                "panelist_id": {{
                    "skill_match_score": 0.0-1.0,
                    "technical_alignment": 0.0-1.0,
                    "experience_relevance": 0.0-1.0,
                    "interview_effectiveness": 0.0-1.0,
                    "reasoning": "explanation"
                }}
            }},
            "recommended_panelists": ["id1", "id2", "id3"],
            "skill_coverage_analysis": {{
                "covered_skills": ["skill1", "skill2"],
                "missing_skills": ["skill3"],
                "coverage_score": 0.0-1.0
            }},
            "recommendations": ["recommendation1", "recommendation2"]
        }}
        """
        
        response = self.generate_response(prompt)
        try:
            return json.loads(response)
        except json.JSONDecodeError:
            # Fallback analysis if JSON parsing fails
            return self._fallback_skill_analysis(candidate, available_panelists)
    
    def _format_panelists_for_prompt(self, panelists: List[Panelist]) -> str:
        """Format panelist data for the prompt"""
        formatted = []
        for p in panelists:
            formatted.append(f"""
            ID: {p.id}
            Name: {p.name}
            Role: {p.role}
            Department: {p.department.value}
            Experience: {p.experience_level.value} ({p.years_of_experience} years)
            Skills: {', '.join(p.skills)}
            Interview Score: {p.interview_feedback_score}/5.0
            Interviews Conducted: {p.total_interviews_conducted}
            """)
        return '\n'.join(formatted)
    
    def _fallback_skill_analysis(self, candidate: Candidate, panelists: List[Panelist]) -> Dict[str, Any]:
        """Fallback skill analysis if LLM response parsing fails"""
        scores = {}
        for panelist in panelists:
            skill_overlap = len(set(candidate.required_skills) & set(panelist.skills))
            total_skills = len(set(candidate.required_skills) | set(panelist.skills))
            skill_score = skill_overlap / total_skills if total_skills > 0 else 0
            
            scores[panelist.id] = {
                "skill_match_score": skill_score,
                "technical_alignment": skill_score,
                "experience_relevance": 0.8 if panelist.experience_level.value == candidate.experience_level.value else 0.6,
                "interview_effectiveness": panelist.interview_feedback_score / 5.0,
                "reasoning": f"Skills overlap: {skill_overlap}/{len(candidate.required_skills)}"
            }
        
        # Sort by skill match score and recommend top 3
        sorted_panelists = sorted(scores.items(), key=lambda x: x[1]["skill_match_score"], reverse=True)
        recommended = [p[0] for p in sorted_panelists[:3]]
        
        return {
            "panelist_scores": scores,
            "recommended_panelists": recommended,
            "skill_coverage_analysis": {
                "covered_skills": candidate.required_skills[:2],
                "missing_skills": candidate.required_skills[2:],
                "coverage_score": 0.7
            },
            "recommendations": ["Include technical expertise", "Balance experience levels"]
        }

class DEIComplianceAgent(BaseAgent):
    def __init__(self):
        super().__init__()
        self.agent_name = "DEI Compliance Agent"
        
    def analyze_diversity(self, candidate: Candidate, potential_panel: List[Panelist]) -> Dict[str, Any]:
        """Analyze diversity aspects of the proposed panel"""
        
        # Get diversity best practices from RAG
        diversity_guidance = self.rag_system.query_best_practices(
            "diversity interview panel composition gender ethnicity experience",
            candidate.role
        )
        
        rag_content = "\n".join([result["content"] for result in diversity_guidance])
        
        prompt = f"""
        As the DEI Compliance Agent, analyze the diversity of the proposed interview panel.
        
        **Candidate Profile:**
        - Role: {candidate.role}
        - Department: {candidate.department.value}
        - Experience Level: {candidate.experience_level.value}
        
        **Proposed Panel:**
        {self._format_panel_diversity_info(potential_panel)}
        
        **Diversity Best Practices (from RAG):**
        {rag_content}
        
        **Analysis Required:**
        1. Evaluate gender diversity (aim for balanced representation)
        2. Assess ethnic diversity 
        3. Analyze experience level diversity
        4. Check department/functional diversity
        5. Calculate overall diversity score (0-1)
        6. Provide recommendations for improvement
        
        Return analysis in JSON format:
        {{
            "diversity_metrics": {{
                "gender_distribution": {{"Male": 0, "Female": 0, "Non-Binary": 0}},
                "ethnicity_diversity_score": 0.0-1.0,
                "experience_level_spread": {{"Junior": 0, "Mid": 0, "Senior": 0, "Staff": 0, "Principal": 0}},
                "department_diversity": {{"Engineering": 0, "Product": 0, "etc": 0}}
            }},
            "overall_diversity_score": 0.0-1.0,
            "diversity_gaps": ["gap1", "gap2"],
            "recommendations": ["recommendation1", "recommendation2"],
            "compliance_status": "Compliant/Non-Compliant",
            "improvement_suggestions": ["suggestion1", "suggestion2"]
        }}
        """
        
        response = self.generate_response(prompt)
        try:
            return json.loads(response)
        except json.JSONDecodeError:
            return self._fallback_diversity_analysis(potential_panel)
    
    def _format_panel_diversity_info(self, panelists: List[Panelist]) -> str:
        """Format panelist diversity information for prompt"""
        formatted = []
        for p in panelists:
            formatted.append(f"""
            ID: {p.id}
            Name: {p.name}
            Gender: {p.gender.value}
            Ethnicity: {p.ethnicity}
            Experience Level: {p.experience_level.value}
            Department: {p.department.value}
            Role: {p.role}
            """)
        return '\n'.join(formatted)
    
    def _fallback_diversity_analysis(self, panelists: List[Panelist]) -> Dict[str, Any]:
        """Fallback diversity analysis"""
        gender_dist = {}
        exp_dist = {}
        dept_dist = {}
        
        for p in panelists:
            gender_dist[p.gender.value] = gender_dist.get(p.gender.value, 0) + 1
            exp_dist[p.experience_level.value] = exp_dist.get(p.experience_level.value, 0) + 1
            dept_dist[p.department.value] = dept_dist.get(p.department.value, 0) + 1
        
        # Simple diversity scoring
        gender_diversity = 1 - max(gender_dist.values()) / len(panelists) if panelists else 0
        overall_score = min(gender_diversity * 1.5, 1.0)  # Simplified scoring
        
        return {
            "diversity_metrics": {
                "gender_distribution": gender_dist,
                "ethnicity_diversity_score": 0.7,
                "experience_level_spread": exp_dist,
                "department_diversity": dept_dist
            },
            "overall_diversity_score": overall_score,
            "diversity_gaps": ["Consider more gender balance"] if gender_diversity < 0.3 else [],
            "recommendations": ["Maintain current diversity levels"],
            "compliance_status": "Compliant" if overall_score > 0.6 else "Needs Improvement",
            "improvement_suggestions": ["Include more diverse panelists"] if overall_score < 0.6 else []
        }

class PanelDesignOptimizerAgent(BaseAgent):
    def __init__(self):
        super().__init__()
        self.agent_name = "Panel Design Optimizer Agent"
        self.tavily_client = TavilyClient(api_key=os.getenv("TAVILY_API_KEY"))
        
    def optimize_panel_design(self, candidate: Candidate, skill_analysis: Dict[str, Any], 
                            diversity_analysis: Dict[str, Any], available_panelists: List[Panelist]) -> PanelRecommendation:
        """Optimize the overall panel design using all inputs"""
        
        # Get comprehensive best practices from RAG
        panel_guidance = self.rag_system.query_best_practices(
            f"optimal interview panel design {candidate.role} {candidate.experience_level.value}",
            candidate.role,
            k=5
        )
        
        # Get latest industry trends via web search
        industry_trends = self._get_industry_trends(candidate.role)
        
        rag_content = "\n".join([result["content"] for result in panel_guidance])
        
        prompt = f"""
        As the Panel Design Optimizer Agent, create the optimal interview panel recommendation.
        
        **Candidate Profile:**
        - Role: {candidate.role}
        - Department: {candidate.department.value}
        - Experience Level: {candidate.experience_level.value}
        - Required Skills: {', '.join(candidate.required_skills)}
        - Behavioral Competencies: {', '.join(candidate.behavioral_competencies)}
        
        **Skill Match Analysis:**
        {json.dumps(skill_analysis, indent=2)}
        
        **Diversity Analysis:**
        {json.dumps(diversity_analysis, indent=2)}
        
        **Best Practices (RAG):**
        {rag_content}
        
        **Industry Trends:**
        {industry_trends}
        
        **Available Panelists:**
        {self._format_panelists_for_optimization(available_panelists)}
        
        **Optimization Criteria:**
        1. Skill relevance and coverage (30% weight)
        2. Diversity and inclusion (25% weight)
        3. Interview effectiveness (20% weight)
        4. Experience level appropriateness (15% weight)
        5. Conflict avoidance (10% weight)
        
        Create the optimal panel recommendation (3-4 panelists) and return in JSON format:
        {{
            "recommended_panel": {{
                "panelist_ids": ["id1", "id2", "id3"],
                "panel_composition_rationale": "explanation",
                "interview_structure": "Technical/Behavioral/Mixed",
                "estimated_duration": "minutes"
            }},
            "optimization_scores": {{
                "skill_match_score": 0.0-1.0,
                "diversity_score": 0.0-1.0,
                "effectiveness_score": 0.0-1.0,
                "overall_score": 0.0-1.0
            }},
            "panel_strengths": ["strength1", "strength2"],
            "potential_concerns": ["concern1", "concern2"],
            "alternative_configurations": [
                {{
                    "panelist_ids": ["alt1", "alt2", "alt3"],
                    "rationale": "alternative reasoning"
                }}
            ],
            "final_recommendations": ["final_rec1", "final_rec2"]
        }}
        """
        
        response = self.generate_response(prompt)
        try:
            optimization_result = json.loads(response)
            return self._create_panel_recommendation(
                candidate, optimization_result, available_panelists, 
                skill_analysis, diversity_analysis
            )
        except json.JSONDecodeError:
            return self._create_fallback_recommendation(
                candidate, available_panelists, skill_analysis, diversity_analysis
            )
    
    def _get_industry_trends(self, role: str) -> str:
        """Get latest industry trends for interview practices"""
        try:
            query = f"latest interview panel best practices {role} 2024 2025"
            search_result = self.tavily_client.search(query, max_results=3)
            
            trends = []
            for result in search_result.get('results', []):
                trends.append(f"- {result.get('title', '')}: {result.get('content', '')[:200]}...")
            
            return '\n'.join(trends) if trends else "No recent trends found."
        except Exception as e:
            return f"Unable to fetch industry trends: {str(e)}"
    
    def _format_panelists_for_optimization(self, panelists: List[Panelist]) -> str:
        """Format panelist data for optimization prompt"""
        formatted = []
        for p in panelists:
            formatted.append(f"""
            ID: {p.id}, Name: {p.name}, Role: {p.role}
            Skills: {', '.join(p.skills[:3])}{'...' if len(p.skills) > 3 else ''}
            Experience: {p.experience_level.value}, Gender: {p.gender.value}
            Interview Score: {p.interview_feedback_score}/5.0
            """)
        return '\n'.join(formatted)
    
    def _create_panel_recommendation(self, candidate: Candidate, optimization_result: Dict[str, Any], 
                                   available_panelists: List[Panelist], skill_analysis: Dict[str, Any], 
                                   diversity_analysis: Dict[str, Any]) -> PanelRecommendation:
        """Create the final panel recommendation object"""
        
        # Get recommended panelists
        recommended_ids = optimization_result.get("recommended_panel", {}).get("panelist_ids", [])
        recommended_panelists = [p for p in available_panelists if p.id in recommended_ids]
        
        # Create main panel
        main_panel = InterviewPanel(
            panel_id=f"panel_{candidate.id}_{len(recommended_panelists)}",
            candidate=candidate,
            panelists=recommended_panelists,
            interview_type=optimization_result.get("recommended_panel", {}).get("interview_structure", "Mixed"),
            diversity_score=optimization_result.get("optimization_scores", {}).get("diversity_score", 0.7),
            skill_match_score=optimization_result.get("optimization_scores", {}).get("skill_match_score", 0.7),
            conflict_risk_score=0.1,  # Assume low conflict risk for now
            overall_score=optimization_result.get("optimization_scores", {}).get("overall_score", 0.7),
            recommendations=optimization_result.get("final_recommendations", [])
        )
        
        # Create alternative panels
        alternatives = []
        for alt_config in optimization_result.get("alternative_configurations", [])[:2]:
            alt_ids = alt_config.get("panelist_ids", [])
            alt_panelists = [p for p in available_panelists if p.id in alt_ids]
            if alt_panelists:
                alt_panel = InterviewPanel(
                    panel_id=f"alt_panel_{candidate.id}_{len(alt_panelists)}",
                    candidate=candidate,
                    panelists=alt_panelists,
                    interview_type="Mixed",
                    diversity_score=0.6,
                    skill_match_score=0.6,
                    conflict_risk_score=0.1,
                    overall_score=0.6,
                    recommendations=[alt_config.get("rationale", "Alternative configuration")]
                )
                alternatives.append(alt_panel)
        
        return PanelRecommendation(
            recommended_panel=main_panel,
            reasoning=optimization_result.get("recommended_panel", {}).get("panel_composition_rationale", "Optimized panel composition"),
            alternative_options=alternatives,
            diversity_analysis=diversity_analysis,
            skill_coverage=skill_analysis.get("skill_coverage_analysis", {}),
            potential_conflicts=[]
        )
    
    def _create_fallback_recommendation(self, candidate: Candidate, available_panelists: List[Panelist], 
                                      skill_analysis: Dict[str, Any], diversity_analysis: Dict[str, Any]) -> PanelRecommendation:
        """Create fallback recommendation if optimization fails"""
        
        # Select top 3 panelists based on skill scores
        recommended_ids = skill_analysis.get("recommended_panelists", [])[:3]
        recommended_panelists = [p for p in available_panelists if p.id in recommended_ids]
        
        if not recommended_panelists:
            recommended_panelists = available_panelists[:3]
        
        main_panel = InterviewPanel(
            panel_id=f"fallback_panel_{candidate.id}",
            candidate=candidate,
            panelists=recommended_panelists,
            interview_type="Mixed",
            diversity_score=diversity_analysis.get("overall_diversity_score", 0.6),
            skill_match_score=0.7,
            conflict_risk_score=0.1,
            overall_score=0.65,
            recommendations=["Fallback panel configuration", "Review and adjust as needed"]
        )
        
        return PanelRecommendation(
            recommended_panel=main_panel,
            reasoning="Fallback panel based on skill matching and diversity analysis",
            alternative_options=[],
            diversity_analysis=diversity_analysis,
            skill_coverage=skill_analysis.get("skill_coverage_analysis", {}),
            potential_conflicts=[]
        )