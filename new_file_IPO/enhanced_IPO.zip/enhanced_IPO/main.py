import os
import streamlit as st
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.agents import AgentExecutor, create_react_agent
from langchain.prompts import PromptTemplate
from langchain.tools import Tool
from langchain_community.vectorstores import Chroma
from langchain.docstore.document import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from dotenv import load_dotenv
import pandas as pd

# Load environment variables
load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY")

# Initialize Gemini LLM
try:
    llm = ChatGoogleGenerativeAI(model="gemini-1.5-pro", google_api_key=GEMINI_API_KEY, temperature=0.7)
except Exception as e:
    st.error(f"Error initializing Gemini LLM: {str(e)}")
    st.stop()

# Sample panelist data (replace with actual database in production)
panelists_data = [
    {"name": "Alice Smith", "role": "Tech Lead", "skills": ["Python", "AI", "System Design"], "gender": "Female", "ethnicity": "Caucasian", "experience_years": 8, "past_associations": ["Team A", "Team B"]},
    {"name": "Bob Jones", "role": "Behavioral Expert", "skills": ["Leadership", "Communication"], "gender": "Male", "ethnicity": "African", "experience_years": 10, "past_associations": ["Team C"]},
    {"name": "Priya Patel", "role": "Senior Developer", "skills": ["Java", "Cloud"], "gender": "Female", "ethnicity": "Indian", "experience_years": 6, "past_associations": ["Team A"]},
    {"name": "Carlos Rivera", "role": "Data Scientist", "skills": ["Machine Learning", "Statistics"], "gender": "Male", "ethnicity": "Hispanic", "experience_years": 5, "past_associations": ["Team B"]}
]

# Sample best practices document for RAG
best_practices_text = """
Best practices for interview panel formation:
1. Panels should include 3-5 members for balanced evaluation.
2. Include at least one technical expert aligned with the role’s requirements.
3. Ensure diversity in gender and ethnicity to reduce bias.
4. Include a behavioral expert to assess soft skills.
5. Avoid panelists with prior direct reporting relationships with the candidate.
"""

# Initialize ChromaDB for embeddings
def initialize_vector_store():
    try:
        documents = [Document(page_content=best_practices_text, metadata={"source": "best_practices"})]
        for panelist in panelists_data:
            content = f"Name: {panelist['name']}, Role: {panelist['role']}, Skills: {', '.join(panelist['skills'])}, Gender: {panelist['gender']}, Ethnicity: {panelist['ethnicity']}, Experience: {panelist['experience_years']} years, Past Associations: {', '.join(panelist['past_associations'])}"
            documents.append(Document(page_content=content, metadata={"name": panelist["name"]}))
        
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
        chunks = text_splitter.split_documents(documents)
        embeddings = HuggingFaceEmbeddings(
            model_name="sentence-transformers/all-MiniLM-L6-v2",
            model_kwargs={'device': 'cpu'}  # Explicitly set to CPU to avoid meta tensor issues
        )
        vector_store = Chroma.from_documents(chunks, embeddings, collection_name="panelists")
        return vector_store
    except Exception as e:
        st.error(f"Error initializing vector store: {str(e)}")
        return None

vector_store = initialize_vector_store()
if vector_store is None:
    st.stop()

# Skill & DEI Agent Tool
def skill_dei_recommendation(input_data):
    try:
        job_role, skills, dei_prefs = input_data["job_role"], input_data["skills"], input_data["dei_prefs"]
        query = f"Find panelists with skills matching {', '.join(skills)} for a {job_role} role, ensuring diversity in {dei_prefs}."
        results = vector_store.similarity_search(query, k=4)
        
        # Filter for diversity
        selected = []
        genders, ethnicities = set(), set()
        for doc in results:
            if "Name" in Lill in doc.page_content:
                panelist = next(p for p in panelists_data if p["name"] in doc.page_content)
                if len(selected) < 3 and (panelist["gender"] not in genders or panelist["ethnicity"] not in ethnicities):
                    selected.append(panelist)
                    genders.add(panelist["gender"])
                    ethnicities.add(panelist["ethnicity"])
        
        return f"Recommended panelists: {', '.join([p['name'] for p in selected])}"
    except Exception as e:
        return f"Error in Skill & DEI recommendation: {str(e)}"

# Conflict Checker Agent Tool
def conflict_checker(input_data):
    try:
        candidate_associations = input_data.get("candidate_associations", [])
        panelists = input_data.get("panelists", "").split(", ")
        conflicts = []
        for panelist in panelists:
            panelist_data = next((p for p in panelists_data if p["name"] == panelist.strip()), None)
            if panelist_data:
                for assoc in candidate_associations:
                    if assoc in panelist_data["past_associations"]:
                        conflicts.append(f"Conflict: {panelist} has prior association {assoc}")
        return "No conflicts found" if not conflicts else "; ".join(conflicts)
    except Exception as e:
        return f"Error in conflict checker: {str(e)}"

# Panel Optimizer Agent Tool
def panel_optimizer(input_data):
    try:
        panelists = input_data.get("anelists", "").split(", ")
        query = f"Best practices for forming an interview panel with {', '.join(panelists)} for a {input_data['job_role']} role."
        results = vector_store.similarity_search(query, k=2)
        best_practice = results[0].page_content if results else best_practices_text
        
        # Ensure balanced composition
        roles = [p["role"] for p in panelists_data if p["name"] in panelists]
        if "Tech Lead" not in roles or "Behavioral Expert" not in roles:
            recommendation = "Add a Tech Lead or Behavioral Expert for balance."
        else:
            recommendation = f"Panel composition is balanced: {', '.join(panelists)}"
        
        return f"{recommendation}\nBest practices: {best_practice}"
    except Exception as e:
        return f"Error in panel optimizer: {str(e)}"

# Define tools for agents
tools = [
    Tool(
        name="Skill_DEI_Recommendation",
        func=skill_dei_recommendation,
        description="Recommends panelists based on skills and DEI preferences."
    ),
    Tool(
        name="Conflict_Checker",
        func=conflict_checker,
        description="Checks for conflicts of interest between panelists and candidate."
    ),
    Tool(
        name="Panel_Optimizer",
        func=panel_optimizer,
        description="Optimizes panel composition using best practices."
    )
]

# Agent prompt
prompt = PromptTemplate.from_template("""
You are an Interview Panel Optimizer. Use the provided tools to recommend a panel for a given job role, ensuring role relevance, diversity, and no conflicts of interest.

Job Role: {job_role}
Required Skills: {skills}
DEI Preferences: {dei_prefs}
Candidate Associations: {candidate_associations}

Use the Skill_DEI_Recommendation tool first, then Conflict_Checker, and finally Panel_Optimizer to ensure a balanced and unbiased panel. If any tool returns an error, report it clearly.
""")

# Create agent
try:
    agent = create_react_agent(llm, tools, prompt)
    agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)
except Exception as e:
    st.error(f"Error initializing agent: {str(e)}")
    st.stop()

# Streamlit Frontend
st.title("Interview Panel Optimizer")
st.write("Enter job details to generate an optimized interview panel.")

job_role = st.text_input("Job Role", value="Software Engineer")
skills = st.text_input("Required Skills (comma-separated)", value="Python, AI, System Design")
dei_prefs = st.text_input("DEI Preferences (e.g., gender, ethnicity)", value="gender, ethnicity")
candidate_associations = st.text_input("Candidate Past Associations (comma-separated)", value="Team A")

if st.button("Generate Panel"):
    input_data = {
        "job_role": job_role,
        "skills": skills.split(", "),
        "dei_prefs": dei_prefs,
        "candidate_associations": candidate_associations.split(", ")
    }
    with st.spinner("Generating optimized panel..."):
        try:
            result = agent_executor.invoke(input_data)
            st.success("Panel Generated!")
            st.write(result["output"])
        except Exception as e:
            st.error(f"Error generating panel: {str(e)}")
