from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from enum import Enum

class Gender(str, Enum):
    MALE = "Male"
    FEMALE = "Female"
    NON_BINARY = "Non-Binary"
    PREFER_NOT_TO_SAY = "Prefer not to say"

class ExperienceLevel(str, Enum):
    JUNIOR = "Junior"
    MID = "Mid"
    SENIOR = "Senior"
    STAFF = "Staff"
    PRINCIPAL = "Principal"

class Department(str, Enum):
    ENGINEERING = "Engineering"
    PRODUCT = "Product"
    DESIGN = "Design"
    DATA_SCIENCE = "Data Science"
    MARKETING = "Marketing"
    SALES = "Sales"
    HR = "HR"
    FINANCE = "Finance"

class Panelist(BaseModel):
    id: str
    name: str
    email: str
    department: Department
    role: str
    experience_level: ExperienceLevel
    skills: List[str]
    gender: Gender
    ethnicity: str
    years_of_experience: int
    interview_feedback_score: float  # Average score from past interviews
    total_interviews_conducted: int
    recent_team_associations: List[str]  # Recent team/project associations
    reporting_relationships: List[str]  # Direct reports or managers

class Candidate(BaseModel):
    id: str
    name: str
    role: str
    department: Department
    experience_level: ExperienceLevel
    required_skills: List[str]
    behavioral_competencies: List[str]
    years_of_experience: int
    previous_company: Optional[str]
    referrer_id: Optional[str]  # If referred by someone in company

class InterviewPanel(BaseModel):
    panel_id: str
    candidate: Candidate
    panelists: List[Panelist]
    interview_type: str  # "Technical", "Behavioral", "Cultural Fit", "Mixed"
    diversity_score: float
    skill_match_score: float
    conflict_risk_score: float
    overall_score: float
    recommendations: List[str]

class PanelRecommendation(BaseModel):
    recommended_panel: InterviewPanel
    reasoning: str
    alternative_options: List[InterviewPanel]
    diversity_analysis: Dict[str, Any]
    skill_coverage: Dict[str, float]
    potential_conflicts: List[str]