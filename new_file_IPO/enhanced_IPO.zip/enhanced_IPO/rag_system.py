import chromadb
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
from langchain.schema import Document
import os
from typing import List, Dict, Any
import json

class RAGSystem:
    def __init__(self, persist_directory: str = "./chroma_db"):
        self.persist_directory = persist_directory
        self.embeddings = HuggingFaceEmbeddings(
            model_name="sentence-transformers/all-MiniLM-L6-v2"
        )
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200
        )
        self.vectorstore = None
        self.initialize_vectorstore()
        
    def initialize_vectorstore(self):
        """Initialize the vector store with interview best practices"""
        # Create sample interview best practices data
        best_practices_data = [
            {
                "title": "Technical Interview Panel Composition",
                "content": "For technical roles, panels should include: 1) A senior engineer from the same domain, 2) A cross-functional team member, 3) A hiring manager or tech lead. Avoid having more than 4 panelists to prevent candidate overwhelm. Technical panelists should have hands-on experience with the required technologies.",
                "category": "technical",
                "role_types": ["Software Engineer", "Data Scientist", "DevOps Engineer"]
            },
            {
                "title": "Diversity in Interview Panels",
                "content": "Research shows diverse interview panels reduce bias by 30%. Include panelists from different backgrounds, experience levels, and departments when possible. Aim for at least one female panelist for every panel, and ensure ethnic diversity reflects company demographics.",
                "category": "diversity",
                "role_types": ["all"]
            },
            {
                "title": "Behavioral Interview Best Practices",
                "content": "Behavioral assessments require panelists trained in competency-based interviewing. Include an HR representative or trained behavioral interviewer. Focus on leadership, communication, and cultural fit. Avoid having direct managers of the candidate's potential team to reduce confirmation bias.",
                "category": "behavioral",
                "role_types": ["Senior Engineer", "Manager", "Director"]
            },
            {
                "title": "Panel Size Optimization",
                "content": "Optimal panel size is 3-4 members. Smaller panels (2 members) may lack diverse perspectives, while larger panels (5+ members) can intimidate candidates and reduce individual panelist engagement. Each panelist should have a specific evaluation focus.",
                "category": "structure",
                "role_types": ["all"]
            },
            {
                "title": "Conflict of Interest Prevention",
                "content": "Avoid panelists who: 1) Previously worked directly with the candidate, 2) Have personal relationships with the candidate, 3) Are direct competitors for the same role, 4) Have financial interests in the hire decision. Maintain professional distance while ensuring relevant expertise.",
                "category": "conflict_prevention",
                "role_types": ["all"]
            },
            {
                "title": "Junior Role Interview Panels",
                "content": "For junior positions, include: 1) A senior team member as mentor figure, 2) A peer-level interviewer for relatability, 3) A cross-functional stakeholder. Focus on potential over experience. Avoid intimidating senior leadership unless culturally appropriate.",
                "category": "junior_roles",
                "role_types": ["Junior Engineer", "Associate", "Entry Level"]
            },
            {
                "title": "Senior Role Interview Panels",
                "content": "Senior roles require panels with: 1) Peer-level or senior technical experts, 2) Cross-functional leaders they'll collaborate with, 3) A team member they'll potentially manage. Include stakeholders who understand strategic impact of the role.",
                "category": "senior_roles",
                "role_types": ["Senior Engineer", "Staff Engineer", "Principal", "Manager"]
            }
        ]
        
        # Convert to documents
        documents = []
        for item in best_practices_data:
            doc = Document(
                page_content=item["content"],
                metadata={
                    "title": item["title"],
                    "category": item["category"],
                    "role_types": item["role_types"]
                }
            )
            documents.append(doc)
        
        # Split documents
        split_docs = self.text_splitter.split_documents(documents)
        
        # Create vector store
        self.vectorstore = Chroma.from_documents(
            documents=split_docs,
            embedding=self.embeddings,
            persist_directory=self.persist_directory
        )
        
    def query_best_practices(self, query: str, role_type: str = None, k: int = 3) -> List[Dict[str, Any]]:
        """Query the RAG system for relevant best practices"""
        if not self.vectorstore:
            return []
            
        # Add role-specific context to query
        if role_type:
            enhanced_query = f"Best practices for {role_type} interviews: {query}"
        else:
            enhanced_query = query
            
        results = self.vectorstore.similarity_search_with_score(enhanced_query, k=k)
        
        formatted_results = []
        for doc, score in results:
            formatted_results.append({
                "content": doc.page_content,
                "metadata": doc.metadata,
                "relevance_score": 1 - score  # Convert distance to similarity
            })
            
        return formatted_results
    
    def get_role_specific_guidance(self, role: str, experience_level: str) -> str:
        """Get specific guidance for a role and experience level"""
        query = f"interview panel composition for {role} {experience_level} position"
        results = self.query_best_practices(query, role_type=role)
        
        if results:
            guidance = "\n\n".join([result["content"] for result in results[:2]])
            return guidance
        else:
            return "General best practices: Include diverse perspectives, relevant technical expertise, and appropriate seniority levels."